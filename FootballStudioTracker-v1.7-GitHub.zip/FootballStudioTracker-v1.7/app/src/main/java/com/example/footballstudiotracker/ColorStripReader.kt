package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences
import kotlin.math.max

/**
 * Reads Evolution's narrow colored marker/chevron in each result tile.
 * The selected region must cover the result strip only, from first visible tile
 * to last visible tile. We scan every pixel in the center band so thin markers
 * are not skipped by a coarse sampling step.
 */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): List<Char>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 4) return null

        val left = (width * (prefs.getInt("region_left", 18) / 1000f)).toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 435) / 1000f)).toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 985) / 1000f)).toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 500) / 1000f)).toInt().coerceIn(top + 1, height - 1)
        val count = prefs.getInt("scan_count", 7).coerceIn(3, 12)
        val regionWidth = right - left
        val regionHeight = bottom - top
        if (regionWidth < count * 12 || regionHeight < 8) return null

        val hsv = FloatArray(3)
        val output = ArrayList<Char>(count)
        for (slot in 0 until count) {
            val slotLeft = left + regionWidth * slot / count
            val slotRight = left + regionWidth * (slot + 1) / count
            val slotWidth = slotRight - slotLeft

            // The Evolution marker is centered inside each dark chevron. Include
            // enough width for a 1-3 px marker, but avoid neighboring tiles.
            val centerX = (slotLeft + slotRight) / 2
            val halfBand = max(2, (slotWidth * 0.18f).toInt())
            val sampleLeft = (centerX - halfBand).coerceAtLeast(slotLeft + 2)
            val sampleRight = (centerX + halfBand).coerceAtMost(slotRight - 2)
            val sampleTop = top + (regionHeight * 0.14f).toInt()
            val sampleBottom = bottom - (regionHeight * 0.14f).toInt()
            if (sampleRight <= sampleLeft || sampleBottom <= sampleTop) return null

            var redPixels = 0
            var bluePixels = 0
            var yellowPixels = 0
            var validPixels = 0
            val redByColumn = IntArray(sampleRight - sampleLeft)
            val blueByColumn = IntArray(sampleRight - sampleLeft)
            val yellowByColumn = IntArray(sampleRight - sampleLeft)

            var y = sampleTop
            while (y < sampleBottom) {
                var x = sampleLeft
                while (x < sampleRight) {
                    val index = y * rowStride + x * pixelStride
                    if (index >= 0 && index + 3 < buffer.limit()) {
                        val r = buffer.get(index).toInt() and 0xff
                        val g = buffer.get(index + 1).toInt() and 0xff
                        val b = buffer.get(index + 2).toInt() and 0xff
                        val a = buffer.get(index + 3).toInt() and 0xff
                        if (a > 100) {
                            Color.RGBToHSV(r, g, b, hsv)
                            val hue = hsv[0]
                            val saturation = hsv[1]
                            val value = hsv[2]
                            val col = x - sampleLeft
                            when {
                                // Red A: allow slightly orange/red shades from video compression.
                                saturation >= 0.28f && value >= 0.20f && (hue <= 24f || hue >= 338f) -> {
                                    redPixels++
                                    redByColumn[col]++
                                }
                                // Blue B: wide hue range covers Evolution's deep/cyan blue.
                                saturation >= 0.26f && value >= 0.18f && hue in 185f..265f -> {
                                    bluePixels++
                                    blueByColumn[col]++
                                }
                                // Yellow X: the marker is gold, not bright lemon yellow.
                                saturation >= 0.22f && value >= 0.38f && hue in 24f..72f -> {
                                    yellowPixels++
                                    yellowByColumn[col]++
                                }
                            }
                            validPixels++
                        }
                    }
                    x++
                }
                y++
            }

            if (validPixels < 20) return null
            val sampleHeight = max(1, sampleBottom - sampleTop)
            fun score(total: Int, columns: IntArray): Float {
                val areaCoverage = total.toFloat() / validPixels
                val strongestVerticalMarker = (columns.maxOrNull() ?: 0).toFloat() / sampleHeight
                // Solid-color tiles score by area; dark tiles with a thin vertical
                // marker score by the strongest column.
                return max(areaCoverage, strongestVerticalMarker * 0.72f)
            }
            val scores = listOf(
                'A' to score(redPixels, redByColumn),
                'B' to score(bluePixels, blueByColumn),
                'X' to score(yellowPixels, yellowByColumn)
            ).sortedByDescending { it.second }

            val best = scores[0]
            val second = scores[1].second
            // A colored result marker should form a visible vertical run. Reject
            // ambiguous or empty cells instead of assigning the wrong team.
            if (best.second < 0.075f || best.second < second * 1.18f) return null
            output.add(best.first)
        }
        return output
    }
}
