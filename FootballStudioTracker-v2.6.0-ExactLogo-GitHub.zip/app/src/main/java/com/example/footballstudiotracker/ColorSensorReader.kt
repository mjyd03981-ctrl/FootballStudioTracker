package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences

/**
 * Reads a small user-selected screen region. It deliberately ignores the moving video
 * background and counts only saturated red/blue/yellow pixels inside the sensor frame.
 */
object ColorSensorReader {
    data class Detection(val result: Char, val confidence: Float, val signature: String)

    fun detect(image: Image, prefs: SharedPreferences): Detection? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 2 || height < 2 || pixelStride < 4) return null

        // Coordinates are stored as thousandths of the captured screen dimensions.
        val left = (width * prefs.getInt("region_left", 12) / 1000f).toInt().coerceIn(0, width - 1)
        val top = (height * prefs.getInt("region_top", 430) / 1000f).toInt().coerceIn(0, height - 1)
        val right = (width * prefs.getInt("region_right", 138) / 1000f).toInt().coerceIn(left + 1, width)
        val bottom = (height * prefs.getInt("region_bottom", 490) / 1000f).toInt().coerceIn(top + 1, height)
        val roiWidth = right - left
        val roiHeight = bottom - top
        if (roiWidth < 4 || roiHeight < 4) return null

        val hsv = FloatArray(3)
        var red = 0
        var blue = 0
        var yellow = 0
        var samples = 0
        // Sample the full box, excluding a narrow border to avoid its blue outline.
        val insetX = (roiWidth * 0.08f).toInt()
        val insetY = (roiHeight * 0.08f).toInt()
        val x0 = (left + insetX).coerceAtMost(right - 1)
        val x1 = (right - insetX).coerceAtLeast(x0 + 1)
        val y0 = (top + insetY).coerceAtMost(bottom - 1)
        val y1 = (bottom - insetY).coerceAtLeast(y0 + 1)
        val stepX = maxOf(1, (x1 - x0) / 48)
        val stepY = maxOf(1, (y1 - y0) / 32)
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val index = y * rowStride + x * pixelStride
                if (index >= 0 && index + 2 < buffer.limit()) {
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    Color.RGBToHSV(r, g, b, hsv)
                    val h = hsv[0]
                    val s = hsv[1]
                    val v = hsv[2]
                    samples++
                    if (s >= 0.58f && v >= 0.30f) {
                        when {
                            h <= 17f || h >= 345f -> red++
                            h in 195f..255f -> blue++
                            h in  thirty..sixtyFive -> yellow++
                        }
                    }
                }
                x += stepX
            }
            y += stepY
        }
        if (samples == 0) return null

        val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
        val best = scores[0]
        val second = scores[1].second
        // A genuine colored marker should occupy a visible fraction of the small ROI.
        val coverage = best.second.toFloat() / samples
        val dominance = best.second.toFloat() / (red + blue + yellow).coerceAtLeast(1)
        if (coverage < 0.003f || dominance < 0.68f || best.second < second * 1.45f) return null
        return Detection(best.first, dominance, "${best.first}:$coverage:$dominance")
    }

    private const val thirty = 28f
    private const val sixtyFive = 68f
}
