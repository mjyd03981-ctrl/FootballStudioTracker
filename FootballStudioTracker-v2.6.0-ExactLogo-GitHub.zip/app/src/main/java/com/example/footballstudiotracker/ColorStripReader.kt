package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences
import kotlin.math.max

/** Per-cell Evolution history reader. A null cell means "not confident"; it never guesses. */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): List<Char?>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 4) return null

        val left = (width * (prefs.getInt("region_left", 18) / 1000f)).toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 435) / 1000f)).toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 985) / 1000f)).toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 500) / 1000f)).toInt().coerceIn(top + 1, height - 1)
        val count = prefs.getInt("scan_count", 7).coerceIn(3, 12)
        val regionWidth = right - left
        val regionHeight = bottom - top
        if (regionWidth < count * 8 || regionHeight < 5) return null

        val hsv = FloatArray(3)
        val output = ArrayList<Char?>(count)
        for (slot in 0 until count) {
            val slotLeft = left + regionWidth * slot / count
            val slotRight = left + regionWidth * (slot + 1) / count
            val slotWidth = slotRight - slotLeft
            // Evolution history markers are narrow vertical strokes near each tile's center.
            val centerX = (slotLeft + slotRight) / 2
            val halfBand = max(2, (slotWidth * 0.22f).toInt())
            val sampleLeft = (centerX - halfBand).coerceAtLeast(slotLeft + 1)
            val sampleRight = (centerX + halfBand).coerceAtMost(slotRight - 1)
            val sampleTop = top + (regionHeight * 0.10f).toInt()
            val sampleBottom = bottom - (regionHeight * 0.10f).toInt()
            if (sampleRight <= sampleLeft || sampleBottom <= sampleTop) {
                output.add(null)
                continue
            }

            val sampleHeight = sampleBottom - sampleTop
            val redColumns = IntArray(sampleRight - sampleLeft)
            val blueColumns = IntArray(sampleRight - sampleLeft)
            val yellowColumns = IntArray(sampleRight - sampleLeft)
            var sampled = 0
            var y = sampleTop
            while (y < sampleBottom) {
                var x = sampleLeft
                while (x < sampleRight) {
                    val index = y * rowStride + x * pixelStride
                    if (index >= 0 && index + 3 < buffer.limit()) {
                        val r = buffer.get(index).toInt() and 0xff
                        val g = buffer.get(index + 1).toInt() and 0xff
                        val b = buffer.get(index + 2).toInt() and 0xff
                        val a = buffer.get(index + 3).toInt() and 0xff
                        if (a > 100) {
                            Color.RGBToHSV(r, g, b, hsv)
                            val h = hsv[0]
                            val s = hsv[1]
                            val v = hsv[2]
                            val col = x - sampleLeft
                            // Require chroma and brightness; hue bands include video-compressed shades.
                            when {
                                s >= 0.38f && v >= 0.22f && (h <= 22f || h >= 340f) -> redColumns[col]++
                                s >= 0.34f && v >= 0.20f && h in 188f..258f -> blueColumns[col]++
                                s >= 0.30f && v >= 0.38f && h in 28f..70f -> yellowColumns[col]++
                            }
                            sampled++
                        }
                    }
                    x++
                }
                y++
            }
            if (sampled < 12) {
                output.add(null)
                continue
            }

            // A thin vertical marker can occupy very little area. Score its strongest
            // column against sample height, then use total colored pixels as tie-breaker.
            fun score(columns: IntArray): Float {
                val peak = columns.maxOrNull() ?: 0
                val total = columns.sum()
                val verticalRun = peak.toFloat() / sampleHeight
                val colorDensity = total.toFloat() / sampled
                return max(verticalRun, colorDensity * 1.8f)
            }
            val scores = listOf(
                'A' to score(redColumns),
                'B' to score(blueColumns),
                'X' to score(yellowColumns)
            ).sortedByDescending { it.second }
            val best = scores[0]
            val second = scores[1].second
            // If the marker is weak or two colors compete, leave this cell unknown.
            output.add(if (best.second >= 0.12f && best.second >= second * 1.30f) best.first else null)
        }
        return output
    }
}
