package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences

/**
 * Reads only the selected upper-center winner announcement banner.
 * A = red host win, B = blue guest win, X = yellow draw/push.
 *
 * The sensor intentionally ignores text/card values and classifies the banner's
 * dominant saturated background color. The user should fit the frame tightly
 * around the announcement bar, not around the whole table.
 */
object BannerAnnouncementReader {
    data class Detection(
        val result: Char,
        val confidence: Float,
        val red: Int,
        val blue: Int,
        val yellow: Int
    )

    fun detect(image: Image, prefs: SharedPreferences): Detection? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 4) return null

        // Normalized screen coordinates saved by RegionSelectorOverlay.
        val left = (width * (prefs.getInt("region_left", 90) / 1000f))
            .toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 132) / 1000f))
            .toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 910) / 1000f))
            .toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 178) / 1000f))
            .toInt().coerceIn(top + 1, height - 1)

        val roiWidth = right - left
        val roiHeight = bottom - top
        if (roiWidth < 40 || roiHeight < 12) return null

        // Avoid frame edges and sample a dense grid across the banner background.
        val xStart = left + (roiWidth * 0.06f).toInt()
        val xEnd = right - (roiWidth * 0.06f).toInt()
        val yStart = top + (roiHeight * 0.18f).toInt()
        val yEnd = bottom - (roiHeight * 0.18f).toInt()
        val stepX = maxOf(1, roiWidth / 220)
        val stepY = maxOf(1, roiHeight / 20)

        val hsv = FloatArray(3)
        var red = 0
        var blue = 0
        var yellow = 0
        var coloredSamples = 0
        var validSamples = 0

        var y = yStart
        while (y < yEnd) {
            var x = xStart
            while (x < xEnd) {
                val index = y * rowStride + x * pixelStride
                if (index >= 0 && index + 3 < buffer.limit()) {
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    val a = buffer.get(index + 3).toInt() and 0xff
                    if (a > 100) {
                        validSamples++
                        Color.RGBToHSV(r, g, b, hsv)
                        val hue = hsv[0]
                        val saturation = hsv[1]
                        val value = hsv[2]

                        // Ignore white text, dark table pixels and low-saturation glare.
                        if (saturation >= 0.34f && value >= 0.24f) {
                            when {
                                hue <= 20f || hue >= 342f -> { red++; coloredSamples++ }
                                hue in 195f..255f -> { blue++; coloredSamples++ }
                                hue in 30f..65f -> { yellow++; coloredSamples++ }
                            }
                        }
                    }
                }
                x += stepX
            }
            y += stepY
        }

        val total = red + blue + yellow
        if (validSamples < 30 || total < 25) return null

        // Require enough of the selected area to be a recognizable banner color.
        val coverage = total.toFloat() / validSamples.coerceAtLeast(1)
        if (coverage < 0.22f) return null

        val scores = listOf('A' to red, 'B' to blue, 'X' to yellow)
            .sortedByDescending { it.second }
        val best = scores[0]
        val second = scores[1].second
        val dominance = best.second.toFloat() / total.coerceAtLeast(1)
        val confidence = best.second.toFloat() / validSamples.coerceAtLeast(1)

        // Reject mixed colors, background clutter and uncertain frames.
        if (dominance < 0.80f || best.second < second * 2.4f || confidence < 0.16f) {
            return null
        }
        return Detection(best.first, confidence, red, blue, yellow)
    }
}
