package com.example.footballstudiotracker

import android.content.SharedPreferences
import android.media.Image
import kotlin.math.max

/**
 * Experimental RGB reader. It samples the configured horizontal result strip.
 * Coordinates are percentages of the captured screen and must be calibrated
 * against the actual Football Studio page on the user's device.
 */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): List<Char>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride

        val yPercent = prefs.getInt("scan_y", 475).coerceIn(50, 950) / 1000f
        val xStart = prefs.getInt("scan_x_start", 0).coerceIn(0, 800) / 1000f
        val xEnd = prefs.getInt("scan_x_end", 940).coerceIn(200, 1000) / 1000f
        val count = prefs.getInt("scan_count", 7).coerceIn(3, 12)
        if (xEnd <= xStart) return null

        val yCenter = (height * yPercent).toInt().coerceIn(0, height - 1)
        val left = (width * xStart).toInt().coerceIn(0, width - 1)
        val right = (width * xEnd).toInt().coerceIn(left + 1, width - 1)
        val result = ArrayList<Char>(count)

        for (slot in 0 until count) {
            val cx = (left + (right - left) * (slot + 0.5f) / count).toInt()
            var red = 0
            var blue = 0
            var yellow = 0
            var samples = 0

            // Each chevron has a narrow colored vertical marker near its center.
            // Sample a narrow column across the marker instead of averaging the gray arrow body.
            for (dy in -16..16 step 2) {
                val y = (yCenter + dy).coerceIn(0, height - 1)
                for (dx in -5..5 step 2) {
                    val x = (cx + dx).coerceIn(0, width - 1)
                    val index = y * rowStride + x * pixelStride
                    if (index < 0 || index + 2 >= buffer.limit()) continue
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    samples++

                    when {
                        r >= 105 && r > g * 1.28f && r > b * 1.22f -> red++
                        b >= 90 && b > r * 1.18f && b > g * 1.08f -> blue++
                        r >= 130 && g >= 90 && b <= 165 && r > b * 1.12f && g > b * 1.08f -> yellow++
                    }
                }
            }

            val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
            val winner = scores.firstOrNull() ?: return null
            val threshold = max(5, (samples * 0.12f).toInt())
            val runnerUp = scores.getOrNull(1)?.second ?: 0
            if (winner.second < threshold || winner.second < runnerUp * 1.12f) return null
            result.add(winner.first)
        }
        return result.takeIf { it.size == count }
    }
}
