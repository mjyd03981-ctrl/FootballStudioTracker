# Football Studio Tracker v2.5.8

Based on v2.5.7. Preserves the nine-result persistent A/B alert (X draws are ignored and do not break the streak; the alert continues until the opposite A/B result).

## Numbered results
- Floating result ribbon shows each tile's chronological result number in white.
- Saved results in the app also show the same number in white inside each colored tile.
- Exported PNG grid includes the same white numbers.
- Clearing the history clears the result counter too, so the next result is numbered 1.
- Correcting a result does not change its number.

All other app behavior is retained from v2.5.7.
