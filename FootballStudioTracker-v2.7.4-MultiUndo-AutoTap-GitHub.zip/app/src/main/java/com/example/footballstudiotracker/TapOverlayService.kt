package com.example.footballstudiotracker

import android.app.AlertDialog
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class TapOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var seconds = 30L
    private var tapsPerCycle = 1
    private var cycles = 0 // 0 = continuous
    private var completedCycles = 0
    private val task = object : Runnable {
        override fun run() {
            if (!running) return
            performCycle(0)
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "TAP"; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC1769AA.toInt()); setStroke(2, Color.WHITE) }
            elevation = 12f
        }
        val lp = WindowManager.LayoutParams(58, 58, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 40; y = 300
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true; if(moved){lp.x=(ox+dx).coerceAtLeast(0);lp.y=(oy+dy).coerceAtLeast(0);wm.updateViewLayout(b,lp)};return true }
                    MotionEvent.ACTION_UP -> { if(moved){getSharedPreferences("tracker",0).edit().putInt("tap_x",lp.x).putInt("tap_y",lp.y).apply()} else showSettings(); return true }
                }; return true
            }
        })
        lp.x=getSharedPreferences("tracker",0).getInt("tap_x",40); lp.y=getSharedPreferences("tracker",0).getInt("tap_y",300)
        wm.addView(b,lp); bubble=b; params=lp
    }
    private fun showSettings() {
        val prefs=getSharedPreferences("tracker",0)
        val input=EditText(this).apply { inputType=2; setText(seconds.toString()); hint="الفاصل بالثواني" }
        val taps=EditText(this).apply { inputType=2; setText(tapsPerCycle.toString()); hint="عدد الضغطات بكل دورة" }
        val repeat=EditText(this).apply { inputType=2; setText(cycles.toString()); hint="عدد الدورات (0 مستمر)" }
        val box=LinearLayout(this).apply { orientation=1; setPadding(40,10,40,0); addView(input);addView(taps);addView(repeat) }
        val dialog=AlertDialog.Builder(this).setTitle("إعداد الضغط التلقائي")
            .setMessage("حرّك زر TAP إلى موقع الضغط المطلوب. فعّل خدمة إمكانية الوصول من إعدادات الجهاز.")
            .setView(box).setPositiveButton("حفظ") { _,_ ->
                seconds=(input.text.toString().toLongOrNull()?:30L).coerceIn(1,86400)
                tapsPerCycle=(taps.text.toString().toIntOrNull()?:1).coerceIn(1,20)
                cycles=(repeat.text.toString().toIntOrNull()?:0).coerceAtLeast(0)
                if(AutoTapAccessibilityService.instance==null){
                    Toast.makeText(this,"فعّل خدمة إمكانية الوصول أولاً",Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else { running=true; completedCycles=0; handler.removeCallbacks(task); handler.post(task); Toast.makeText(this,"بدأ الضغط التلقائي",Toast.LENGTH_SHORT).show() }
            }.setNeutralButton("إيقاف") { _,_ -> running=false; handler.removeCallbacks(task); Toast.makeText(this,"تم إيقاف الضغط التلقائي",Toast.LENGTH_SHORT).show() }
            .setNegativeButton("إغلاق",null).create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.show(); dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }
    private fun performCycle(index:Int) {
        if(!running) return
        if(index>=tapsPerCycle){ completedCycles++; if(cycles>0 && completedCycles>=cycles){running=false;return}; handler.postDelayed(task,seconds*1000); return }
        val b=bubble; val lp=params
        val x=(lp?.x?:40)+29f; val y=(lp?.y?:300)+29f
        // Temporarily remove the overlay so the gesture reaches the app underneath.
        try { if(b!=null) wm.removeView(b) } catch (_:Exception) {}
        handler.postDelayed({
            val service=AutoTapAccessibilityService.instance
            if(service==null){running=false;Toast.makeText(this,"خدمة إمكانية الوصول غير مفعّلة",Toast.LENGTH_LONG).show();restoreBubble();return@postDelayed}
            service.tap(x,y) {
                handler.postDelayed({ restoreBubble(); handler.postDelayed({performCycle(index+1)},180) },120)
            }
        },120)
    }
    private fun restoreBubble(){ try { bubble?.let { if(it.parent==null) wm.addView(it,params) } } catch (_:Exception) {} }
    override fun onDestroy(){ running=false;handler.removeCallbacksAndMessages(null);try{bubble?.let{wm.removeView(it)}}catch(_:Exception){};bubble=null;super.onDestroy() }
}
