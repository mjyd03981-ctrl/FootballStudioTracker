plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.footballstudiotracker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.footballstudiotracker"
        minSdk = 26
        targetSdk = 35
        versionCode = 40
        versionName = "2.7.4"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
