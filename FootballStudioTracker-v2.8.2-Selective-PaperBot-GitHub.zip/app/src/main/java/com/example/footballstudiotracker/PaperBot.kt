package com.example.footballstudiotracker

import android.content.SharedPreferences

/** Selective paper-only predictor. It never places or submits real bets. */
object PaperBot {
    private const val KEY_ENABLED = "paper_bot_enabled"
    private const val KEY_LAST_SEEN = "paper_bot_last_seen_count"
    private const val KEY_PENDING = "paper_bot_pending_prediction"
    private const val KEY_SIGNALS = "paper_bot_signals"
    private const val KEY_WINS = "paper_bot_wins"
    private const val KEY_LOSSES = "paper_bot_losses"
    private const val KEY_SKIPPED = "paper_bot_skipped_rounds"
    private const val KEY_WAITS = "paper_bot_wait_rounds"
    private const val KEY_LAST_SIGNAL = "paper_bot_last_signal"
    private const val MIN_SUPPORT = 0.60
    private val WINDOWS = intArrayOf(10, 20, 50)

    data class Snapshot(
        val enabled: Boolean,
        val signals: Int,
        val wins: Int,
        val losses: Int,
        val skipped: Int,
        val waits: Int,
        val pending: Char?,
        val lastSignal: Char?
    ) {
        val settled: Int get() = wins + losses
        val accuracy: Int get() = if (settled == 0) 0 else (wins * 100.0 / settled).toInt()
    }

    fun start(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit().putBoolean(KEY_ENABLED, true).putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING).putString(KEY_LAST_SIGNAL, "").apply()
    }

    fun stop(prefs: SharedPreferences) { prefs.edit().putBoolean(KEY_ENABLED, false).apply() }

    fun reset(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit().putBoolean(KEY_ENABLED, false).putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING).putInt(KEY_SIGNALS, 0).putInt(KEY_WINS, 0)
            .putInt(KEY_LOSSES, 0).putInt(KEY_SKIPPED, 0).putInt(KEY_WAITS, 0)
            .putString(KEY_LAST_SIGNAL, "").apply()
    }

    /** Process newly appended results in chronological order; storedResults is oldest-first. */
    fun observe(prefs: SharedPreferences, totalCount: Long, storedResults: String) {
        if (!prefs.getBoolean(KEY_ENABLED, false)) return
        val lastSeen = prefs.getLong(KEY_LAST_SEEN, totalCount)
        val delta = totalCount - lastSeen
        if (delta <= 0L) return

        if (delta > storedResults.length.toLong()) {
            prefs.edit().putInt(KEY_SKIPPED, prefs.getInt(KEY_SKIPPED, 0) + delta.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                .remove(KEY_PENDING).putLong(KEY_LAST_SEEN, totalCount).apply()
            return
        }

        val newResults = storedResults.takeLast(delta.toInt())
        val history = storedResults.dropLast(newResults.length).filter { it == 'A' || it == 'B' }.toMutableList()
        var pending = prefs.getString(KEY_PENDING, "")?.firstOrNull()
        var signals = prefs.getInt(KEY_SIGNALS, 0)
        var wins = prefs.getInt(KEY_WINS, 0)
        var losses = prefs.getInt(KEY_LOSSES, 0)
        var waits = prefs.getInt(KEY_WAITS, 0)
        var lastSignal: Char? = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()

        for (actual in newResults) {
            if (pending == 'A' || pending == 'B') {
                if (actual == pending) wins++ else losses++ // X settles as a loss.
            }
            if (actual == 'A' || actual == 'B') history.add(actual)

            val decision = selectSignal(history)
            if (decision == null) {
                pending = null
                waits++
            } else {
                pending = decision
                lastSignal = decision
                signals++
            }
        }

        val edit = prefs.edit().putInt(KEY_SIGNALS, signals).putInt(KEY_WINS, wins)
            .putInt(KEY_LOSSES, losses).putInt(KEY_WAITS, waits).putLong(KEY_LAST_SEEN, totalCount)
        if (pending == null) edit.remove(KEY_PENDING) else edit.putString(KEY_PENDING, pending.toString())
        if (lastSignal == null) edit.putString(KEY_LAST_SIGNAL, "") else edit.putString(KEY_LAST_SIGNAL, lastSignal.toString())
        edit.apply()
    }

    /** Require >=60% support for the same side in each of the last 10, 20 and 50 A/B results. */
    private fun selectSignal(history: List<Char>): Char? {
        if (history.size < 50) return null
        var allA = true
        var allB = true
        for (window in WINDOWS) {
            val recent = history.takeLast(window)
            val aRate = recent.count { it == 'A' }.toDouble() / window
            if (aRate < MIN_SUPPORT) allA = false
            if (aRate > 1.0 - MIN_SUPPORT) allB = false
        }
        return when { allA -> 'A'; allB -> 'B'; else -> null }
    }

    /** Reset only paper-test counters once when upgrading to selective strategy; preserve result history. */
    fun migrateToSelectiveStrategy(prefs: SharedPreferences, currentCount: Long) {
        if (prefs.getInt("paper_bot_selective_strategy_version", 0) >= 1) return
        prefs.edit().putBoolean(KEY_ENABLED, false).putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING).putInt(KEY_SIGNALS, 0).putInt(KEY_WINS, 0)
            .putInt(KEY_LOSSES, 0).putInt(KEY_SKIPPED, 0).putInt(KEY_WAITS, 0)
            .putString(KEY_LAST_SIGNAL, "").putInt("paper_bot_selective_strategy_version", 1).apply()
    }

    fun snapshot(prefs: SharedPreferences): Snapshot = Snapshot(
        enabled = prefs.getBoolean(KEY_ENABLED, false),
        signals = prefs.getInt(KEY_SIGNALS, 0),
        wins = prefs.getInt(KEY_WINS, 0),
        losses = prefs.getInt(KEY_LOSSES, 0),
        skipped = prefs.getInt(KEY_SKIPPED, 0),
        waits = prefs.getInt(KEY_WAITS, 0),
        pending = prefs.getString(KEY_PENDING, "")?.firstOrNull(),
        lastSignal = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()
    )
}
