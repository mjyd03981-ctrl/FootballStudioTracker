# Football Studio Tracker v2.8.0

Built from the user's saved v2.7.5 baseline. Changes in this version are limited to alarm configuration and game-stop alert:

- Streak alert threshold is configurable from 1 through 15.
- Red (A) and blue (B) streaks are tracked independently; yellow draws (X) are ignored and do not break a streak.
- Once the configured streak threshold is reached, the existing persistent triple-burst alarm continues until the opposite A/B result arrives.
- Independent game-stop alert: configurable from 10 to 60 seconds, with enable/disable and three selectable tone patterns.
- Added an "إعدادات الإنذارات" entry in the main screen.
- Preserves the existing v2.7.5 manual result editing, multi-undo, logo, capture, and export features.
- No Accessibility service or Accessibility permission is added.

Build using the included GitHub Actions workflow. A local APK build was not verified in this environment because Gradle is unavailable.


## v2.7.7
- Added independent move/fix mode for the history result ribbon.
- Use the floating controls menu item "تحريك / تثبيت شريط النتائج" to toggle movement. Drag the ribbon and toggle again to lock it. Position is saved.
- Existing v2.7.6 alarm settings and prior features are retained.


## v2.7.8 — Unified 100-step undo
- Undo history now includes both manual edits and automatically detected A/B/X results.
- Every new result detection saves a snapshot before writing the result.
- One Undo press restores exactly one prior state; the shared history retains the latest 100 changes.
- Existing manual undo history is migrated into the unified history on app launch.


## v2.7.9 — Paper Bot (simulation only)
- Added a simulation-only Football Studio predictor panel.
- The bot observes newly recorded results and tests a simple baseline: repeat the most recent non-draw A/B result.
- It tracks virtual predictions, wins, losses, accuracy, and skipped rounds. Draw X settles a pending Home/Away prediction as incorrect.
- The bot does not connect to 1xBet, access accounts, submit bets, or handle money.
- Start the test from the main screen button “البوت التجريبي — بدون رهان حقيقي”.
- Existing result history and the 100-step undo feature are retained. No historical database is modified.
- The strategy is a baseline for evaluation only; prior out-of-sample testing did not establish a reliable predictive edge.


## v2.8.0 — Paper Bot sequence and background-processing fix
- PaperBot now processes every newly appended result in chronological order, including multiple results accumulated while the app UI is in the background, provided the new results are still present in the retained history.
- Corrected the prediction timing: after observing a result, the bot now prepares the next-round prediction from the latest known non-draw A/B result.
- If a count gap is larger than the retained result history, the bot safely records a skipped gap rather than inventing outcomes.
- Paper-test statistics are reset once on first launch of v2.8.0 because the previous counter mixed a sequence gap and an off-by-one prediction timing issue. The user's saved result history is not reset or modified by this migration.
- Simulation only; no 1xBet integration or real betting.


## v2.8.1 — Compact live sensor region
- Resizes the default sensor to the compact centered banner region (45% screen width).
- Aligns the visible overlay and sampled color region to the same normalized bounds.
- One-time migration replaces the previous oversized saved region; future manual selections are preserved.
- Paper-bot and result history behavior are otherwise unchanged.

## v2.8.2 — Selective paper signals (experimental)
- Replaces the always-repeat-last-result baseline with a selective filter.
- The bot issues a Home/Away paper signal only when the last 10, 20 and 50 non-draw A/B results all show at least 60% support for the same side. Otherwise it records a WAIT decision.
- Adds a separate WAIT counter to distinguish deliberate waits from sequence gaps.
- The pending signal is settled by the next observed result; a draw X is counted as a loss for a pending A/B signal and is excluded from the A/B rolling windows.
- One-time migration resets only paper-bot counters and leaves the saved result history untouched.
- Important: a historical chronological holdout check of this filter on the saved 5,231-round dataset produced 85 signals and 47.1% accuracy in the final test segment. This is not evidence of an edge; the filter is for transparent paper evaluation only and must not be used as a real-betting signal.
