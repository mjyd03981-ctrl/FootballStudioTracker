package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_SELECT_REGION = "select_region"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var previous: List<Char?>? = null
    private var pendingSequence: List<Char?>? = null
    private var pendingSequenceFrames = 0
    private var lastAcceptedAt = 0L
    private var bannerCandidate: Char? = null
    private var bannerCandidateFrames = 0
    private var bannerNeutralFrames = 0
    private var bannerNeutralSince = 0L
    private var bannerLatched = false
    private var bannerLastResult: Char? = null
    private var windowManager: WindowManager? = null
    private var floatingView: LinearLayout? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private var floatingAction: TextView? = null
    private var floatingActionParams: WindowManager.LayoutParams? = null
    private var floatingToolbar: LinearLayout? = null
    private var floatingToolbarParams: WindowManager.LayoutParams? = null
    private var toolbarVisible = true
    private var floatingMenu: LinearLayout? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    private var regionSelector: RegionSelectorOverlay? = null
    private var selectingRegion = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data, intent?.getBooleanExtra(EXTRA_SELECT_REGION, false) == true)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent, selectRegion: Boolean) {
        migrateResultOrderIfNeeded()
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        captureWidth = width
        captureHeight = height
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    if (!selectingRegion) {
                        val detected = BannerAnnouncementReader.detect(image, prefs)
                        processBannerDetection(detected?.result)
                    }
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        showFloatingIndicator()
        if (selectRegion) showRegionSelector(width, height)
    }

    private fun showRegionSelector(width: Int, height: Int) {
        selectingRegion = true
        regionSelector?.dismiss()
        regionSelector = RegionSelectorOverlay(
            this, getSystemService(WINDOW_SERVICE) as WindowManager, width, height,
            onSave = { left, top, right, bottom ->
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .putInt("region_left", left).putInt("region_top", top)
                    .putInt("region_right", right).putInt("region_bottom", bottom)
                    .putBoolean("region_custom", true).apply()
                selectingRegion = false
                previous = null
                pendingSequence = null
                pendingSequenceFrames = 0
                bannerCandidate = null
                bannerCandidateFrames = 0
                bannerNeutralFrames = 0
                bannerNeutralSince = 0L
                bannerLatched = false
                bannerLastResult = null
                lastAcceptedAt = 0L
                updateFloatingStatus("تم حفظ منطقة إعلان النتيجة")
            },
            onCancel = {
                selectingRegion = false
                updateFloatingStatus("اختيار المنطقة ألغي")
            }
        ).also { it.show() }
    }


    private fun migrateResultOrderIfNeeded() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("banner_reader_v19", false)) {
            // v1.8 stored a rectangle for the history-arrow strip; v1.9 uses the
            // announcement banner, so discard the incompatible old rectangle.
            prefs.edit().remove("region_left").remove("region_top")
                .remove("region_right").remove("region_bottom")
                .putBoolean("banner_reader_v19", true).apply()
        }
        if (!prefs.getBoolean("newest_first_v15", false)) {
            val old = prefs.getString("results", "") ?: ""
            prefs.edit()
                .putString("results", old.reversed())
                .putBoolean("newest_first_v15", true)
                .apply()
        }
        if (!prefs.getBoolean("scan_count_custom", false)) {
            prefs.edit().putInt("scan_count", 7).apply()
        }
    }

    private fun updateFloatingStatus(message: String) {
        mainHandler.post {
            // Keep the result strip intact; show status separately as a short toast.
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /** One result per visible announcement. A stable colored banner is latched until it disappears. */
    private fun processBannerDetection(result: Char?) {
        if (result == null) {
            bannerCandidate = null
            bannerCandidateFrames = 0
            bannerNeutralFrames++
            if (bannerNeutralSince == 0L) bannerNeutralSince = android.os.SystemClock.elapsedRealtime()
            if (bannerNeutralFrames >= 8 && android.os.SystemClock.elapsedRealtime() - bannerNeutralSince >= 900L) {
                bannerLatched = false
                bannerLastResult = null
            }
            return
        }

        bannerNeutralFrames = 0
        bannerNeutralSince = 0L
        if (bannerCandidate == result) bannerCandidateFrames++ else {
            bannerCandidate = result
            bannerCandidateFrames = 1
        }
        // Four consecutive frames (~0.4-0.8s depending on device) avoid transient flashes.
        if (bannerCandidateFrames < 4) return

        if (bannerLatched) {
            // A different, stable announcement can be accepted as the next round only
            // after a neutral gap; do not turn color flicker into duplicate outcomes.
            return
        }

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastAcceptedAt < 2500L) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val newestFirst = prefs.getString("results", "") ?: ""
        // Newest result is prepended, so it appears at the left in the LTR result strip.
        val updated = (result + newestFirst).take(1000)
        prefs.edit().putString("results", updated).apply()
        bannerLatched = true
        bannerLastResult = result
        lastAcceptedAt = now
        updateFloatingIndicator(updated)
        updateFloatingStatus(when (result) {
            'A' -> "تم رصد فوز الفريق المضيف — A"
            'B' -> "تم رصد فوز الفريق الضيف — B"
            else -> "تم رصد التعادل — X"
        })
    }

    @Suppress("DEPRECATION")
    private fun showFloatingIndicator() {
        if (!Settings.canDrawOverlays(this) || floatingView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val initial = prefs.getString("results", "") ?: ""
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(9, 7, 9, 7)
            alpha = 0.84f
            elevation = 12f
            background = GradientDrawable().apply {
                setColor(Color.argb(178, 12, 19, 30))
                cornerRadius = 18f
                setStroke(1, Color.argb(105, 255, 255, 255))
            }
        }
        floatingView = panel
        renderFloatingTiles(initial)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(10)
            y = dp(170)
        }
        panel.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var downX = 0f
            private var downY = 0f
            private var moved = false
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        downX = event.rawX
                        downY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downX
                        val dy = event.rawY - downY
                        if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                        params.x = (startX + dx.toInt()).coerceIn(0, (captureWidth - view.width).coerceAtLeast(0))
                        params.y = (startY + dy.toInt()).coerceIn(0, (captureHeight - view.height).coerceAtLeast(0))
                        try { windowManager?.updateViewLayout(view, params) } catch (_: Exception) { }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) toggleFloatingMenu()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return true
            }
        })
        try {
            windowManager?.addView(panel, params)
            floatingParams = params
        } catch (_: Exception) {
            floatingView = null
        }
        showFloatingActionButton(type)
    }

    @Suppress("DEPRECATION")
    private fun showFloatingActionButton(type: Int) {
        if (floatingAction != null || windowManager == null) return

        // Restore the compact translucent floating control. Tap opens the detail menu.
        val button = TextView(this).apply {
            text = "●"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(65, 145, 255))
            alpha = 0.78f
            elevation = dp(8).toFloat()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(112, 12, 20, 32))
                setStroke(dp(1), Color.argb(125, 210, 225, 245))
            }
            contentDescription = "فتح تفاصيل المراقبة"
        }
        val size = dp(48)
        val params = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(270)
        }
        button.setOnTouchListener(object : View.OnTouchListener {
            private var sx = 0
            private var sy = 0
            private var dx = 0f
            private var dy = 0f
            private var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = params.x; sy = params.y; dx = e.rawX; dy = e.rawY; moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = e.rawX - dx; val my = e.rawY - dy
                        if (kotlin.math.abs(mx) > dp(5) || kotlin.math.abs(my) > dp(5)) moved = true
                        params.x = (sx + mx.toInt()).coerceIn(0, (captureWidth - size).coerceAtLeast(0))
                        params.y = (sy + my.toInt()).coerceIn(0, (captureHeight - size).coerceAtLeast(0))
                        try { windowManager?.updateViewLayout(v, params) } catch (_: Exception) { }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) toggleFloatingMenu()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return true
            }
        })
        try {
            windowManager?.addView(button, params)
            floatingAction = button
            floatingActionParams = params
        } catch (_: Exception) { floatingAction = null }
    }

    @Suppress("DEPRECATION")
    private fun toggleFloatingMenu() {
        if (floatingMenu != null) { removeFloatingMenu(); return }
        val wm = windowManager ?: return
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(242, 16, 25, 42)); cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        fun menuButton(label: String, action: () -> Unit) {
            menu.addView(TextView(this).apply {
                text = label; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(dp(12), dp(11), dp(12), dp(11))
                isClickable = true
                setOnClickListener { removeFloatingMenu(); action() }
            }, LinearLayout.LayoutParams(dp(170), -2))
        }
        menuButton("تحديد منطقة إعلان النتيجة") { showRegionSelector(captureWidth, captureHeight) }
        menuButton("إخفاء / إظهار شريط النتائج") {
            floatingView?.visibility = if (floatingView?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        menuButton("إيقاف المراقبة") { stopSelf() }
        menuButton("إغلاق القائمة") { }
        val anchor = floatingActionParams
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((anchor?.x ?: dp(12)) + dp(58)).coerceAtMost((captureWidth - dp(180)).coerceAtLeast(0))
            y = (anchor?.y ?: dp(250)).coerceAtMost((captureHeight - dp(160)).coerceAtLeast(0))
        }
        try { wm.addView(menu, params); floatingMenu = menu } catch (_: Exception) { floatingMenu = null }
    }

    private fun removeFloatingMenu() {
        try { floatingMenu?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        floatingMenu = null
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun renderFloatingTiles(values: String) {
        val panel = floatingView ?: return
        panel.removeAllViews()
        // Stored order is newest-first. In LTR layout, the newest tile is at the LEFT.
        values.take(8).forEach { result ->
            val tile = TextView(this).apply {
                text = result.toString()
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(when (result) {
                        'A' -> Color.rgb(205, 35, 45)   // A: red
                        'B' -> Color.rgb(30, 90, 220)   // B: blue
                        else -> Color.rgb(232, 184, 32)  // X: yellow
                    })
                    cornerRadius = 6f
                    setStroke(1, Color.argb(120, 255, 255, 255))
                }
                alpha = 0.96f
            }
            val size = (36 * resources.displayMetrics.density).toInt()
            val margin = (3 * resources.displayMetrics.density).toInt()
            panel.addView(tile, LinearLayout.LayoutParams(size, size).apply {
                leftMargin = margin
                rightMargin = margin
            })
        }
        if (values.isEmpty()) {
            panel.addView(TextView(this).apply {
                text = "بانتظار النتائج"
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(5, 0, 5, 0)
            })
        }
        // Put REC on the RIGHT so it never pushes the newest result away from the left edge.
        panel.addView(TextView(this).apply {
            text = "● REC"
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(7, 0, 3, 0)
        })
    }

    // Android Views must only be changed on the main/UI thread.
    private fun updateFloatingIndicator(values: String) {
        mainHandler.post {
            if (floatingView != null) renderFloatingTiles(values)
        }
    }

    private fun removeFloatingIndicator() {
        removeFloatingMenu()
        try { floatingToolbar?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        floatingToolbar = null
        floatingToolbarParams = null
        try { floatingView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        try { floatingAction?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        floatingView = null
        floatingParams = null
        floatingAction = null
        floatingActionParams = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("مشاركة الشاشة وقراءة شريط النتائج مفعّلة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        regionSelector?.dismiss()
        regionSelector = null
        removeFloatingIndicator()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
