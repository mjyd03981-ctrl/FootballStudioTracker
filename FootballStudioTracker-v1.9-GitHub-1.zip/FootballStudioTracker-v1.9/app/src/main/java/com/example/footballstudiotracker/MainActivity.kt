package com.example.footballstudiotracker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStreamWriter

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_CAPTURE = 4102
        private const val REQUEST_OVERLAY = 4103
        private const val REQUEST_EXPORT = 4104
    }

    private lateinit var status: TextView
    private lateinit var strip: LinearLayout
    private lateinit var history: TextView
    private var pendingRegionSelection = false
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            renderSavedResults()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        migrateResultOrderIfNeeded()
        buildUi()
        renderSavedResults()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun migrateResultOrderIfNeeded() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("banner_reader_v19", false)) {
            prefs.edit().remove("region_left").remove("region_top")
                .remove("region_right").remove("region_bottom")
                .putBoolean("banner_reader_v19", true).apply()
        }
        if (!prefs.getBoolean("newest_first_v15", false)) {
            val old = prefs.getString("results", "") ?: ""
            prefs.edit().putString("results", old.reversed())
                .putBoolean("newest_first_v15", true).apply()
        }
        if (!prefs.getBoolean("scan_count_custom", false)) {
            prefs.edit().putInt("scan_count", 7).apply()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(Color.rgb(14, 22, 38))
        }
        val title = TextView(this).apply {
            text = "FOOTBALL STUDIO TRACKER"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        status = TextView(this).apply {
            text = "متوقف — اضغط بدء المراقبة"
            textSize = 14f
            setTextColor(Color.rgb(180, 195, 215))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "بدء مراقبة الشاشة"
            setOnClickListener { checkOverlayThenCapture() }
        }
        val stop = Button(this).apply {
            text = "إيقاف المراقبة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "المراقبة متوقفة"
                renderSavedResults()
            }
        }
        val selectRegion = Button(this).apply {
            text = "تحديد منطقة إعلان النتيجة"
            setOnClickListener { checkOverlayThenCapture(selectRegion = true) }
        }
        val calibrate = Button(this).apply {
            text = "معايرة يدوية متقدمة"
            setOnClickListener { showCalibrationDialog() }
        }
        val export = Button(this).apply {
            text = "حفظ السجل CSV"
            setOnClickListener { createCsvDocument() }
        }
        val reset = Button(this).apply {
            text = "مسح السجل"
            setOnClickListener {
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .remove("results").remove("baseline").apply()
                renderSavedResults()
            }
        }
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 14)
        }
        val gridTitle = TextView(this).apply {
            text = "شبكة النتائج — الأحدث يساراً والأقدم يميناً"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 4)
        }
        history = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        }
        val note = TextView(this).apply {
            text = "طريقة القراءة الجديدة: يراقب إعلان النتيجة أعلى منتصف البث. الأحمر (الفريق المضيف) = A، الأزرق (الفريق الضيف) = B، والذهبي (اسحب) = X. يسجل الإعلان مرة واحدة بعد ثباته، ثم ينتظر اختفاءه قبل تسجيل إعلان جديد. حدّد إطاراً ضيقاً حول شريط الإعلان فقط."
            textSize = 13f
            setTextColor(Color.rgb(180, 195, 215))
            setPadding(0, 18, 0, 0)
        }
        listOf(title, status, start, stop, selectRegion, calibrate, export, reset, gridTitle, strip, history, note).forEach { root.addView(it) }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }


    private fun showCalibrationDialog() {
        AlertDialog.Builder(this)
            .setTitle("معايرة إعلان النتيجة")
            .setMessage("القراءة الجديدة تراقب شريط الإعلان أعلى منتصف اللعبة: الأحمر (الفريق المضيف) = A، الأزرق (الفريق الضيف) = B، والذهبي (اسحب) = X. اضغط تحديد المنطقة، ثم ضع الإطار حول شريط الإعلان فقط واحفظه.")
            .setNegativeButton("إغلاق", null)
            .setPositiveButton("تحديد المنطقة") { _, _ -> checkOverlayThenCapture(selectRegion = true) }
            .show()
    }

    private fun checkOverlayThenCapture(selectRegion: Boolean = false) {
        pendingRegionSelection = selectRegion
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح للتطبيق بالظهور فوق التطبيقات لإظهار مؤشر المراقبة", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY -> if (Settings.canDrawOverlays(this)) requestScreenCapture()
            REQUEST_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                    putExtra(CaptureService.EXTRA_SELECT_REGION, pendingRegionSelection)
                }
                startForegroundService(service)
                status.text = if (pendingRegionSelection) "حدد شريط النتائج بالإطار الشفاف ثم اضغط حفظ المنطقة" else "المراقبة تعمل — المؤشر العائم يظهر فوق اللعبة"
                pendingRegionSelection = false
            }
            REQUEST_EXPORT -> if (resultCode == RESULT_OK && data?.data != null) exportCsv(data.data!!)
        }
    }

    private fun createCsvDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "football-studio-results.csv")
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    private fun exportCsv(uri: Uri) {
        val values = getSharedPreferences("tracker", Context.MODE_PRIVATE).getString("results", "") ?: ""
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                OutputStreamWriter(stream, Charsets.UTF_8).use { writer ->
                    writer.write("number,result,color\n")
                    values.forEachIndexed { index, value ->
                        val color = when (value) { 'A' -> "red"; 'B' -> "blue"; else -> "yellow_draw" }
                        writer.write("${index + 1},$value,$color\n")
                    }
                }
            } ?: throw IllegalStateException("تعذر فتح الملف")
            Toast.makeText(this, "تم حفظ السجل", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ السجل: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderSavedResults() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val values = prefs.getString("results", "") ?: ""
        strip.removeAllViews()

        // Stored newest-first to mirror the live Evolution strip (newest at LEFT).
        val newestFirst = values.take(500).toList()
        if (newestFirst.isEmpty()) {
            strip.addView(TextView(this).apply {
                text = "ستظهر النتائج هنا بعد اكتشافها"
                setTextColor(Color.LTGRAY)
                setPadding(8, 18, 8, 18)
            })
        } else {
            newestFirst.chunked(10).forEachIndexed { rowIndex, row ->
                val rowLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
                    gravity = Gravity.CENTER
                }
                row.forEachIndexed { columnIndex, ch ->
                    val newestFirstIndex = rowIndex * 10 + columnIndex
                    val tile = TextView(this).apply {
                        text = ch.toString()
                        textSize = 15f
                        gravity = Gravity.CENTER
                        setTextColor(Color.WHITE)
                        background = android.graphics.drawable.GradientDrawable().apply {
                            setColor(when (ch) {
                                'A' -> Color.rgb(205, 48, 55)
                                'B' -> Color.rgb(30, 90, 220)
                                else -> Color.rgb(222, 177, 28)
                            })
                            cornerRadius = 7f
                            setStroke(1, Color.argb(90, 255, 255, 255))
                        }
                        contentDescription = when (ch) {
                            'A' -> "أحمر A"
                            'B' -> "أزرق B"
                            else -> "تعادل X أصفر"
                        }
                        setOnClickListener { showCorrectionDialog(newestFirstIndex, ch) }
                    }
                    val size = (resources.displayMetrics.widthPixels / resources.displayMetrics.density / 10f - 9f)
                        .toInt().coerceIn(25, 42)
                    val lp = LinearLayout.LayoutParams(0, size, 1f)
                    lp.setMargins(2, 3, 2, 3)
                    rowLayout.addView(tile, lp)
                }
                while (rowLayout.childCount < 10) {
                    rowLayout.addView(android.view.View(this), LinearLayout.LayoutParams(0, 1, 1f))
                }
                strip.addView(rowLayout)
            }
        }

        val counts = values.take(500).groupingBy { it }.eachCount()
        history.text = "المجموع المحفوظ: ${values.length}  |  المعروض: ${newestFirst.size}\nA أحمر: ${counts['A'] ?: 0}   B أزرق: ${counts['B'] ?: 0}   X أصفر: ${counts['X'] ?: 0}\nالأحدث أقصى اليسار — اضغط على أي مربع لتصحيح النتيجة."
        status.text = if (prefs.getBoolean("monitoring", false)) "المراقبة تعمل" else "متوقف — اضغط بدء المراقبة"
    }

    private fun showCorrectionDialog(latestIndex: Int, current: Char) {
        val choices = arrayOf("A — أحمر", "B — أزرق", "X — أصفر / تعادل")
        val selected = when (current) { 'A' -> 0; 'B' -> 1; else -> 2 }
        AlertDialog.Builder(this)
            .setTitle("تصحيح النتيجة")
            .setSingleChoiceItems(choices, selected) { dialog, which ->
                val replacement = when (which) { 0 -> 'A'; 1 -> 'B'; else -> 'X' }
                val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                val old = prefs.getString("results", "") ?: ""
                val index = latestIndex
                if (index in old.indices) {
                    val updated = old.toCharArray()
                    updated[index] = replacement
                    prefs.edit().putString("results", String(updated)).apply()
                    Toast.makeText(this, "تم تصحيح النتيجة إلى $replacement", Toast.LENGTH_SHORT).show()
                    renderSavedResults()
                }
                dialog.dismiss()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
