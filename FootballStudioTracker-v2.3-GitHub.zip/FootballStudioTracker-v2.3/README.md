# Football Studio Tracker v2.3

Android/Kotlin screen-color sensor prototype.

## v2.3 changes
- Removed the old floating REC/control button; the only overlay is the transparent, movable/resizable sensor frame and the Android screen-capture notification.
- Reworked color sampling to count saturated red, blue, and yellow pixels inside the selected sensor region, while ignoring most moving background pixels.
- Added an event gate: a neutral/empty sensor reading arms the detector; a colored marker must remain stable for five frames; after recording, the detector disarms until the sensor region returns to neutral. This prevents repeated logging while one marker remains visible.
- The result list displays newest first at the far left; storage remains chronological for CSV export.

## How to use
1. Build and install the APK from GitHub Actions.
2. Open the app and grant screen-capture and display-over-other-apps permissions.
3. Tap **تحديد مربع حساس اللون**.
4. Move/resize the blue frame so it covers the small history tile/marker, not the full game video. Save it.
5. Start monitoring. The sensor records A (red), B (blue), and X (yellow) once per visible color event.

## Important limitation
A single small sensor region can only detect a new event if the watched tile visibly changes or returns to a neutral state between events. If two consecutive results look identical in exactly the same pixels and no neutral/transition frame is captured, one region cannot distinguish them reliably. Adjust the frame to include the marker's movement/empty area if needed. This is a prototype and requires live-stream calibration.
