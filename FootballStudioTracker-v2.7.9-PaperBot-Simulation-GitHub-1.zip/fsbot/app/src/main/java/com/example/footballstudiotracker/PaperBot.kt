package com.example.footballstudiotracker

import android.content.SharedPreferences

/** Simulation-only predictor. It never places or submits real bets. */
object PaperBot {
    private const val KEY_ENABLED = "paper_bot_enabled"
    private const val KEY_LAST_SEEN = "paper_bot_last_seen_count"
    private const val KEY_PENDING = "paper_bot_pending_prediction"
    private const val KEY_SIGNALS = "paper_bot_signals"
    private const val KEY_WINS = "paper_bot_wins"
    private const val KEY_LOSSES = "paper_bot_losses"
    private const val KEY_SKIPPED = "paper_bot_skipped_rounds"
    private const val KEY_LAST_SIGNAL = "paper_bot_last_signal"

    data class Snapshot(
        val enabled: Boolean,
        val signals: Int,
        val wins: Int,
        val losses: Int,
        val skipped: Int,
        val pending: Char?,
        val lastSignal: Char?
    ) {
        val settled: Int get() = wins + losses
        val accuracy: Int get() = if (settled == 0) 0 else (wins * 100.0 / settled).toInt()
    }

    fun start(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, true)
            .putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING)
            .putString(KEY_LAST_SIGNAL, "")
            .apply()
    }

    fun stop(prefs: SharedPreferences) {
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
    }

    fun reset(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, false)
            .putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING)
            .putInt(KEY_SIGNALS, 0)
            .putInt(KEY_WINS, 0)
            .putInt(KEY_LOSSES, 0)
            .putInt(KEY_SKIPPED, 0)
            .putString(KEY_LAST_SIGNAL, "")
            .apply()
    }

    /** Call whenever the stored result count changes. Stored results are oldest-first. */
    fun observe(prefs: SharedPreferences, totalCount: Long, storedResults: String) {
        if (!prefs.getBoolean(KEY_ENABLED, false)) return
        val lastSeen = prefs.getLong(KEY_LAST_SEEN, totalCount)
        val delta = totalCount - lastSeen
        if (delta <= 0L) return

        val edit = prefs.edit()
        if (delta != 1L || storedResults.isEmpty()) {
            // A gap means we cannot safely align predictions to outcomes; skip rather than invent data.
            edit.putInt(KEY_SKIPPED, prefs.getInt(KEY_SKIPPED, 0) + delta.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                .remove(KEY_PENDING)
                .putLong(KEY_LAST_SEEN, totalCount)
                .apply()
            return
        }

        val actual = storedResults.last()
        val pending = prefs.getString(KEY_PENDING, "")?.firstOrNull()
        if (pending == 'A' || pending == 'B') {
            val key = if (actual == pending) KEY_WINS else KEY_LOSSES
            edit.putInt(key, prefs.getInt(key, 0) + 1)
        }

        // Baseline only: repeat the latest non-draw result. This is for paper testing,
        // not a validated edge or a recommendation to wager.
        val previous = storedResults.dropLast(1).reversed().firstOrNull { it == 'A' || it == 'B' }
        if (previous == 'A' || previous == 'B') {
            edit.putString(KEY_PENDING, previous.toString())
                .putString(KEY_LAST_SIGNAL, previous.toString())
                .putInt(KEY_SIGNALS, prefs.getInt(KEY_SIGNALS, 0) + 1)
        } else {
            edit.remove(KEY_PENDING).putString(KEY_LAST_SIGNAL, "")
        }
        edit.putLong(KEY_LAST_SEEN, totalCount).apply()
    }

    fun snapshot(prefs: SharedPreferences): Snapshot {
        return Snapshot(
            enabled = prefs.getBoolean(KEY_ENABLED, false),
            signals = prefs.getInt(KEY_SIGNALS, 0),
            wins = prefs.getInt(KEY_WINS, 0),
            losses = prefs.getInt(KEY_LOSSES, 0),
            skipped = prefs.getInt(KEY_SKIPPED, 0),
            pending = prefs.getString(KEY_PENDING, "")?.firstOrNull(),
            lastSignal = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()
        )
    }
}
