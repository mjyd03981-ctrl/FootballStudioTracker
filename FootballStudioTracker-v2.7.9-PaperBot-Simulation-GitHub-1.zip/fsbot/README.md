# Football Studio Tracker v2.7.6

Built from the user's saved v2.7.5 baseline. Changes in this version are limited to alarm configuration and game-stop alert:

- Streak alert threshold is configurable from 1 through 15.
- Red (A) and blue (B) streaks are tracked independently; yellow draws (X) are ignored and do not break a streak.
- Once the configured streak threshold is reached, the existing persistent triple-burst alarm continues until the opposite A/B result arrives.
- Independent game-stop alert: configurable from 10 to 60 seconds, with enable/disable and three selectable tone patterns.
- Added an "إعدادات الإنذارات" entry in the main screen.
- Preserves the existing v2.7.5 manual result editing, multi-undo, logo, capture, and export features.
- No Accessibility service or Accessibility permission is added.

Build using the included GitHub Actions workflow. A local APK build was not verified in this environment because Gradle is unavailable.


## v2.7.7
- Added independent move/fix mode for the history result ribbon.
- Use the floating controls menu item "تحريك / تثبيت شريط النتائج" to toggle movement. Drag the ribbon and toggle again to lock it. Position is saved.
- Existing v2.7.6 alarm settings and prior features are retained.


## v2.7.8 — Unified 100-step undo
- Undo history now includes both manual edits and automatically detected A/B/X results.
- Every new result detection saves a snapshot before writing the result.
- One Undo press restores exactly one prior state; the shared history retains the latest 100 changes.
- Existing manual undo history is migrated into the unified history on app launch.


## v2.7.9 — Paper Bot (simulation only)
- Added a simulation-only Football Studio predictor panel.
- The bot observes newly recorded results and tests a simple baseline: repeat the most recent non-draw A/B result.
- It tracks virtual predictions, wins, losses, accuracy, and skipped rounds. Draw X settles a pending Home/Away prediction as incorrect.
- The bot does not connect to 1xBet, access accounts, submit bets, or handle money.
- Start the test from the main screen button “البوت التجريبي — بدون رهان حقيقي”.
- Existing result history and the 100-step undo feature are retained. No historical database is modified.
- The strategy is a baseline for evaluation only; prior out-of-sample testing did not establish a reliable predictive edge.
