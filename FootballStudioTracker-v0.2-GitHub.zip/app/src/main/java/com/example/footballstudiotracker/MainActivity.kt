package com.example.footballstudiotracker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val requestCapture = 4102
    private val requestOverlay = 4103
    private val requestExport = 4104
    private lateinit var status: TextView
    private lateinit var strip: LinearLayout
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderSavedResults()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(Color.rgb(14, 22, 38))
        }
        val title = TextView(this).apply {
            text = "FOOTBALL STUDIO TRACKER"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        status = TextView(this).apply {
            text = "متوقف — اضغط بدء المراقبة"
            textSize = 14f
            setTextColor(Color.rgb(180, 195, 215))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "بدء مراقبة الشاشة"
            setOnClickListener { beginMonitoring() }
        }
        val stop = Button(this).apply {
            text = "إيقاف المراقبة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "المراقبة متوقفة"
                renderSavedResults()
            }
        }
        val export = Button(this).apply {
            text = "حفظ السجل CSV"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/csv"
                    putExtra(Intent.EXTRA_TITLE, "FootballStudioTracker-history.csv")
                }
                startActivityForResult(intent, requestExport)
            }
        }
        val reset = Button(this).apply {
            text = "مسح السجل"
            setOnClickListener {
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .remove("results").remove("records").remove("baseline").apply()
                renderSavedResults()
            }
        }
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        history = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        }
        val note = TextView(this).apply {
            text = "الألوان: A أحمر، B أزرق، X أصفر (تعادل). القراءة آلية تجريبية وتعتمد على موضع شريط النتائج في الشاشة، لذلك راجع النتائج يدوياً. النافذة العائمة تعرض حالة المراقبة وآخر نتيجة فقط."
            textSize = 13f
            setTextColor(Color.rgb(180, 195, 215))
            setPadding(0, 18, 0, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(export)
        root.addView(reset)
        root.addView(strip)
        root.addView(history)
        root.addView(note)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun beginMonitoring() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "اسمح بالظهور فوق التطبيقات ثم ارجع واضغط بدء المراقبة"
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestOverlay)
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Activity result API retained for compatibility with this project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            requestOverlay -> status.text = if (Settings.canDrawOverlays(this))
                "تم السماح بالنافذة العائمة — اضغط بدء المراقبة" else "لم يتم منح صلاحية النافذة العائمة"
            requestCapture -> if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                startForegroundService(service)
                status.text = "المراقبة تعمل"
            }
            requestExport -> if (resultCode == RESULT_OK && data != null) exportCsv(data)
        }
    }

    private fun exportCsv(uri: Uri) {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val records = prefs.getString("records", "") ?: ""
        val output = buildString {
            append("time,result\n")
            records.lines().filter { it.contains("|") }.forEach { line ->
                val parts = line.split("|", limit = 2)
                if (parts.size == 2) {
                    val time = parts[0].toLongOrNull()?.let {
                        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(it))
                    } ?: parts[0]
                    append(time).append(",").append(parts[1]).append("\n")
                }
            }
            if (records.isBlank()) {
                val old = prefs.getString("results", "") ?: ""
                old.forEach { append(",").append(it).append("\n") }
            }
        }
        contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(output) }
        status.text = "تم حفظ ملف السجل"
    }

    private fun renderSavedResults() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val values = prefs.getString("results", "") ?: ""
        strip.removeAllViews()
        values.takeLast(30).forEach { ch ->
            val tile = TextView(this).apply {
                text = ch.toString()
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(12, 12, 12, 12)
                setBackgroundColor(colorFor(ch))
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(3, 0, 3, 0)
            strip.addView(tile, lp)
        }
        if (values.isEmpty()) {
            strip.addView(TextView(this).apply {
                text = "ستظهر النتائج هنا بعد اكتشافها"
                setTextColor(Color.LTGRAY)
            })
        }
        history.text = "النتائج المسجلة: ${values.length}\n${values.chunked(7).joinToString("  ")}"
        if (prefs.getBoolean("monitoring", false)) status.text = "المراقبة تعمل"
    }

    private fun colorFor(ch: Char) = when (ch) {
        'A' -> Color.rgb(205, 35, 45)
        'B' -> Color.rgb(35, 85, 175)
        else -> Color.rgb(205, 170, 20)
    }

    override fun onResume() {
        super.onResume()
        renderSavedResults()
    }
}
