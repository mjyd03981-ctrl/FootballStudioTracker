# Football Studio Tracker v2.1

Android/Kotlin project.

## Build on GitHub Actions
1. Extract this ZIP.
2. Upload the contents of the `FootballStudioTracker-v2.1` folder to the repository root. The `.github` and `app` folders must be directly at repository root.
3. Do not upload only the ZIP file and do not nest the project folder inside another folder.
4. Open Actions and run `Build Football Studio Tracker APK`.
5. Download the `FootballStudioTracker-debug` artifact from the successful run.

## Important
- This release changes the history string counts to Kotlin `count()` and increments the Android version to 2.1.
- GitHub Actions must confirm the build. Live banner recognition must be tested on the actual Evolution broadcast; screenshots alone cannot guarantee detection accuracy.
- Select a tight capture region around the result announcement banner: red banner / الفريق المضيف = A; blue banner / الفريق الضيف = B; gold banner / اسحب = X.
