package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences

/**
 * Detects Evolution's result announcement banner (not the tiny history arrows).
 * The user selects a tight rectangle around the upper-center announcement.
 * A = red "الفريق المضيف", B = blue "الفريق الضيف", X = gold "اسحب".
 */
object BannerAnnouncementReader {
    data class Detection(val result: Char, val confidence: Float, val red: Int, val blue: Int, val yellow: Int)

    fun detect(image: Image, prefs: SharedPreferences): Detection? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 4) return null

        // RegionSelectorOverlay stores normalized coordinates in thousandths.
        // Defaults match the upper-center banner in the user's Evolution screenshots.
        val left = (width * (prefs.getInt("region_left", 90) / 1000f)).toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 132) / 1000f)).toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 910) / 1000f)).toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 178) / 1000f)).toInt().coerceIn(top + 1, height - 1)
        val roiWidth = right - left
        val roiHeight = bottom - top
        if (roiWidth < 40 || roiHeight < 12) return null

        val hsv = FloatArray(3)
        var red = 0
        var blue = 0
        var yellow = 0
        var eligible = 0
        // Sample evenly across the banner. Ignore a narrow border to avoid table/video edges.
        val xStart = left + (roiWidth * 0.04f).toInt()
        val xEnd = right - (roiWidth * 0.04f).toInt()
        val yStart = top + (roiHeight * 0.12f).toInt()
        val yEnd = bottom - (roiHeight * 0.12f).toInt()
        val stepX = maxOf(1, roiWidth / 180)
        val stepY = maxOf(1, roiHeight / 24)

        var y = yStart
        while (y < yEnd) {
            var x = xStart
            while (x < xEnd) {
                val index = y * rowStride + x * pixelStride
                if (index >= 0 && index + 3 < buffer.limit()) {
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    val a = buffer.get(index + 3).toInt() and 0xff
                    if (a > 100) {
                        Color.RGBToHSV(r, g, b, hsv)
                        val hue = hsv[0]
                        val saturation = hsv[1]
                        val value = hsv[2]
                        // Colored banner background is broad and saturated; white text is ignored.
                        if (saturation >= 0.28f && value >= 0.22f) {
                            when {
                                hue <= 22f || hue >= 340f -> red++
                                hue in 190f..258f -> blue++
                                hue in 28f..68f -> yellow++
                            }
                            eligible++
                        }
                    }
                }
                x += stepX
            }
            y += stepY
        }

        val total = red + blue + yellow
        if (eligible < 30 || total < 25) return null
        val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
        val best = scores[0]
        val second = scores[1].second
        val dominance = best.second.toFloat() / total.coerceAtLeast(1)
        val confidence = best.second.toFloat() / eligible.coerceAtLeast(1)
        // Require a clearly dominant banner color, not a few colored pixels in the video.
        if (dominance < 0.78f || best.second < second * 2.2f || confidence < 0.18f) return null
        return Detection(best.first, confidence, red, blue, yellow)
    }
}
