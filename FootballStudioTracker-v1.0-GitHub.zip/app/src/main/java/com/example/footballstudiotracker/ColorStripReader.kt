package com.example.footballstudiotracker

import android.content.SharedPreferences
import android.media.Image
import kotlin.math.max

/**
 * Reads the small colored vertical marks in Football Studio's history chevrons.
 * Defaults are based on the supplied 728x1600 game screenshot: the history
 * strip is around 45.5% of the captured display height, spanning almost full width.
 * Coordinates remain adjustable because browser chrome / fullscreen changes them.
 */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): List<Char>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 3) return null

        val yPercent = prefs.getInt("scan_y", 455).coerceIn(50, 950) / 1000f
        val xStart = prefs.getInt("scan_x_start", 0).coerceIn(0, 800) / 1000f
        val xEnd = prefs.getInt("scan_x_end", 960).coerceIn(200, 1000) / 1000f
        val count = prefs.getInt("scan_count", 7).coerceIn(3, 12)
        if (xEnd <= xStart) return null

        val yCenter = (height * yPercent).toInt().coerceIn(0, height - 1)
        val left = (width * xStart).toInt().coerceIn(0, width - 1)
        val right = (width * xEnd).toInt().coerceIn(left + 1, width - 1)
        val result = ArrayList<Char>(count)

        for (slot in 0 until count) {
            val cx = (left + (right - left) * (slot + 0.5f) / count).toInt()
            var red = 0
            var blue = 0
            var yellow = 0
            var colored = 0
            // The marker is a thin colored line inside each dark chevron.
            // Scan a compact patch around its expected center and classify chroma.
            for (dy in -12..12 step 2) {
                val y = (yCenter + dy).coerceIn(0, height - 1)
                for (dx in -6..6 step 2) {
                    val x = (cx + dx).coerceIn(0, width - 1)
                    val index = y * rowStride + x * pixelStride
                    if (index < 0 || index + 2 >= buffer.limit()) continue
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff

                    when {
                        r >= 95 && r - g >= 35 && r - b >= 25 -> { red++; colored++ }
                        b >= 85 && b - r >= 20 && b - g >= 12 -> { blue++; colored++ }
                        r >= 125 && g >= 85 && r - b >= 35 && g - b >= 18 -> { yellow++; colored++ }
                    }
                }
            }

            val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
            val winner = scores.first()
            val runnerUp = scores.getOrNull(1)?.second ?: 0
            // Require several chromatic pixels and a clear lead; otherwise leave
            // this frame undecided rather than inserting a guessed result.
            val minPixels = max(3, (colored * 0.22f).toInt())
            if (winner.second < minPixels || winner.second < 3 || winner.second < runnerUp * 1.18f) return null
            result.add(winner.first)
        }
        return result.takeIf { it.size == count }
    }
}
