# Football Studio Tracker v1.0

Android screen-capture tracker for the Football Studio history strip.

## Color mapping (based on the supplied game screenshot)
- A = red
- B = blue
- X = yellow/gold draw

## v1.0 changes
- Corrected default scan line from 30% to 45.5% of captured display height, matching the history chevrons in the supplied 728x1600 screenshot.
- Default scan width is 0%-96%, with seven visible slots.
- Improved chromatic sampling and confidence checks; ambiguous frames are ignored instead of guessed.
- Corrected the app's history-grid and CSV color labels to red / blue / yellow.
- Kept the floating draggable result tiles and REC indicator.

## Important calibration note
The 45.5% coordinate is an estimate from one screenshot. Browser bars, device scaling, zoom, fullscreen, and orientation can move the strip. Start the game in the same display mode, then use **معايرة مكان شريط الألوان** and adjust Y until the scan line crosses the small colored markers in the history chevrons. Keep X start at 0, X end at 96, and count at 7 initially.

The reader uses screen pixels only; it does not perform OCR or read Evolution's internal game data. It may miss or misclassify results if the strip moves or is visually obscured. Verify recorded results manually. This app does not predict outcomes.

## Build
Open this repository at its root in GitHub. GitHub Actions workflow: `.github/workflows/build-apk.yml`.
