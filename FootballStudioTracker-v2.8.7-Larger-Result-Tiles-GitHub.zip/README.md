# Football Studio Tracker v2.8.0

Built from the user's saved v2.7.5 baseline. Changes in this version are limited to alarm configuration and game-stop alert:

- Streak alert threshold is configurable from 1 through 15.
- Red (A) and blue (B) streaks are tracked independently; yellow draws (X) are ignored and do not break a streak.
- Once the configured streak threshold is reached, the existing persistent triple-burst alarm continues until the opposite A/B result arrives.
- Independent game-stop alert: configurable from 10 to 60 seconds, with enable/disable and three selectable tone patterns.
- Added an "إعدادات الإنذارات" entry in the main screen.
- Preserves the existing v2.7.5 manual result editing, multi-undo, logo, capture, and export features.
- No Accessibility service or Accessibility permission is added.

Build using the included GitHub Actions workflow. A local APK build was not verified in this environment because Gradle is unavailable.


## v2.7.7
- Added independent move/fix mode for the history result ribbon.
- Use the floating controls menu item "تحريك / تثبيت شريط النتائج" to toggle movement. Drag the ribbon and toggle again to lock it. Position is saved.
- Existing v2.7.6 alarm settings and prior features are retained.


## v2.7.8 — Unified 100-step undo
- Undo history now includes both manual edits and automatically detected A/B/X results.
- Every new result detection saves a snapshot before writing the result.
- One Undo press restores exactly one prior state; the shared history retains the latest 100 changes.
- Existing manual undo history is migrated into the unified history on app launch.


## v2.7.9 — Paper Bot (simulation only)
- Added a simulation-only Football Studio predictor panel.
- The bot observes newly recorded results and tests a simple baseline: repeat the most recent non-draw A/B result.
- It tracks virtual predictions, wins, losses, accuracy, and skipped rounds. Draw X settles a pending Home/Away prediction as incorrect.
- The bot does not connect to 1xBet, access accounts, submit bets, or handle money.
- Start the test from the main screen button “البوت التجريبي — بدون رهان حقيقي”.
- Existing result history and the 100-step undo feature are retained. No historical database is modified.
- The strategy is a baseline for evaluation only; prior out-of-sample testing did not establish a reliable predictive edge.


## v2.8.0 — Paper Bot sequence and background-processing fix
- PaperBot now processes every newly appended result in chronological order, including multiple results accumulated while the app UI is in the background, provided the new results are still present in the retained history.
- Corrected the prediction timing: after observing a result, the bot now prepares the next-round prediction from the latest known non-draw A/B result.
- If a count gap is larger than the retained result history, the bot safely records a skipped gap rather than inventing outcomes.
- Paper-test statistics are reset once on first launch of v2.8.0 because the previous counter mixed a sequence gap and an off-by-one prediction timing issue. The user's saved result history is not reset or modified by this migration.
- Simulation only; no 1xBet integration or real betting.


## v2.8.1 — Compact live sensor region
- Resizes the default sensor to the compact centered banner region (45% screen width).
- Aligns the visible overlay and sampled color region to the same normalized bounds.
- One-time migration replaces the previous oversized saved region; future manual selections are preserved.
- Paper-bot and result history behavior are otherwise unchanged.

## v2.8.2 — Selective paper signals (experimental)
- Replaces the always-repeat-last-result baseline with a selective filter.
- The bot issues a Home/Away paper signal only when the last 10, 20 and 50 non-draw A/B results all show at least 60% support for the same side. Otherwise it records a WAIT decision.
- Adds a separate WAIT counter to distinguish deliberate waits from sequence gaps.
- The pending signal is settled by the next observed result; a draw X is counted as a loss for a pending A/B signal and is excluded from the A/B rolling windows.
- One-time migration resets only paper-bot counters and leaves the saved result history untouched.
- Important: a historical chronological holdout check of this filter on the saved 5,231-round dataset produced 85 signals and 47.1% accuracy in the final test segment. This is not evidence of an edge; the filter is for transparent paper evaluation only and must not be used as a real-betting signal.


## v2.8.3 — Exact Sensor + 8,991-round Historical Base

- Sensor rectangle aligned to the user's latest reference image (normalized screen bounds: left 265, top 133, right 733, bottom 172).
- Future region selector defaults use the same proportions.
- Bundles `app/src/main/assets/footballstudio_history_8991.csv`, the original 8,991-row CSV, unchanged.
- PaperBot loads the chronological A/B/X sequence from that dataset as historical context, then appends live results separately.
- The original Data 1 / historical CSV is not overwritten or edited.
- The sensor-only migration changes no other settings.


## v2.8.4 — Bot Data Load and Round Processing

- Adds the user's uploaded `Data1_master_8991_with_local_image_numbers.csv` byte-for-byte as `app/src/main/assets/footballstudio_history_8991.csv`.
- Fixes the historical CSV reader to locate `global_index` and `color_en` by header name and validate all 8,991 ordered rows.
- Uses the last 50 non-draw historical outcomes as the rolling seed for the existing selective 10/20/50 rule; the complete 8,991-row CSV remains bundled unchanged.
- Tracks every available valid incoming A/B/X result as processed. Deliberate no-signal rounds are counted as WAIT, separately from genuinely unavailable rounds.
- If more new rounds arrive than remain in the app's 1,000-result live buffer, processes the retained tail and counts only the unrecoverable gap instead of discarding the whole available tail.
- Optimizes per-round analysis to a rolling 50-result buffer rather than rescanning the full historical CSV each time.
- Adds processed-round and historical-dataset counts to the paper-bot status dialog.
- Does not change `CaptureService.kt`, `BannerAnnouncementReader.kt`, `RegionSelectorOverlay.kt`, sensor geometry, sensor colors, capture settings, or detector thresholds.
- Preserves existing bot counters and user settings; no forced reset is performed.

Historical walk-forward replay of the existing selective rule on the uploaded 8,991 rounds produced 1,096 signals and 7,895 waits, with 507 wins and 589 losses (46.26% on settled signals). This is not evidence of a profitable edge; the rule remains paper-only.


## v2.8.5 — Paper-bot stats reset and status display fix

- One-time reset of paper-bot statistics at first launch of v2.8.5. The bot is left stopped until the user starts it again.
- Historical 8,991-round CSV remains bundled and unchanged.
- Live detected results, sensor geometry, capture settings, detector thresholds, and sensor-related source files are unchanged.
- Fixes literal `\\n` display in the bot status dialog so lines render as intended.
- Calculates success percentage as rounded wins / (wins + losses) × 100.
- No real betting functionality is added.


## v2.8.6 — Data 1 round-order alignment

- PaperBot now explicitly sorts the imported historical rows by `global_index` before building its sequence, then validates the full consecutive 1..8,991 order and checks image-part/local-round metadata without assuming those two numbering columns are identical.
- The numbered PNG export now follows the same Data 1 layout: oldest round at top-left, left-to-right, exactly 10 rounds per row (1–10, 11–20, 21–30, ...).
- Live sensor/detector files and capture thresholds are unchanged. Live result storage remains chronological; newest-first ribbons remain display-only.
- Paper-only simulation; no real betting integration.


## v2.8.7 — Larger result tiles (visual-only)

- Enlarges the square result tiles in the live results ribbon and increases the number text size for readability.
- Keeps the existing result colors, order, tap-to-correct behavior, long-press delete behavior, and horizontal scrolling.
- No sensor, detector, capture, bot, history, or data-order logic is changed.
- Build using the included GitHub Actions workflow; local APK build is not verified.
