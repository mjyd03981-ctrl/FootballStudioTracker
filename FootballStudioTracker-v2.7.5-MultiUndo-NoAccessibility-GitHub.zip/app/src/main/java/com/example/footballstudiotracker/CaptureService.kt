package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_SELECT_REGION = "select_region"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
        const val ACTION_CONTROL = "com.example.footballstudiotracker.CONTROL"
        const val EXTRA_CONTROL_ACTION = "control_action"
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var lastAcceptedAt = 0L
    private var sensorArmed = false
    private var sensorNeutralFrames = 0
    private var sensorCandidate: Char? = null
    private var sensorCandidateFrames = 0
    private var sensorFrameView: View? = null
    private var historyRibbonView: View? = null
    private var windowManager: WindowManager? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    private var regionSelector: RegionSelectorOverlay? = null
    private var selectingRegion = false
    private var floatingControls: FloatingControlOverlay? = null
    private var activeAlertResult: Char? = null
    private var alertPlayer: MediaPlayer? = null
    private val alertRunnable = object : Runnable {
        override fun run() {
            if (activeAlertResult == null) return
            // The selected triple-burst recording contains its own three-pulse pattern.
            // MediaPlayer loops it until an opposite A/B result is detected.
            if (alertPlayer == null) startAlertPlayback()
            mainHandler.postDelayed(this, 800L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data, intent?.getBooleanExtra(EXTRA_SELECT_REGION, false) == true)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent, selectRegion: Boolean) {
        migrateResultOrderIfNeeded()
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        captureWidth = width
        captureHeight = height
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopCaptureKeepControls()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    if (!selectingRegion) {
                        val detected = BannerAnnouncementReader.detect(image, prefs)
                        processSensorDetection(detected)
                    }
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        showFloatingControls()
        if (selectRegion) showRegionSelector(width, height) else {
            showSensorFrameIfConfigured()
            showHistoryRibbon()
        }
    }

    private fun showRegionSelector(width: Int, height: Int) {
        removeSensorFrame()
        selectingRegion = true
        regionSelector?.dismiss()
        regionSelector = RegionSelectorOverlay(
            this, getSystemService(WINDOW_SERVICE) as WindowManager, width, height,
            onSave = { left, top, right, bottom ->
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .putInt("region_left", left).putInt("region_top", top)
                    .putInt("region_right", right).putInt("region_bottom", bottom)
                    .putBoolean("region_custom", true).apply()
                selectingRegion = false
                sensorArmed = false
                sensorNeutralFrames = 0
                sensorCandidate = null
                sensorCandidateFrames = 0
                lastAcceptedAt = 0L
                mainHandler.post { showSensorFrameIfConfigured(); showHistoryRibbon() }
                updateFloatingStatus("تم حفظ منطقة حساس اللون")
            },
            onCancel = {
                selectingRegion = false
                updateFloatingStatus("اختيار المنطقة ألغي")
            }
        ).also { it.show() }
    }


    private fun showFloatingControls() {
        if (!Settings.canDrawOverlays(this)) return
        if (floatingControls == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            floatingControls = FloatingControlOverlay(this, windowManager!!) { action ->
                when (action) {
                    FloatingControlOverlay.Action.START -> {
                        val alreadyRunning = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                            .getBoolean("monitoring", false)
                        if (alreadyRunning) updateFloatingStatus("المراقبة تعمل بالفعل")
                        else openMainActivity(MainActivity.ACTION_REQUEST_CAPTURE)
                    }
                    FloatingControlOverlay.Action.STOP -> stopCaptureKeepControls()
                    FloatingControlOverlay.Action.SELECT_REGION -> {
                        if (captureWidth > 0 && captureHeight > 0) {
                            showRegionSelector(captureWidth, captureHeight)
                        } else {
                            openMainActivity(MainActivity.ACTION_REQUEST_REGION)
                        }
                    }
                    FloatingControlOverlay.Action.CALIBRATE -> openMainActivity(MainActivity.ACTION_CALIBRATE)
                    FloatingControlOverlay.Action.EXPORT -> openMainActivity(MainActivity.ACTION_EXPORT)
                    FloatingControlOverlay.Action.CLEAR -> {
                        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                            .remove("results").remove("baseline").putLong("result_count", 0L).apply()
                        updateHistoryRibbon()
                        updateFloatingStatus("تم مسح السجل وإرجاع الترقيم إلى 1")
                    }
                }
            }
        }
        floatingControls?.show()
    }

    private fun openMainActivity(action: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_CONTROL_ACTION, action)
        }
        try { startActivity(intent) } catch (_: Exception) {
            updateFloatingStatus("تعذر فتح شاشة التحكم")
        }
    }

    /** Stops screen capture but keeps the draggable control bubble available for restart. */
    private fun stopCaptureKeepControls() {
        selectingRegion = false
        regionSelector?.dismiss()
        regionSelector = null
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        stopPersistentAlert()
        removeSensorFrame()
        removeHistoryRibbon()
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
        projectionCallback?.let { callback ->
            try { projection?.unregisterCallback(callback) } catch (_: Exception) { }
        }
        projectionCallback = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        try { thread?.quitSafely() } catch (_: Exception) { }
        thread = null
        worker = null
        captureWidth = 0
        captureHeight = 0
        updateFloatingStatus("المراقبة متوقفة — الزر العائم جاهز لإعادة التشغيل")
    }

    private fun migrateResultOrderIfNeeded() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("banner_reader_v19", false)) {
            // v1.8 stored a rectangle for the history-arrow strip; v1.9 uses the
            // announcement banner, so discard the incompatible old rectangle.
            prefs.edit().remove("region_left").remove("region_top")
                .remove("region_right").remove("region_bottom")
                .putBoolean("banner_reader_v19", true).apply()
        }
        // Keep storage chronological; UI components reverse it for newest-left display.
        if (!prefs.getBoolean("storage_oldest_first_v20", false)) {
            val old = prefs.getString("results", "") ?: ""
            prefs.edit()
                .putString("results", old.reversed())
                .putBoolean("storage_oldest_first_v20", true)
                .apply()
        }
        if (!prefs.getBoolean("scan_count_custom", false)) {
            prefs.edit().putInt("scan_count", 7).apply()
        }
    }

    private fun updateFloatingStatus(message: String) {
        mainHandler.post {
            // Keep the result strip intact; show status separately as a short toast.
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * A color is recorded once after the watched tile has been neutral for several frames.
     * Requiring a neutral interval prevents the same persistent color from being logged again.
     */
    private fun processSensorDetection(detection: BannerAnnouncementReader.Detection?) {
        if (detection == null) {
            sensorNeutralFrames = (sensorNeutralFrames + 1).coerceAtMost(30)
            sensorCandidate = null
            sensorCandidateFrames = 0
            if (sensorNeutralFrames >= 10) sensorArmed = true
            return
        }
        sensorNeutralFrames = 0
        if (!sensorArmed) return

        if (sensorCandidate == detection.result) {
            sensorCandidateFrames++
        } else {
            sensorCandidate = detection.result
            sensorCandidateFrames = 1
        }
        if (sensorCandidateFrames < 6) return

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastAcceptedAt < 1200L) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val chronological = prefs.getString("results", "") ?: ""
        // Alert only when an A/B streak reaches exactly nine wins; yellow X results are ignored.
        // Trigger once at the 9th matching win, not again for later wins in the same streak.
        val previousStreak = trailingStreakLength(chronological, detection.result)
        val shouldAlert = detection.result in listOf('A', 'B') && previousStreak == 8
        val nextResultNumber = prefs.getLong("result_count", chronological.length.toLong()) + 1L
        prefs.edit()
            .putLong("result_count", nextResultNumber)
            .putString("results", (chronological + detection.result).takeLast(1000))
            .putString("last_detected_result", detection.result.toString())
            .putLong("last_detected_at", now)
            .apply()
        mainHandler.post {
            updateHistoryRibbon()
            // Yellow draws are ignored. A persistent alert stops only when the
            // opposite team's A/B result is recorded.
            if (detection.result == 'A' || detection.result == 'B') {
                if (activeAlertResult != null && activeAlertResult != detection.result) {
                    stopPersistentAlert()
                }
                if (shouldAlert) startPersistentAlert(detection.result)
            }
        }

        sensorArmed = false
        sensorCandidate = null
        sensorCandidateFrames = 0
        lastAcceptedAt = now
        updateFloatingStatus(when (detection.result) {
            'A' -> "الحساس رصد شريط الفوز: الأحمر — A"
            'B' -> "الحساس رصد شريط الفوز: الأزرق — B"
            else -> "الحساس رصد شريط الفوز: الأصفر — X"
        })
    }


    /**
     * Counts consecutive A or B wins while ignoring yellow draws (X).
     * Example: A,A,X,A is a three-A streak. The opposite team result breaks it.
     */
    private fun trailingStreakLength(history: String, result: Char): Int {
        if (history.isEmpty() || result !in listOf('A', 'B')) return 0
        var count = 0
        for (index in history.length - 1 downTo 0) {
            when (history[index]) {
                'X' -> continue // Draws do not count and do not break a color streak.
                result -> count++
                else -> break // An opposite A/B win breaks the streak.
            }
        }
        return count
    }

    /**
     * Louder repeating bell starts when a nine-result A/B streak is reached.
     * It keeps sounding through yellow draws and stops when the opposite A/B
     * result arrives. It does not restart for the 4th/5th result in the same run.
     */
    private fun startPersistentAlert(result: Char) {
        if (activeAlertResult == result) return
        stopPersistentAlert()
        try {
            activeAlertResult = result
            startAlertPlayback()
            val label = if (result == 'A') "9 نتائج حمراء — الإنذار مستمر حتى ظهور الأزرق"
                else "9 نتائج زرقاء — الإنذار مستمر حتى ظهور الأحمر"
            android.widget.Toast.makeText(this, label, android.widget.Toast.LENGTH_LONG).show()
            mainHandler.removeCallbacks(alertRunnable)
            alertRunnable.run()
        } catch (_: Exception) {
            stopPersistentAlert()
        }
    }

    private fun stopPersistentAlert() {
        activeAlertResult = null
        mainHandler.removeCallbacks(alertRunnable)
        try { alertPlayer?.stop() } catch (_: Exception) { }
        try { alertPlayer?.release() } catch (_: Exception) { }
        alertPlayer = null
    }

    private fun startAlertPlayback() {
        if (activeAlertResult == null || alertPlayer != null) return
        try {
            val player = MediaPlayer()
            alertPlayer = player
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            resources.openRawResourceFd(R.raw.alarm_triple_burst).use { descriptor ->
                player.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
            }
            player.isLooping = true
            player.setVolume(1.0f, 1.0f)
            player.prepare()
            player.start()
        } catch (_: Exception) {
            try { alertPlayer?.release() } catch (_: Exception) { }
            alertPlayer = null
        }
    }

    @Suppress("DEPRECATION")
    private fun showSensorFrameIfConfigured() {
        if (sensorFrameView != null || !Settings.canDrawOverlays(this)) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("region_custom", false)) return
        val left = (captureWidth * prefs.getInt("region_left", 90) / 1000f).toInt()
        val top = (captureHeight * prefs.getInt("region_top", 132) / 1000f).toInt()
        val right = (captureWidth * prefs.getInt("region_right", 910) / 1000f).toInt()
        val bottom = (captureHeight * prefs.getInt("region_bottom", 178) / 1000f).toInt()
        val sensor = android.widget.FrameLayout(this).apply {
            background = GradientDrawable().apply {
                // Almost fully transparent: the banner remains visible and its colors stay readable.
                setColor(Color.argb(2, 30, 130, 255))
                cornerRadius = dp(5).toFloat()
                setStroke(dp(2), Color.argb(225, 35, 135, 255))
            }
            contentDescription = "إطار حساس اللون — المراقبة مباشرة"
            addView(android.widget.TextView(this@CaptureService).apply {
                text = "● LIVE SENSOR"
                textSize = 9f
                setTextColor(Color.WHITE)
                setPadding(dp(5), dp(2), dp(5), dp(2))
                background = GradientDrawable().apply {
                    setColor(Color.argb(145, 5, 15, 30))
                    cornerRadius = dp(5).toFloat()
                }
            }, android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (right - left).coerceAtLeast(dp(24)), (bottom - top).coerceAtLeast(dp(24)), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = left; y = top }
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager?.addView(sensor, params)
            sensorFrameView = sensor
        } catch (_: Exception) { sensorFrameView = null }
    }

    /** Displays the recent A/B/X history over the live broadcast. Newest tile is always at far left. */
    @Suppress("DEPRECATION")
    private fun showHistoryRibbon() {
        if (historyRibbonView != null || !Settings.canDrawOverlays(this)) return
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val ribbon = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
            background = GradientDrawable().apply {
                setColor(Color.argb(178, 18, 22, 34))
                cornerRadius = dp(9).toFloat()
                setStroke(dp(1), Color.argb(100, 255, 255, 255))
            }
            isClickable = false
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (metrics.widthPixels - dp(24)).coerceAtLeast(dp(180)), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = (metrics.heightPixels * 0.265f).toInt()
        }
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager?.addView(ribbon, params)
            historyRibbonView = ribbon
            updateHistoryRibbon()
        } catch (_: Exception) { historyRibbonView = null }
    }

    private fun updateHistoryRibbon() {
        val ribbon = historyRibbonView as? android.widget.LinearLayout ?: return
        ribbon.removeAllViews()
        val values = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            .getString("results", "") ?: ""
        val totalCount = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            .getLong("result_count", values.length.toLong())
        val visibleCount = minOf(8, values.length)
        val newestFirst = values.takeLast(visibleCount).reversed()
        val firstVisibleNumber = (totalCount - visibleCount + 1L).coerceAtLeast(1L)
        if (newestFirst.isEmpty()) {
            ribbon.addView(android.widget.TextView(this).apply {
                text = "A     B     X"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.LTGRAY)
            }, android.widget.LinearLayout.LayoutParams(-1, -1))
            return
        }
        newestFirst.forEachIndexed { index, result ->
            val tileNumber = totalCount - index
            val tile = android.widget.TextView(this).apply {
                text = tileNumber.toString()
                textSize = when { tileNumber >= 10000L -> 9f; tileNumber >= 1000L -> 10f; tileNumber >= 100L -> 12f; tileNumber >= 10L -> 14f; else -> 17f }
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(when (result) {
                        'A' -> Color.rgb(205, 48, 55)
                        'B' -> Color.rgb(35, 95, 220)
                        else -> Color.rgb(222, 177, 28)
                    })
                    cornerRadius = dp(5).toFloat()
                    setStroke(dp(1), Color.argb(110, 255, 255, 255))
                }
            }
            val lp = android.widget.LinearLayout.LayoutParams(0, dp(44), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            ribbon.addView(tile, lp)
        }
    }

    private fun removeHistoryRibbon() {
        try { historyRibbonView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        historyRibbonView = null
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun removeSensorFrame() {
        try { sensorFrameView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        sensorFrameView = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("قراءة لون إعلان الفوز داخل إطار الحساس")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        regionSelector?.dismiss()
        regionSelector = null
        stopPersistentAlert()
        floatingControls?.dismiss()
        floatingControls = null
        removeSensorFrame()
        removeHistoryRibbon()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
