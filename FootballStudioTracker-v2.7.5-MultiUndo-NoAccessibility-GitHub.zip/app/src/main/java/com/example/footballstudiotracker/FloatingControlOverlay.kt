package com.example.footballstudiotracker

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Small translucent draggable bubble with a monochrome glass control panel.
 * The overlay is owned by CaptureService and does not alter capture or detection logic.
 */
class FloatingControlOverlay(
    private val context: Context,
    private val windowManager: WindowManager,
    private val onAction: (Action) -> Unit
) {
    enum class Action { START, STOP, SELECT_REGION, CALIBRATE, EXPORT, CLEAR }

    private var bubble: TextView? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var attached = false
    private var panelVisible = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var downX = 0
    private var downY = 0
    private var dragged = false

    fun show() {
        if (attached) return
        val prefs = context.getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val size = dp(48)
        val dot = TextView(context).apply {
            text = "•"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.argb(220, 255, 255, 255))
            background = glassCircle()
            elevation = dp(8).toFloat()
            contentDescription = "فتح قائمة Football Studio Tracker"
        }
        val params = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("floating_bubble_x", dp(12)).coerceAtLeast(0)
            y = prefs.getInt("floating_bubble_y", dp(220)).coerceAtLeast(0)
        }
        dot.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = params.x
                    downY = params.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) dragged = true
                    if (dragged) {
                        params.x = (downX + dx).coerceAtLeast(0)
                        params.y = (downY + dy).coerceAtLeast(0)
                        try { windowManager.updateViewLayout(dot, params) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        prefs.edit().putInt("floating_bubble_x", params.x)
                            .putInt("floating_bubble_y", params.y).apply()
                    } else {
                        togglePanel()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
        try {
            windowManager.addView(dot, params)
            bubble = dot
            bubbleParams = params
            attached = true
        } catch (_: Exception) {
            attached = false
        }
    }

    private fun togglePanel() {
        if (panelVisible) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panelVisible) return
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.argb(226, 23, 34, 54), Color.argb(210, 34, 43, 62), Color.argb(218, 18, 27, 44))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(210, 210, 225, 245))
            }
            elevation = dp(14).toFloat()
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(10))
        }
        header.addView(TextView(context).apply {
            text = "Football Studio Tracker"
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(TextView(context).apply {
            text = "×"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glassCircle()
            setOnClickListener { hidePanel() }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(header)

        val rows = listOf(
            Triple("▶", "بدء مراقبة الشاشة", Action.START),
            Triple("■", "إيقاف المراقبة", Action.STOP),
            Triple("⌗", "تحديد مربع حساس اللون", Action.SELECT_REGION),
            Triple("⚙", "معايرة يدوية متقدمة", Action.CALIBRATE),
            Triple("▤", "حفظ السجل CSV / صورة ملونة", Action.EXPORT),
            Triple("⌫", "مسح السجل", Action.CLEAR)
        )
        rows.forEach { (symbol, label, action) ->
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(14), 0, dp(14), 0)
                background = GradientDrawable().apply {
                    setColor(Color.argb(92, 215, 225, 242))
                    cornerRadius = dp(28).toFloat()
                    setStroke(dp(1), Color.argb(150, 190, 210, 238))
                }
                isClickable = true
                isFocusable = false
                setOnClickListener {
                    hidePanel()
                    onAction(action)
                }
            }
            row.addView(TextView(context).apply {
                text = symbol
                textSize = 25f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(46), -1))
            row.addView(TextView(context).apply {
                text = label
                textSize = 15f
                gravity = Gravity.CENTER_VERTICAL or Gravity.END
                textDirection = View.TEXT_DIRECTION_RTL
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }, LinearLayout.LayoutParams(0, -1, 1f))
            val lp = LinearLayout.LayoutParams(-1, dp(54))
            lp.bottomMargin = dp(8)
            root.addView(row, lp)
        }

        val scroll = ScrollView(context).apply {
            isFillViewport = true
            addView(root)
        }
        val metrics = context.resources.displayMetrics
        val width = (metrics.widthPixels - dp(28)).coerceAtMost(dp(380))
        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(54)
        }
        try {
            windowManager.addView(scroll, params)
            panel = scroll
            panelParams = params
            panelVisible = true
        } catch (_: Exception) {
            panelVisible = false
        }
    }

    private fun hidePanel() {
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) { }
        panel = null
        panelParams = null
        panelVisible = false
    }

    fun dismiss() {
        hidePanel()
        try { bubble?.let { windowManager.removeView(it) } } catch (_: Exception) { }
        bubble = null
        bubbleParams = null
        attached = false
    }

    private fun glassCircle() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.argb(72, 225, 235, 250))
        setStroke(dp(1), Color.argb(205, 230, 240, 255))
    }

    private fun overlayType() =
        if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
}
