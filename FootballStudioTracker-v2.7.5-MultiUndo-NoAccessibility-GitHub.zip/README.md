# Football Studio Tracker v2.5.8

Based on v2.5.7. Preserves the nine-result persistent A/B alert (X draws are ignored and do not break the streak; the alert continues until the opposite A/B result).

## Numbered results
- Floating result ribbon shows each tile's chronological result number in white.
- Saved results in the app also show the same number in white inside each colored tile.
- Exported PNG grid includes the same white numbers.
- Clearing the history clears the result counter too, so the next result is numbered 1.
- Correcting a result does not change its number.

All other app behavior is retained from v2.5.7.


## Version 2.5.9
- Updated Android launcher icon only.
- Existing result counters, streak threshold, history numbering, and clear-history reset behavior are unchanged from v2.5.8.
- APK build must be verified with GitHub Actions.


## Version 2.6.0
- Uses the exact launcher logo image supplied by the user.
- No app counter, result detection, alert threshold, numbering, or history logic intentionally changed from v2.5.9.
- Verify APK build with GitHub Actions.


## Version 2.6.1
- Replaced the launcher icon with the latest image supplied by the user.
- No application logic, counters, detection, alert threshold, numbering, or history behavior changed from v2.6.0.
- Verify APK build with GitHub Actions.


## Version 2.7.0
- Added a draggable translucent circular floating control bubble.
- Added a frosted-glass floating menu with monochrome classic controls for start/stop, sensor region, calibration, export, and clear history.
- The floating stop action stops screen capture but keeps the bubble available; start can request a fresh MediaProjection session.
- Updated the launcher icon to the latest user-supplied Football Studio Tracker logo.
- Existing detection, nine-result alert logic, result numbering, storage, and history rendering are retained.
- Build and test the APK with GitHub Actions on a device before release.


## Version 2.7.1
- Build-fix release: removed an unused service-action branch that referenced a missing handler.
- No intended changes to floating menu behavior, detection, nine-result alert logic, result numbering, or storage.

## Version 2.7.2
- Updated the Android launcher icon using the latest logo image supplied by the user.
- Replaced the nine-result alert tone with the selected three-burst alarm recording, played at full player volume on the Android alarm audio usage and repeated until the opposite A/B result appears.
- The nine-result streak behavior is unchanged: X draws are ignored and do not break the streak.
- Other application behavior is retained from v2.7.1. Verify the APK build with GitHub Actions.


## Version 2.7.3
- Adds manual result controls in the main app: add A/B/X, tap a tile to correct it, long-press a tile to delete it, clear all results, and undo the latest manual change.
- Manual edits update the shared result history and numbering used by the tracker ribbon.
- Automatic screen monitoring and color detection remain available and unchanged.
- The manual controls edit the tracker's recorded results; they do not alter the external live broadcast graphics.
- Verify the APK build with GitHub Actions on a device before release.


## Version 2.7.5
- Retains the multi-step manual undo history (up to 100 steps) introduced in v2.7.4.
- Removes the automatic TAP feature and its Accessibility Service to avoid requesting accessibility access.
- Retains the existing tracker, result controls, alarm, icon, and screen-monitoring behavior from v2.7.4.
- No Accessibility Service is declared or required. The normal overlay permission remains for existing tracker overlays.
- Verify the APK build with GitHub Actions on a device before release.
