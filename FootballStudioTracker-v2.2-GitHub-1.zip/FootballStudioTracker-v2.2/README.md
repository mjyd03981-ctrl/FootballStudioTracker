# Football Studio Tracker v2.2

Android/Kotlin screen-color sensor for Football Studio.

## What changed in v2.2
- Removed the old floating REC/action button and floating result strip.
- Added a small blue sensor frame that marks the selected screen region; it is transparent and does not intercept touches.
- The default selection is positioned over the first small history tile on the left, matching the supplied screenshot. Move/resize the frame before saving.
- Reads red (A), blue (B), and yellow (X) pixels from the selected region.
- Uses a sampled image signature plus stable-color frames to reduce duplicate readings and to notice a tile change even when its color repeats, provided the tile's visible pixels change.
- Results remain in the app's saved list; newest result is shown at the far left.

## Important limitation
A single small region cannot distinguish two consecutive outcomes if the displayed tile is pixel-identical and there is no visible transition inside that region. If this happens, enlarge/reposition the sensor to include part of the moving history strip, or use a region where the game's new-result animation is visible. This is a visual screen reader, not an official game data feed.

## Build
Open this project in Android Studio or upload the project contents to the root of a GitHub repository and run the `Build Football Studio Tracker APK` workflow. The workflow produces `app/build/outputs/apk/debug/app-debug.apk`.

The APK has not been built or tested against a live broadcast in this environment. Validate it with several red, blue, and yellow outcomes before relying on its log.
