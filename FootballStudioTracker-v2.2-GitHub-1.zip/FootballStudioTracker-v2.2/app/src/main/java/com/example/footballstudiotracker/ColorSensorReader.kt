package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences

/** Reads the color of the user-selected small sensor area (for example the first history tile). */
object ColorSensorReader {
    data class Detection(val result: Char, val confidence: Float, val signature: String)

    fun detect(image: Image, prefs: SharedPreferences): Detection? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 80 || height < 80 || pixelStride < 4) return null

        // RegionSelectorOverlay stores normalized screen coordinates in thousandths.
        val left = (width * (prefs.getInt("region_left", 12) / 1000f)).toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 430) / 1000f)).toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 138) / 1000f)).toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 490) / 1000f)).toInt().coerceIn(top + 1, height - 1)
        val roiWidth = right - left
        val roiHeight = bottom - top
        if (roiWidth < 12 || roiHeight < 12) return null

        val hsv = FloatArray(3)
        var red = 0
        var blue = 0
        var yellow = 0
        val signature = StringBuilder()
        // Fine sampling for the thin colored mark inside the dark history-arrow tile.
        val stepX = maxOf(1, roiWidth / 72)
        val stepY = maxOf(1, roiHeight / 42)
        var y = top + roiHeight / 12
        val yEnd = bottom - roiHeight / 12
        while (y < yEnd) {
            var x = left + roiWidth / 12
            val xEnd = right - roiWidth / 12
            while (x < xEnd) {
                val index = y * rowStride + x * pixelStride
                if (index >= 0 && index + 3 < buffer.limit()) {
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    Color.RGBToHSV(r, g, b, hsv)
                    val h = hsv[0]
                    val s = hsv[1]
                    val v = hsv[2]
                    // Quantized RGB signature detects a new tile even if its color repeats.
                    signature.append(((r shr 5) and 7).toString(16))
                        .append(((g shr 5) and 7).toString(16))
                        .append(((b shr 5) and 7).toString(16))
                    if (s >= 0.48f && v >= 0.28f) {
                        when {
                            h <= 18f || h >= 342f -> red++
                            h in 190f..260f -> blue++
                            h in 25f..72f -> yellow++
                        }
                    }
                }
                x += stepX
            }
            y += stepY
        }

        val total = red + blue + yellow
        if (total < 5) return null
        val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
        val best = scores[0]
        val second = scores[1].second
        val dominance = best.second.toFloat() / total.coerceAtLeast(1)
        if (dominance < 0.52f || best.second < second * 1.25f) return null
        return Detection(best.first, dominance, signature.toString())
    }

    fun changedEnough(previous: String?, current: String): Boolean {
        if (previous.isNullOrEmpty() || previous.length != current.length) return false
        var changed = 0
        for (i in current.indices) if (current[i] != previous[i]) changed++
        return changed.toFloat() / current.length >= 0.10f
    }
}
