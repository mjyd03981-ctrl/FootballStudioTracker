package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_SELECT_REGION = "select_region"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var lastAcceptedAt = 0L
    private var sensorBaselineSignature: String? = null
    private var sensorCandidateSignature: String? = null
    private var sensorCandidate: Char? = null
    private var sensorCandidateFrames = 0
    private var sensorFrameView: View? = null
    private var windowManager: WindowManager? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    private var regionSelector: RegionSelectorOverlay? = null
    private var selectingRegion = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data, intent?.getBooleanExtra(EXTRA_SELECT_REGION, false) == true)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent, selectRegion: Boolean) {
        migrateResultOrderIfNeeded()
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        captureWidth = width
        captureHeight = height
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    if (!selectingRegion) {
                        val detected = ColorSensorReader.detect(image, prefs)
                        processSensorDetection(detected)
                    }
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        if (selectRegion) showRegionSelector(width, height) else showSensorFrameIfConfigured()
    }

    private fun showRegionSelector(width: Int, height: Int) {
        removeSensorFrame()
        selectingRegion = true
        regionSelector?.dismiss()
        regionSelector = RegionSelectorOverlay(
            this, getSystemService(WINDOW_SERVICE) as WindowManager, width, height,
            onSave = { left, top, right, bottom ->
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .putInt("region_left", left).putInt("region_top", top)
                    .putInt("region_right", right).putInt("region_bottom", bottom)
                    .putBoolean("region_custom", true).apply()
                selectingRegion = false
                sensorBaselineSignature = null
                sensorCandidateSignature = null
                sensorCandidate = null
                sensorCandidateFrames = 0
                lastAcceptedAt = 0L
                mainHandler.post { showSensorFrameIfConfigured() }
                updateFloatingStatus("تم حفظ منطقة حساس اللون")
            },
            onCancel = {
                selectingRegion = false
                updateFloatingStatus("اختيار المنطقة ألغي")
            }
        ).also { it.show() }
    }


    private fun migrateResultOrderIfNeeded() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("banner_reader_v19", false)) {
            // v1.8 stored a rectangle for the history-arrow strip; v1.9 uses the
            // announcement banner, so discard the incompatible old rectangle.
            prefs.edit().remove("region_left").remove("region_top")
                .remove("region_right").remove("region_bottom")
                .putBoolean("banner_reader_v19", true).apply()
        }
        // Keep storage chronological; UI components reverse it for newest-left display.
        if (!prefs.getBoolean("storage_oldest_first_v20", false)) {
            val old = prefs.getString("results", "") ?: ""
            prefs.edit()
                .putString("results", old.reversed())
                .putBoolean("storage_oldest_first_v20", true)
                .apply()
        }
        if (!prefs.getBoolean("scan_count_custom", false)) {
            prefs.edit().putInt("scan_count", 7).apply()
        }
    }

    private fun updateFloatingStatus(message: String) {
        mainHandler.post {
            // Keep the result strip intact; show status separately as a short toast.
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /** A sensor event is accepted only after the selected tile visibly changes and its new color is stable. */
    private fun processSensorDetection(detection: ColorSensorReader.Detection?) {
        if (detection == null) {
            sensorCandidate = null
            sensorCandidateFrames = 0
            sensorCandidateSignature = null
            return
        }
        val baseline = sensorBaselineSignature
        if (baseline == null) {
            // Establish the current tile as a baseline; do not import an old visible result on startup.
            sensorBaselineSignature = detection.signature
            return
        }
        if (!ColorSensorReader.changedEnough(baseline, detection.signature)) return
        if (sensorCandidate == detection.result && sensorCandidateSignature != null &&
            ColorSensorReader.changedEnough(sensorCandidateSignature, detection.signature).not()) {
            sensorCandidateFrames++
        } else {
            sensorCandidate = detection.result
            sensorCandidateSignature = detection.signature
            sensorCandidateFrames = 1
        }
        if (sensorCandidateFrames < 4) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastAcceptedAt < 1800L) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val chronological = prefs.getString("results", "") ?: ""
        val updated = (chronological + detection.result).takeLast(1000)
        prefs.edit().putString("results", updated).apply()
        sensorBaselineSignature = detection.signature
        sensorCandidate = null
        sensorCandidateSignature = null
        sensorCandidateFrames = 0
        lastAcceptedAt = now
        updateFloatingStatus(when (detection.result) {
            'A' -> "الحساس رصد الأحمر — A"
            'B' -> "الحساس رصد الأزرق — B"
            else -> "الحساس رصد الأصفر — X"
        })
    }

    @Suppress("DEPRECATION")
    private fun showSensorFrameIfConfigured() {
        if (sensorFrameView != null || !Settings.canDrawOverlays(this)) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("region_custom", false)) return
        val left = (captureWidth * prefs.getInt("region_left", 12) / 1000f).toInt()
        val top = (captureHeight * prefs.getInt("region_top", 430) / 1000f).toInt()
        val right = (captureWidth * prefs.getInt("region_right", 138) / 1000f).toInt()
        val bottom = (captureHeight * prefs.getInt("region_bottom", 490) / 1000f).toInt()
        val sensor = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.argb(12, 30, 130, 255))
                cornerRadius = dp(5).toFloat()
                setStroke(dp(2), Color.rgb(35, 135, 255))
            }
            contentDescription = "إطار حساس اللون — المنطقة التي تتم مراقبتها"
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (right - left).coerceAtLeast(dp(24)), (bottom - top).coerceAtLeast(dp(24)), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = left; y = top }
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager?.addView(sensor, params)
            sensorFrameView = sensor
        } catch (_: Exception) { sensorFrameView = null }
    }

    private fun removeSensorFrame() {
        try { sensorFrameView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        sensorFrameView = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("مشاركة الشاشة وقراءة شريط النتائج مفعّلة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        regionSelector?.dismiss()
        regionSelector = null
        removeSensorFrame()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
