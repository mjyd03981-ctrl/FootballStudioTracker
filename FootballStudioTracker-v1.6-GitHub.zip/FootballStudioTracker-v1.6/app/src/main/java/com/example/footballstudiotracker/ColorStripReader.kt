package com.example.footballstudiotracker

import android.graphics.Color
import android.media.Image
import android.content.SharedPreferences
import kotlin.math.max

/** Reads colored result chevrons from the user-selected strip. */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): List<Char>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 4) return null

        val left = (width * (prefs.getInt("region_left", 20) / 1000f)).toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 435) / 1000f)).toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 985) / 1000f)).toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 500) / 1000f)).toInt().coerceIn(top + 1, height - 1)
        val count = prefs.getInt("scan_count", 7).coerceIn(3, 12)
        val regionWidth = right - left
        val regionHeight = bottom - top
        if (regionWidth < count * 10 || regionHeight < 8) return null

        val results = ArrayList<Char>(count)
        val hsv = FloatArray(3)
        for (slot in 0 until count) {
            val slotLeft = left + regionWidth * slot / count
            val slotRight = left + regionWidth * (slot + 1) / count
            val slotWidth = slotRight - slotLeft
            // Sample a broad center band. Evolution uses both fully colored chevrons
            // and dark chevrons with a narrow vertical colored marker.
            val sampleLeft = slotLeft + (slotWidth * 0.22f).toInt()
            val sampleRight = slotRight - (slotWidth * 0.22f).toInt()
            val sampleTop = top + (regionHeight * 0.10f).toInt()
            val sampleBottom = bottom - (regionHeight * 0.10f).toInt()
            if (sampleRight <= sampleLeft || sampleBottom <= sampleTop) return null

            var red = 0
            var blue = 0
            var yellow = 0
            var sampled = 0
            val columnRed = IntArray(sampleRight - sampleLeft)
            val columnBlue = IntArray(sampleRight - sampleLeft)
            val columnYellow = IntArray(sampleRight - sampleLeft)
            val stepX = max(1, (sampleRight - sampleLeft) / 36)
            val stepY = max(1, (sampleBottom - sampleTop) / 24)
            var y = sampleTop
            while (y < sampleBottom) {
                var x = sampleLeft
                while (x < sampleRight) {
                    val index = y * rowStride + x * pixelStride
                    if (index >= 0 && index + 3 < buffer.limit()) {
                        val r = buffer.get(index).toInt() and 0xff
                        val g = buffer.get(index + 1).toInt() and 0xff
                        val b = buffer.get(index + 2).toInt() and 0xff
                        val a = buffer.get(index + 3).toInt() and 0xff
                        if (a > 100) {
                            Color.RGBToHSV(r, g, b, hsv)
                            val h = hsv[0]
                            val s = hsv[1]
                            val v = hsv[2]
                            val column = x - sampleLeft
                            when {
                                s >= 0.30f && v >= 0.24f && (h <= 20f || h >= 340f) -> {
                                    red++
                                    columnRed[column]++
                                }
                                s >= 0.30f && v >= 0.22f && h in 190f..260f -> {
                                    blue++
                                    columnBlue[column]++
                                }
                                // Gold/yellow in the live strip is much less saturated than red/blue.
                                s >= 0.16f && v >= 0.42f && h in 28f..70f -> {
                                    yellow++
                                    columnYellow[column]++
                                }
                            }
                            sampled++
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            val sampleHeight = max(1, (sampleBottom - sampleTop) / stepY)
            // A vertical marker may occupy only 1-2 columns, so combine total color
            // coverage with the strongest vertical column for each hue.
            val redScore = max(red.toFloat() / max(1, sampled),
                (columnRed.maxOrNull() ?: 0).toFloat() / sampleHeight)
            val blueScore = max(blue.toFloat() / max(1, sampled),
                (columnBlue.maxOrNull() ?: 0).toFloat() / sampleHeight)
            val yellowScore = max(yellow.toFloat() / max(1, sampled),
                (columnYellow.maxOrNull() ?: 0).toFloat() / sampleHeight)
            val scores = listOf('A' to redScore, 'B' to blueScore, 'X' to yellowScore)
                .sortedByDescending { it.second }
            val best = scores[0]
            val second = scores[1].second
            // Reject uncertain/empty tiles instead of inventing a result.
            if (sampled < 8 || best.second < 0.055f || best.second < second * 1.25f) return null
            results.add(best.first)
        }
        return results
    }
}
