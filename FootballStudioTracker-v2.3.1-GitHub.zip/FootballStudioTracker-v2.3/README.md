# Football Studio Tracker v2.3.1

## Fixes
- Fixed the Android Kotlin compile error in `CaptureService.kt` by adding a density-aware `dp()` helper used by the sensor-frame overlay.
- Incremented Android `versionCode` to 24 and `versionName` to 2.3.1.
- Keeps the color-sensor region selector and removes the old floating REC control.

## Build with GitHub Actions
1. Upload the contents of this folder to the repository root (the `app` and `.github` folders must be at the root).
2. Run the **Build Football Studio Tracker APK** workflow.
3. Download the `FootballStudioTracker-debug` artifact.

The project ZIP is source code; the APK is produced by GitHub Actions.
