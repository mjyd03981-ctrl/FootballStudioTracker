package com.example.footballstudiotracker

import android.content.SharedPreferences
import android.media.Image

/**
 * Reads ONLY the user-selected winner-banner sensor region.
 * The region is expressed as percentages of the captured display.
 */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): Char? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 3) return null

        val xPct = prefs.getInt("sensor_x", 80).coerceIn(0, 900) / 1000f
        val yPct = prefs.getInt("sensor_y", 150).coerceIn(0, 950) / 1000f
        val wPct = prefs.getInt("sensor_w", 840).coerceIn(50, 1000) / 1000f
        val hPct = prefs.getInt("sensor_h", 65).coerceIn(20, 500) / 1000f
        val left = (width * xPct).toInt().coerceIn(0, width - 2)
        val top = (height * yPct).toInt().coerceIn(0, height - 2)
        val right = (left + width * wPct).toInt().coerceIn(left + 1, width - 1)
        val bottom = (top + height * hPct).toInt().coerceIn(top + 1, height - 1)

        var red = 0
        var blue = 0
        var yellow = 0
        var sampled = 0
        // Sample a grid inside the ROI, not the rest of the screen.
        val stepX = ((right - left) / 32).coerceAtLeast(1)
        val stepY = ((bottom - top) / 8).coerceAtLeast(1)
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val index = y * rowStride + x * pixelStride
                if (index >= 0 && index + 2 < buffer.limit()) {
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    sampled++
                    when {
                        r > 105 && r - g > 42 && r - b > 32 && g < 145 -> red++
                        b > 95 && b - r > 28 && b - g > 10 -> blue++
                        r > 145 && g > 105 && r - b > 35 && g - b > 25 -> yellow++
                    }
                }
                x += stepX
            }
            y += stepY
        }
        if (sampled == 0) return null
        val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
        val best = scores[0]
        val second = scores[1].second
        // Ignore the neutral "اسحب" banner and uncertain/low-contrast frames.
        if (best.second < (sampled * 0.18f).toInt().coerceAtLeast(4)) return null
        if (best.second < second * 1.35f) return null
        return best.first
    }
}
