package com.example.footballstudiotracker

import android.content.Context
import android.content.SharedPreferences

/**
 * Selective paper-only predictor. It never places or submits real bets.
 *
 * All incoming outcomes are consumed in chronological order. A round without
 * a qualifying signal is counted as a WAIT, not as a missed/unprocessed round.
 */
object PaperBot {
    private const val KEY_ENABLED = "paper_bot_enabled"
    private const val KEY_LAST_SEEN = "paper_bot_last_seen_count"
    private const val KEY_PENDING = "paper_bot_pending_prediction"
    private const val KEY_SIGNALS = "paper_bot_signals"
    private const val KEY_WINS = "paper_bot_wins"
    private const val KEY_LOSSES = "paper_bot_losses"
    private const val KEY_SKIPPED = "paper_bot_skipped_rounds"
    private const val KEY_WAITS = "paper_bot_wait_rounds"
    private const val KEY_PROCESSED = "paper_bot_processed_rounds"
    private const val KEY_LAST_SIGNAL = "paper_bot_last_signal"
    private const val KEY_HISTORICAL_BASE = "paper_bot_historical_base"
    private const val KEY_HISTORICAL_COUNT = "paper_bot_historical_count"
    private const val HISTORICAL_DATA_VERSION = 4
    private const val MIN_SUPPORT = 0.60
    private val WINDOWS = intArrayOf(10, 20, 50)
    private const val MAX_HISTORY = 50

    data class Snapshot(
        val enabled: Boolean,
        val signals: Int,
        val wins: Int,
        val losses: Int,
        val skipped: Int,
        val waits: Int,
        val processed: Int,
        val historicalRounds: Int,
        val pending: Char?,
        val lastSignal: Char?
    ) {
        val settled: Int get() = wins + losses
        val accuracy: Int get() = if (settled <= 0) 0 else
            kotlin.math.round(wins.toDouble() * 100.0 / settled.toDouble()).toInt()
    }

    /**
     * Load the official 12,874-round Data 1 CSV by its actual header names.
     * Validate every global index and preserve the original chronological order.
     * Only the latest 50 non-draw outcomes are cached for the existing strategy.
     */
    fun loadHistoricalData(context: Context, prefs: SharedPreferences) {
        if (prefs.getInt("paper_bot_historical_version", 0) >= HISTORICAL_DATA_VERSION &&
            prefs.getInt(KEY_HISTORICAL_COUNT, 0) == 12874) return

        val parsed = try {
            context.assets.open("footballstudio_history_12874.csv").bufferedReader().use { reader ->
                val header = reader.readLine()?.removePrefix("\uFEFF")?.split(",") ?: emptyList()
                val globalIndexColumn = header.indexOf("global_index")
                val colorColumn = header.indexOf("color_en")
                val imagePartColumn = header.indexOf("image_part")
                val localRoundColumn = header.indexOf("local_round")
                require(listOf(globalIndexColumn, colorColumn, imagePartColumn, localRoundColumn).all { it >= 0 }) {
                    "Required CSV columns are missing"
                }

                val orderedRows = ArrayList<Pair<Int, Char>>(12874)
                reader.forEachLine { line ->
                    if (line.isNotBlank()) {
                        val cells = line.split(",")
                        require(cells.size > maxOf(globalIndexColumn, colorColumn, imagePartColumn, localRoundColumn)) {
                            "Malformed CSV row"
                        }
                        val rowIndex = cells[globalIndexColumn].trim().toInt()
                        val imagePart = cells[imagePartColumn].trim().toInt()
                        val localRound = cells[localRoundColumn].trim().toInt()
                        require(imagePart in 1..14 && localRound in 1..1000) {
                            "Invalid image/round metadata at global round $rowIndex"
                        }
                        val result = when (cells[colorColumn].trim().lowercase()) {
                            "red" -> 'A'
                            "blue" -> 'B'
                            "yellow" -> 'X'
                            else -> error("Unknown color in round $rowIndex")
                        }
                        orderedRows.add(rowIndex to result)
                    }
                }
                val sortedRows = orderedRows.sortedBy { it.first }
                require(sortedRows.size == 12874 && sortedRows.indices.all { sortedRows[it].first == it + 1 }) {
                    "Expected 12,874 consecutive rounds in ascending Data 1 order, found ${sortedRows.size}"
                }
                buildString(12874) { sortedRows.forEach { append(it.second) } }
            }
        } catch (_: Exception) {
            ""
        }

        if (parsed.length == 12874) {
            val rollingAb = parsed.filter { it == 'A' || it == 'B' }.takeLast(MAX_HISTORY)
            prefs.edit()
                .putString(KEY_HISTORICAL_BASE, rollingAb)
                .putInt(KEY_HISTORICAL_COUNT, parsed.length)
                .putInt("paper_bot_historical_version", HISTORICAL_DATA_VERSION)
                .apply()
        }
    }

    fun start(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit().putBoolean(KEY_ENABLED, true).putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING).putString(KEY_LAST_SIGNAL, "").apply()
    }

    fun stop(prefs: SharedPreferences) {
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
    }

    fun reset(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit().putBoolean(KEY_ENABLED, false).putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING).putInt(KEY_SIGNALS, 0).putInt(KEY_WINS, 0)
            .putInt(KEY_LOSSES, 0).putInt(KEY_SKIPPED, 0).putInt(KEY_WAITS, 0)
            .putInt(KEY_PROCESSED, 0).putString(KEY_LAST_SIGNAL, "").apply()
    }

    /**
     * Consume every available new result exactly once.
     * The app keeps the latest 1,000 results. If a longer outage means older
     * rounds are no longer present, process the retained results and count only
     * the unrecoverable gap as skipped; do not discard the entire available tail.
     */
    fun observe(prefs: SharedPreferences, totalCount: Long, storedResults: String) {
        if (!prefs.getBoolean(KEY_ENABLED, false)) return

        val lastSeen = prefs.getLong(KEY_LAST_SEEN, totalCount)
        val delta = totalCount - lastSeen
        if (delta <= 0L) return

        val available = minOf(delta, storedResults.length.toLong()).toInt()
        val unavailable = (delta - available).coerceAtLeast(0L)
        if (available <= 0) {
            prefs.edit()
                .putInt(KEY_SKIPPED, prefs.getInt(KEY_SKIPPED, 0) +
                    unavailable.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                .remove(KEY_PENDING)
                .putLong(KEY_LAST_SEEN, totalCount)
                .apply()
            return
        }

        val newResults = storedResults.takeLast(available)
        val historicalBase = prefs.getString(KEY_HISTORICAL_BASE, "") ?: ""
        val priorLive = storedResults.dropLast(available)
        val history = StringBuilder(
            (historicalBase + priorLive.filter { it == 'A' || it == 'B' }).takeLast(MAX_HISTORY)
        )

        var pending = if (unavailable > 0L) null else prefs.getString(KEY_PENDING, "")?.firstOrNull()
        var signals = prefs.getInt(KEY_SIGNALS, 0)
        var wins = prefs.getInt(KEY_WINS, 0)
        var losses = prefs.getInt(KEY_LOSSES, 0)
        var waits = prefs.getInt(KEY_WAITS, 0)
        var processed = prefs.getInt(KEY_PROCESSED, 0)
        var skipped = prefs.getInt(KEY_SKIPPED, 0) +
            unavailable.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        var lastSignal: Char? = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()

        for (actual in newResults) {
            if (actual !in "ABX") {
                skipped++
                continue
            }

            // Settle the previous round's paper signal before deciding on the next one.
            if (pending == 'A' || pending == 'B') {
                if (actual == pending) wins++ else losses++ // X is a loss for A/B.
            }

            if (actual == 'A' || actual == 'B') {
                history.append(actual)
                if (history.length > MAX_HISTORY) history.delete(0, history.length - MAX_HISTORY)
            }

            val decision = selectSignal(history)
            if (decision == null) {
                pending = null
                waits++
            } else {
                pending = decision
                lastSignal = decision
                signals++
            }
            processed++
        }

        val edit = prefs.edit()
            .putInt(KEY_SIGNALS, signals)
            .putInt(KEY_WINS, wins)
            .putInt(KEY_LOSSES, losses)
            .putInt(KEY_WAITS, waits)
            .putInt(KEY_PROCESSED, processed)
            .putInt(KEY_SKIPPED, skipped)
            .putLong(KEY_LAST_SEEN, totalCount)

        if (pending == null) edit.remove(KEY_PENDING) else edit.putString(KEY_PENDING, pending.toString())
        if (lastSignal == null) edit.putString(KEY_LAST_SIGNAL, "") else edit.putString(KEY_LAST_SIGNAL, lastSignal.toString())
        edit.apply()
    }

    /** Require >=60% support for the same side in each of the last 10, 20 and 50 A/B results. */
    private fun selectSignal(history: CharSequence): Char? {
        if (history.length < 50) return null

        var allA = true
        var allB = true
        for (window in WINDOWS) {
            var aCount = 0
            val start = history.length - window
            for (i in start until history.length) {
                if (history[i] == 'A') aCount++
            }
            val aRate = aCount.toDouble() / window
            if (aRate < MIN_SUPPORT) allA = false
            if (aRate > 1.0 - MIN_SUPPORT) allB = false
        }
        return when {
            allA -> 'A'
            allB -> 'B'
            else -> null
        }
    }

    /** Preserve all existing bot counters/settings; update only the history-cache schema. */
    fun migrateHistoricalCache(prefs: SharedPreferences) {
        // The loader replaces only the derived rolling cache when its version is old.
        // No detector, sensor, strategy threshold, or user setting is changed here.
    }

    /** Compatibility hook: this release deliberately preserves existing paper-bot counters. */
    fun migrateToSelectiveStrategy(prefs: SharedPreferences, currentCount: Long) {
        // No reset or settings migration: keep the user's current bot configuration and statistics.
    }

    fun historicalRounds(prefs: SharedPreferences): Int =
        prefs.getInt(KEY_HISTORICAL_COUNT, 0)

    fun snapshot(prefs: SharedPreferences): Snapshot = Snapshot(
        enabled = prefs.getBoolean(KEY_ENABLED, false),
        signals = prefs.getInt(KEY_SIGNALS, 0),
        wins = prefs.getInt(KEY_WINS, 0),
        losses = prefs.getInt(KEY_LOSSES, 0),
        skipped = prefs.getInt(KEY_SKIPPED, 0),
        waits = prefs.getInt(KEY_WAITS, 0),
        processed = prefs.getInt(KEY_PROCESSED, 0),
        historicalRounds = prefs.getInt(KEY_HISTORICAL_COUNT, 0),
        pending = prefs.getString(KEY_PENDING, "")?.firstOrNull(),
        lastSignal = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()
    )
}
