package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.max

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var previous: List<Char>? = null
    private var lastSavedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val detected = ColorStripReader.detect(image)
                    if (detected != null) processSequence(detected)
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
    }

    private fun processSequence(current: List<Char>) {
        val old = previous
        if (old == null) {
            previous = current
            getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                .putString("baseline", current.joinToString("")).apply()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastSavedAt < 2500) return

        val shiftedLeft = old.drop(1) == current.take(6)
        val shiftedRight = old.take(6) == current.drop(1)
        val newResult = when {
            shiftedLeft -> current.last()
            shiftedRight -> current.first()
            else -> null
        }
        if (newResult != null) {
            val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            val existing = prefs.getString("results", "") ?: ""
            prefs.edit().putString("results", (existing + newResult).takeLast(500)).apply()
            lastSavedAt = now
        }
        previous = current
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("مشاركة الشاشة وقراءة شريط النتائج مفعّلة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
