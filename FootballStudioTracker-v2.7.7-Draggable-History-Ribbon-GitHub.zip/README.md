# Football Studio Tracker v2.7.6

Built from the user's saved v2.7.5 baseline. Changes in this version are limited to alarm configuration and game-stop alert:

- Streak alert threshold is configurable from 1 through 15.
- Red (A) and blue (B) streaks are tracked independently; yellow draws (X) are ignored and do not break a streak.
- Once the configured streak threshold is reached, the existing persistent triple-burst alarm continues until the opposite A/B result arrives.
- Independent game-stop alert: configurable from 10 to 60 seconds, with enable/disable and three selectable tone patterns.
- Added an "إعدادات الإنذارات" entry in the main screen.
- Preserves the existing v2.7.5 manual result editing, multi-undo, logo, capture, and export features.
- No Accessibility service or Accessibility permission is added.

Build using the included GitHub Actions workflow. A local APK build was not verified in this environment because Gradle is unavailable.


## v2.7.7
- Added independent move/fix mode for the history result ribbon.
- Use the floating controls menu item "تحريك / تثبيت شريط النتائج" to toggle movement. Drag the ribbon and toggle again to lock it. Position is saved.
- Existing v2.7.6 alarm settings and prior features are retained.
