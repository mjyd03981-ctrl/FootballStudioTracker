# Football Studio Tracker v2.5.8

Based on v2.5.7. Preserves the nine-result persistent A/B alert (X draws are ignored and do not break the streak; the alert continues until the opposite A/B result).

## Numbered results
- Floating result ribbon shows each tile's chronological result number in white.
- Saved results in the app also show the same number in white inside each colored tile.
- Exported PNG grid includes the same white numbers.
- Clearing the history clears the result counter too, so the next result is numbered 1.
- Correcting a result does not change its number.

All other app behavior is retained from v2.5.7.


## Version 2.5.9
- Updated Android launcher icon only.
- Existing result counters, streak threshold, history numbering, and clear-history reset behavior are unchanged from v2.5.8.
- APK build must be verified with GitHub Actions.


## Version 2.6.0
- Uses the exact launcher logo image supplied by the user.
- No app counter, result detection, alert threshold, numbering, or history logic intentionally changed from v2.5.9.
- Verify APK build with GitHub Actions.


## Version 2.6.1
- Replaced the launcher icon with the latest image supplied by the user.
- No application logic, counters, detection, alert threshold, numbering, or history behavior changed from v2.6.0.
- Verify APK build with GitHub Actions.
