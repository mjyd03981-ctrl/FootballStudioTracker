package com.example.footballstudiotracker

import android.content.SharedPreferences

/** Simulation-only predictor. It never places or submits real bets. */
object PaperBot {
    private const val KEY_ENABLED = "paper_bot_enabled"
    private const val KEY_LAST_SEEN = "paper_bot_last_seen_count"
    private const val KEY_PENDING = "paper_bot_pending_prediction"
    private const val KEY_SIGNALS = "paper_bot_signals"
    private const val KEY_WINS = "paper_bot_wins"
    private const val KEY_LOSSES = "paper_bot_losses"
    private const val KEY_SKIPPED = "paper_bot_skipped_rounds"
    private const val KEY_LAST_SIGNAL = "paper_bot_last_signal"

    data class Snapshot(
        val enabled: Boolean,
        val signals: Int,
        val wins: Int,
        val losses: Int,
        val skipped: Int,
        val pending: Char?,
        val lastSignal: Char?
    ) {
        val settled: Int get() = wins + losses
        val accuracy: Int get() = if (settled == 0) 0 else (wins * 100.0 / settled).toInt()
    }

    fun start(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, true)
            .putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING)
            .putString(KEY_LAST_SIGNAL, "")
            .apply()
    }

    fun stop(prefs: SharedPreferences) {
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
    }

    fun reset(prefs: SharedPreferences, currentCount: Long) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, false)
            .putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING)
            .putInt(KEY_SIGNALS, 0)
            .putInt(KEY_WINS, 0)
            .putInt(KEY_LOSSES, 0)
            .putInt(KEY_SKIPPED, 0)
            .putString(KEY_LAST_SIGNAL, "")
            .apply()
    }

    /**
     * Process every newly appended result in chronological order.
     * The results string is oldest-first and may retain only the newest 1000 entries.
     * If the count gap cannot be aligned to the retained history, skip that gap safely.
     */
    fun observe(prefs: SharedPreferences, totalCount: Long, storedResults: String) {
        if (!prefs.getBoolean(KEY_ENABLED, false)) return
        val lastSeen = prefs.getLong(KEY_LAST_SEEN, totalCount)
        val delta = totalCount - lastSeen
        if (delta <= 0L) return

        if (delta > storedResults.length.toLong()) {
            prefs.edit()
                .putInt(KEY_SKIPPED, prefs.getInt(KEY_SKIPPED, 0) + delta.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                .remove(KEY_PENDING)
                .putString(KEY_LAST_SIGNAL, "")
                .putLong(KEY_LAST_SEEN, totalCount)
                .apply()
            return
        }

        val newResults = storedResults.takeLast(delta.toInt())
        var pending = prefs.getString(KEY_PENDING, "")?.firstOrNull()
        var lastNonDraw = storedResults.dropLast(newResults.length).reversed().firstOrNull { it == 'A' || it == 'B' }
        var signals = prefs.getInt(KEY_SIGNALS, 0)
        var wins = prefs.getInt(KEY_WINS, 0)
        var losses = prefs.getInt(KEY_LOSSES, 0)
        var lastSignal: Char? = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()

        for (actual in newResults) {
            if (pending == 'A' || pending == 'B') {
                if (actual == pending) wins++ else losses++ // X is a loss for an A/B prediction.
            }

            // The just-observed result is now the latest known non-draw result.
            if (actual == 'A' || actual == 'B') lastNonDraw = actual

            // Generate the prediction for the NEXT round from the latest known A/B.
            if (lastNonDraw == 'A' || lastNonDraw == 'B') {
                pending = lastNonDraw
                lastSignal = lastNonDraw
                signals++
            } else {
                pending = null
                lastSignal = null
            }
        }

        val edit = prefs.edit()
            .putInt(KEY_SIGNALS, signals)
            .putInt(KEY_WINS, wins)
            .putInt(KEY_LOSSES, losses)
            .putLong(KEY_LAST_SEEN, totalCount)
        if (pending == null) edit.remove(KEY_PENDING) else edit.putString(KEY_PENDING, pending.toString())
        if (lastSignal == null) edit.putString(KEY_LAST_SIGNAL, "") else edit.putString(KEY_LAST_SIGNAL, lastSignal.toString())
        edit.apply()
    }

    /** Reset the paper-test counters once when upgrading to the corrected sequence logic. */
    fun migrateToSequenceFix(prefs: SharedPreferences, currentCount: Long) {
        if (prefs.getInt("paper_bot_sequence_fix_version", 0) >= 1) return
        prefs.edit()
            .putBoolean(KEY_ENABLED, false)
            .putLong(KEY_LAST_SEEN, currentCount)
            .remove(KEY_PENDING)
            .putInt(KEY_SIGNALS, 0)
            .putInt(KEY_WINS, 0)
            .putInt(KEY_LOSSES, 0)
            .putInt(KEY_SKIPPED, 0)
            .putString(KEY_LAST_SIGNAL, "")
            .putInt("paper_bot_sequence_fix_version", 1)
            .apply()
    }

    fun snapshot(prefs: SharedPreferences): Snapshot {
        return Snapshot(
            enabled = prefs.getBoolean(KEY_ENABLED, false),
            signals = prefs.getInt(KEY_SIGNALS, 0),
            wins = prefs.getInt(KEY_WINS, 0),
            losses = prefs.getInt(KEY_LOSSES, 0),
            skipped = prefs.getInt(KEY_SKIPPED, 0),
            pending = prefs.getString(KEY_PENDING, "")?.firstOrNull(),
            lastSignal = prefs.getString(KEY_LAST_SIGNAL, "")?.firstOrNull()
        )
    }
}
