package com.example.footballstudiotracker

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** Full-screen selector. Drag inside the frame to move it; drag any blue corner to resize. */
class RegionSelectorOverlay(
    private val context: Context,
    private val windowManager: WindowManager,
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val onSave: (Int, Int, Int, Int) -> Unit,
    private val onCancel: () -> Unit
) {
    private val root = FrameLayout(context)
    private val frame = FrameLayout(context)
    private val border = View(context)
    private val handles = mutableListOf<TextView>()
    private var attached = false

    private var frameLeft = (screenWidth * 0.025f).toInt()
    private var frameTop = (screenHeight * 0.435f).toInt()
    private var frameWidth = (screenWidth * 0.95f).toInt()
    private var frameHeight = max((screenHeight * 0.055f).toInt(), dp(48))

    private var downX = 0f
    private var downY = 0f
    private var downLeft = 0
    private var downTop = 0
    private var downWidth = 0
    private var downHeight = 0

    private val minFrameWidth get() = dp(90).coerceAtMost(screenWidth)
    private val minFrameHeight get() = dp(36).coerceAtMost(screenHeight)
    private val maxFrameHeight get() = (screenHeight * 0.70f).toInt().coerceAtLeast(minFrameHeight)

    fun show() {
        root.setBackgroundColor(Color.TRANSPARENT)
        root.isClickable = false

        frame.background = GradientDrawable().apply {
            setColor(Color.argb(34, 35, 165, 255))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(3), Color.rgb(55, 205, 255))
        }
        frame.isClickable = true
        frame.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    beginGesture(event)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    frameLeft = downLeft + (event.rawX - downX).toInt()
                    frameTop = downTop + (event.rawY - downY).toInt()
                    clampFrame()
                    updateFrameLayout()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
        root.addView(frame)

        border.background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), Color.WHITE)
            cornerRadius = dp(6).toFloat()
        }
        border.isClickable = false
        frame.addView(border, FrameLayout.LayoutParams(-1, -1))

        // Four large corner grips ensure the blue resize control can be reached from any screen corner.
        addResizeHandle("↖", Corner.TOP_LEFT)
        addResizeHandle("↗", Corner.TOP_RIGHT)
        addResizeHandle("↙", Corner.BOTTOM_LEFT)
        addResizeHandle("↘", Corner.BOTTOM_RIGHT)

        val toolbar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 15, 25, 42))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        toolbar.addView(TextView(context).apply {
            text = "اسحب داخل الإطار لتحريكه، واسحب أي مقبض أزرق من الزوايا لتغيير الحجم"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        val actions = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(Button(context).apply {
            text = "حفظ المنطقة"
            setOnClickListener {
                val l = (frameLeft * 1000f / screenWidth).toInt().coerceIn(0, 999)
                val t = (frameTop * 1000f / screenHeight).toInt().coerceIn(0, 999)
                val r = ((frameLeft + frameWidth) * 1000f / screenWidth).toInt().coerceIn(l + 1, 1000)
                val b = ((frameTop + frameHeight) * 1000f / screenHeight).toInt().coerceIn(t + 1, 1000)
                onSave(l, t, r, b)
                dismiss()
            }
        })
        actions.addView(Button(context).apply {
            text = "إلغاء"
            setOnClickListener { dismiss(); onCancel() }
        })
        toolbar.addView(actions)
        root.addView(toolbar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(48)
        })

        clampFrame()
        updateFrameLayout()
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try {
            windowManager.addView(root, params)
            attached = true
        } catch (_: Exception) {
            attached = false
        }
    }

    private enum class Corner { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

    private fun addResizeHandle(symbol: String, corner: Corner) {
        val handle = TextView(context).apply {
            text = symbol
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.rgb(0, 112, 210))
                cornerRadius = dp(13).toFloat()
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(8).toFloat()
            isClickable = true
            isFocusable = false
        }
        val size = dp(56) // generous touch target for easier dragging on phones
        val gravity = when (corner) {
            Corner.TOP_LEFT -> Gravity.TOP or Gravity.LEFT
            Corner.TOP_RIGHT -> Gravity.TOP or Gravity.RIGHT
            Corner.BOTTOM_LEFT -> Gravity.BOTTOM or Gravity.LEFT
            Corner.BOTTOM_RIGHT -> Gravity.BOTTOM or Gravity.RIGHT
        }
        frame.addView(handle, FrameLayout.LayoutParams(size, size, gravity))
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    beginGesture(event)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    resizeFrom(corner, event.rawX - downX, event.rawY - downY)
                    updateFrameLayout()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
        handles.add(handle)
    }

    private fun beginGesture(event: MotionEvent) {
        downX = event.rawX
        downY = event.rawY
        downLeft = frameLeft
        downTop = frameTop
        downWidth = frameWidth
        downHeight = frameHeight
    }

    private fun resizeFrom(corner: Corner, dxFloat: Float, dyFloat: Float) {
        val dx = dxFloat.toInt()
        val dy = dyFloat.toInt()
        val minW = min(minFrameWidth, screenWidth)
        val minH = min(minFrameHeight, screenHeight)
        when (corner) {
            Corner.TOP_LEFT -> {
                val fixedRight = downLeft + downWidth
                val fixedBottom = downTop + downHeight
                frameLeft = (downLeft + dx).coerceIn(0, fixedRight - minW)
                frameTop = (downTop + dy).coerceIn(0, fixedBottom - minH)
                frameWidth = fixedRight - frameLeft
                frameHeight = fixedBottom - frameTop
            }
            Corner.TOP_RIGHT -> {
                val fixedLeft = downLeft
                val fixedBottom = downTop + downHeight
                frameLeft = fixedLeft
                frameTop = (downTop + dy).coerceIn(0, fixedBottom - minH)
                frameWidth = (downWidth + dx).coerceIn(minW, screenWidth - fixedLeft)
                frameHeight = fixedBottom - frameTop
            }
            Corner.BOTTOM_LEFT -> {
                val fixedRight = downLeft + downWidth
                val fixedTop = downTop
                frameLeft = (downLeft + dx).coerceIn(0, fixedRight - minW)
                frameTop = fixedTop
                frameWidth = fixedRight - frameLeft
                frameHeight = (downHeight + dy).coerceIn(minH, screenHeight - fixedTop)
            }
            Corner.BOTTOM_RIGHT -> {
                frameLeft = downLeft
                frameTop = downTop
                frameWidth = (downWidth + dx).coerceIn(minW, screenWidth - downLeft)
                frameHeight = (downHeight + dy).coerceIn(minH, screenHeight - downTop)
            }
        }
        frameHeight = frameHeight.coerceAtMost(maxFrameHeight)
        clampFrame()
    }

    private fun updateFrameLayout() {
        val lp = frame.layoutParams as? FrameLayout.LayoutParams
            ?: FrameLayout.LayoutParams(frameWidth, frameHeight)
        lp.width = frameWidth
        lp.height = frameHeight
        lp.leftMargin = frameLeft
        lp.topMargin = frameTop
        frame.layoutParams = lp
    }

    private fun clampFrame() {
        frameWidth = frameWidth.coerceIn(minFrameWidth, screenWidth.coerceAtLeast(minFrameWidth))
        frameHeight = frameHeight.coerceIn(minFrameHeight, maxFrameHeight)
        frameLeft = frameLeft.coerceIn(0, max(0, screenWidth - frameWidth))
        frameTop = frameTop.coerceIn(0, max(0, screenHeight - frameHeight))
    }

    fun dismiss() {
        if (attached) try { windowManager.removeView(root) } catch (_: Exception) { }
        attached = false
    }

    private fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
}
