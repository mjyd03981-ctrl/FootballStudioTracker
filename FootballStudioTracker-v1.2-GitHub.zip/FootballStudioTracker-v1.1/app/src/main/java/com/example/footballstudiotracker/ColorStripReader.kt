package com.example.footballstudiotracker

import android.media.Image
import android.content.SharedPreferences
import kotlin.math.max

/** Reads colored result markers only inside the user-selected rectangle. */
object ColorStripReader {
    fun detect(image: Image, prefs: SharedPreferences): List<Char>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 3) return null

        // Values are normalized to 0..1000 and are saved by the drag-selection overlay.
        val left = (width * (prefs.getInt("region_left", 25) / 1000f)).toInt().coerceIn(0, width - 2)
        val top = (height * (prefs.getInt("region_top", 435) / 1000f)).toInt().coerceIn(0, height - 2)
        val right = (width * (prefs.getInt("region_right", 975) / 1000f)).toInt().coerceIn(left + 1, width - 1)
        val bottom = (height * (prefs.getInt("region_bottom", 490) / 1000f)).toInt().coerceIn(top + 1, height - 1)
        val count = prefs.getInt("scan_count", 7).coerceIn(3, 12)
        val regionWidth = right - left
        val regionHeight = bottom - top
        if (regionWidth < count * 8 || regionHeight < 8) return null

        val results = ArrayList<Char>(count)
        for (slot in 0 until count) {
            val slotLeft = left + regionWidth * slot / count
            val slotRight = left + regionWidth * (slot + 1) / count
            // Ignore chevron borders and scan the marker area inside each tile.
            val sampleLeft = slotLeft + ((slotRight - slotLeft) * 0.22f).toInt()
            val sampleRight = slotRight - ((slotRight - slotLeft) * 0.22f).toInt()
            val sampleTop = top + (regionHeight * 0.12f).toInt()
            val sampleBottom = bottom - (regionHeight * 0.12f).toInt()
            var red = 0
            var blue = 0
            var yellow = 0
            var total = 0
            val stepX = max(1, (sampleRight - sampleLeft) / 18)
            val stepY = max(1, (sampleBottom - sampleTop) / 12)

            var y = sampleTop
            while (y < sampleBottom) {
                var x = sampleLeft
                while (x < sampleRight) {
                    val index = y * rowStride + x * pixelStride
                    if (index >= 0 && index + 2 < buffer.limit()) {
                        val r = buffer.get(index).toInt() and 0xff
                        val g = buffer.get(index + 1).toInt() and 0xff
                        val b = buffer.get(index + 2).toInt() and 0xff
                        when {
                            r >= 105 && r - g >= 38 && r - b >= 28 -> { red++; total++ }
                            b >= 95 && b - r >= 22 && b - g >= 14 -> { blue++; total++ }
                            r >= 145 && g >= 105 && r - b >= 38 && g - b >= 24 -> { yellow++; total++ }
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
            val best = scores[0]
            val second = scores[1].second
            // A blank/uncertain tile invalidates the frame; never invent a result.
            if (total < 3 || best.second < 2 || best.second < second * 1.25f || best.second < total * 0.42f) return null
            results.add(best.first)
        }
        return results
    }
}
