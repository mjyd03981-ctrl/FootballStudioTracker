package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var previous: List<Char>? = null
    private var lastSavedAt = 0L
    private var windowManager: WindowManager? = null
    private var floatingView: LinearLayout? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    val detected = ColorStripReader.detect(image, prefs)
                    if (detected != null) processSequence(detected)
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        showFloatingIndicator()
    }

    private fun processSequence(current: List<Char>) {
        val old = previous
        if (old == null || old.size != current.size) {
            previous = current
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastSavedAt < 2200) return
        val shiftedLeft = old.drop(1) == current.dropLast(1)
        val shiftedRight = old.dropLast(1) == current.drop(1)
        val newResult = when {
            shiftedLeft -> current.last()
            shiftedRight -> current.first()
            else -> null
        }
        if (newResult != null) {
            val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            val existing = prefs.getString("results", "") ?: ""
            val updated = (existing + newResult).takeLast(1000)
            prefs.edit().putString("results", updated).apply()
            lastSavedAt = now
            updateFloatingIndicator(updated)
        }
        previous = current
    }

    @Suppress("DEPRECATION")
    private fun showFloatingIndicator() {
        if (!Settings.canDrawOverlays(this) || floatingView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val initial = prefs.getString("results", "") ?: ""
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(9, 7, 9, 7)
            alpha = 0.84f
            elevation = 12f
            background = GradientDrawable().apply {
                setColor(Color.argb(178, 12, 19, 30))
                cornerRadius = 18f
                setStroke(1, Color.argb(105, 255, 255, 255))
            }
        }
        floatingView = panel
        renderFloatingTiles(initial)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 12
            y = 170
            if (Build.VERSION.SDK_INT >= 31) {
                setBackgroundBlurRadius(22)
            }
        }
        panel.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var downX = 0f
            private var downY = 0f
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        downX = event.rawX
                        downY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - downX).toInt()
                        params.y = startY + (event.rawY - downY).toInt()
                        try { windowManager?.updateViewLayout(view, params) } catch (_: Exception) { }
                        return true
                    }
                }
                return true
            }
        })
        try {
            windowManager?.addView(panel, params)
            floatingParams = params
        } catch (_: Exception) {
            floatingView = null
        }
    }

    private fun renderFloatingTiles(values: String) {
        val panel = floatingView ?: return
        panel.removeAllViews()
        val rec = TextView(this).apply {
            text = "● REC"
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(3, 0, 7, 0)
        }
        panel.addView(rec)
        values.takeLast(7).reversed().forEach { result ->
            val tile = TextView(this).apply {
                text = result.toString()
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(when (result) {
                        'A' -> Color.rgb(28, 155, 78)   // A: green
                        'B' -> Color.rgb(205, 48, 55)   // B: red
                        else -> Color.rgb(232, 184, 32)  // X: yellow
                    })
                    cornerRadius = 6f
                    setStroke(1, Color.argb(120, 255, 255, 255))
                }
                alpha = 0.96f
            }
            val size = (36 * resources.displayMetrics.density).toInt()
            val margin = (3 * resources.displayMetrics.density).toInt()
            panel.addView(tile, LinearLayout.LayoutParams(size, size).apply {
                leftMargin = margin
                rightMargin = margin
            })
        }
        if (values.isEmpty()) {
            panel.addView(TextView(this).apply {
                text = "بانتظار النتائج"
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(5, 0, 5, 0)
            })
        }
    }

    // Android Views must only be changed on the main/UI thread.
    private fun updateFloatingIndicator(values: String) {
        mainHandler.post {
            if (floatingView != null) renderFloatingTiles(values)
        }
    }

    private fun removeFloatingIndicator() {
        try { floatingView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        floatingView = null
        floatingParams = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("مشاركة الشاشة وقراءة شريط النتائج مفعّلة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        removeFloatingIndicator()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
