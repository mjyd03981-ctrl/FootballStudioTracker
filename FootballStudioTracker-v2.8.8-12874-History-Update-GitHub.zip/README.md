# Football Studio Tracker v2.8.8 — Data 1 History Update

- Updated the embedded official Data 1 history from 8,991 to 12,874 rounds.
- The CSV is read using its actual six-column schema: global_index, color_ar, color_en, symbol, image_part, local_round.
- Loader validates the full ascending sequence 1..12874 before accepting it.
- Existing paper-bot strategy thresholds and detector/sensor source files/settings are unchanged.
- Existing live result counters are preserved. The historical rolling context is refreshed using a versioned cache migration.
- Paper-only simulation; no real betting actions.

Build the APK with GitHub Actions. Local Gradle build was not run in this environment.
