# Football Studio Tracker (prototype)

Android starter project for a user-consented screen-reading prototype.

## What it does
- Requests Android MediaProjection permission before capturing the screen.
- Runs a foreground service while screen capture is active.
- Samples seven colored markers in the approximate result-ribbon location from the supplied screenshot.
- Stores newly detected results when the seven-marker sequence shifts by one position.
- Displays an A (red), B (blue), X (gold) history strip.

## Important limitations
This is an experimental first prototype, not a verified production app. The detector is calibrated to the supplied portrait screenshot and may need adjustment for different screen sizes, zoom levels, app layouts, or landscape mode. It does not place bets or predict future outcomes. Validate detected results against the game before relying on the history.

## Build
Open this folder in Android Studio (Giraffe or newer), use JDK 17, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, min SDK 26.
