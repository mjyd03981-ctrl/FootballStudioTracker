package com.example.footballstudiotracker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCapture = 4102
    private lateinit var status: TextView
    private lateinit var strip: LinearLayout
    private lateinit var history: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            renderSavedResults()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderSavedResults()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(Color.rgb(14, 22, 38))
        }

        val title = TextView(this).apply {
            text = "FOOTBALL STUDIO TRACKER"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        status = TextView(this).apply {
            text = "متوقف — اضغط بدء المراقبة"
            textSize = 14f
            setTextColor(Color.rgb(180, 195, 215))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "بدء مراقبة الشاشة"
            setOnClickListener { requestScreenCapture() }
        }
        val stop = Button(this).apply {
            text = "إيقاف المراقبة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "المراقبة متوقفة"
            }
        }
        val reset = Button(this).apply {
            text = "مسح السجل"
            setOnClickListener {
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .remove("results").remove("baseline").apply()
                renderSavedResults()
            }
        }
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        history = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        }
        val note = TextView(this).apply {
            text = "مهم: هذه نسخة أولية. تسمح بمشاركة الشاشة بإذن أندرويد، وتحاول قراءة شريط الألوان من موضعه الظاهر في الصورة المرجعية. قد تحتاج معايرة حسب حجم الشاشة أو واجهة اللعبة. لا تتنبأ بنتائج الجولات."
            textSize = 13f
            setTextColor(Color.rgb(180, 195, 215))
            setPadding(0, 18, 0, 0)
        }

        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(reset)
        root.addView(strip)
        root.addView(history)
        root.addView(note)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            startForegroundService(service)
            status.text = "المراقبة تعمل — أندرويد يعرض إشعار مشاركة الشاشة"
        }
    }

    private fun renderSavedResults() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val values = prefs.getString("results", "") ?: ""
        strip.removeAllViews()
        val chars = values.takeLast(14).toList()
        if (chars.isEmpty()) {
            val empty = TextView(this).apply {
                text = "ستظهر النتائج هنا بعد اكتشافها"
                setTextColor(Color.LTGRAY)
            }
            strip.addView(empty)
        } else {
            chars.forEach { ch ->
                val tile = TextView(this).apply {
                    text = ch.toString()
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    setPadding(12, 12, 12, 12)
                    setBackgroundColor(when (ch) {
                        'A' -> Color.rgb(205, 25, 38)
                        'B' -> Color.rgb(25, 77, 153)
                        else -> Color.rgb(177, 151, 69)
                    })
                }
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(3, 0, 3, 0)
                strip.addView(tile, lp)
            }
        }
        history.text = "النتائج المسجلة: ${values.length}\n${values.chunked(7).joinToString("  ")}"
        if (prefs.getBoolean("monitoring", false)) {
            status.text = "المراقبة تعمل"
        }
    }
}
