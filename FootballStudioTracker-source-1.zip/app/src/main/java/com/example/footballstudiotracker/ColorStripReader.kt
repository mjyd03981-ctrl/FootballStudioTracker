package com.example.footballstudiotracker

import android.media.Image
import kotlin.math.max
import kotlin.math.min

/**
 * Prototype detector for the 7 colored result markers in the supplied portrait screenshot.
 * It samples seven small windows along the result ribbon around 42.5% of screen height.
 * The first version intentionally returns null unless enough colored pixels are found.
 */
object ColorStripReader {
    fun detect(image: Image): List<Char>? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val yCenter = (height * 0.425f).toInt()
        val centers = (0 until 7).map { ((0.075f + it * 0.14f) * width).toInt().coerceIn(0, width - 1) }
        val result = mutableListOf<Char>()

        for (cx in centers) {
            var red = 0
            var blue = 0
            var yellow = 0
            var total = 0
            for (dy in -10..10 step 2) {
                val y = (yCenter + dy).coerceIn(0, height - 1)
                for (dx in -9..9 step 2) {
                    val x = (cx + dx).coerceIn(0, width - 1)
                    val index = y * rowStride + x * pixelStride
                    if (index + 2 >= buffer.limit()) continue
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    total++
                    if (r > 135 && r > g * 1.35 && r > b * 1.25) red++
                    if (b > 105 && b > r * 1.22 && b > g * 1.08) blue++
                    if (r > 145 && g > 105 && b < 145 && r > b * 1.15 && g > b * 1.12) yellow++
                }
            }
            val threshold = max(3, (total * 0.055f).toInt())
            val winner = listOf('A' to red, 'B' to blue, 'X' to yellow).maxByOrNull { it.second }
            if (winner == null || winner.second < threshold) return null
            result.add(winner.first)
        }
        return if (result.size == 7) result else null
    }
}
