package com.example.footballstudiotracker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStreamWriter

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_CAPTURE = 4102
        private const val REQUEST_OVERLAY = 4103
        private const val REQUEST_EXPORT = 4104
    }

    private lateinit var status: TextView
    private lateinit var strip: LinearLayout
    private lateinit var history: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            renderSavedResults()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderSavedResults()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(Color.rgb(14, 22, 38))
        }
        val title = TextView(this).apply {
            text = "FOOTBALL STUDIO TRACKER"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        status = TextView(this).apply {
            text = "متوقف — اضغط بدء المراقبة"
            textSize = 14f
            setTextColor(Color.rgb(180, 195, 215))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "بدء مراقبة الشاشة"
            setOnClickListener { checkOverlayThenCapture() }
        }
        val stop = Button(this).apply {
            text = "إيقاف المراقبة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "المراقبة متوقفة"
                renderSavedResults()
            }
        }
        val calibrate = Button(this).apply {
            text = "معايرة مكان شريط الألوان"
            setOnClickListener { showCalibrationDialog() }
        }
        val export = Button(this).apply {
            text = "حفظ السجل CSV"
            setOnClickListener { createCsvDocument() }
        }
        val reset = Button(this).apply {
            text = "مسح السجل"
            setOnClickListener {
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .remove("results").remove("baseline").apply()
                renderSavedResults()
            }
        }
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        history = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        }
        val note = TextView(this).apply {
            text = "ترتيب النتائج مثل الموقع: الأحدث في أقصى اليسار، والأقدم إلى اليمين. الألوان: A أحمر، B أزرق، X أصفر (تعادل). القراءة آلية وتجريبية وقد تحتاج معايرة حسب موضع الشريط. راجع النتائج يدوياً؛ ليست تنبؤاً بنتائج المباريات."
            textSize = 13f
            setTextColor(Color.rgb(180, 195, 215))
            setPadding(0, 18, 0, 0)
        }
        listOf(title, status, start, stop, calibrate, export, reset, strip, history, note).forEach { root.addView(it) }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }


    private fun showCalibrationDialog() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val y = EditText(this).apply { hint = "موضع Y بالمئة (مثلاً 47.5)"; setText((prefs.getInt("scan_y", 475) / 10f).toString()); inputType = 8194 }
        val x1 = EditText(this).apply { hint = "بداية X بالمئة (مثلاً 0)"; setText((prefs.getInt("scan_x_start", 0) / 10f).toString()); inputType = 8194 }
        val x2 = EditText(this).apply { hint = "نهاية X بالمئة (مثلاً 94)"; setText((prefs.getInt("scan_x_end", 940) / 10f).toString()); inputType = 8194 }
        val count = EditText(this).apply { hint = "عدد المربعات (3 إلى 12)"; setText(prefs.getInt("scan_count", 7).toString()); inputType = 2 }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 0)
            addView(y); addView(x1); addView(x2); addView(count)
        }
        AlertDialog.Builder(this)
            .setTitle("معايرة شريط النتائج")
            .setMessage("اضبط منطقة الشريط الأفقي في صفحة Football Studio. الإعداد الافتراضي قريب من صورتك: Y=47.5%، من X=0% إلى 94%، و7 خانات. ترتيب الموقع: الأحدث في اليسار.")
            .setView(content)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val yy = (y.text.toString().toFloatOrNull() ?: 47.5f).coerceIn(5f, 95f)
                val xx1 = (x1.text.toString().toFloatOrNull() ?: 0f).coerceIn(0f, 80f)
                val xx2 = (x2.text.toString().toFloatOrNull() ?: 94f).coerceIn(20f, 100f)
                val n = (count.text.toString().toIntOrNull() ?: 7).coerceIn(3, 12)
                if (xx2 <= xx1) {
                    Toast.makeText(this, "نهاية X يجب أن تكون أكبر من البداية", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                prefs.edit().putInt("scan_y", (yy * 10).toInt())
                    .putInt("scan_x_start", (xx1 * 10).toInt())
                    .putInt("scan_x_end", (xx2 * 10).toInt())
                    .putInt("scan_count", n).apply()
                Toast.makeText(this, "تم حفظ إعدادات القراءة", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun checkOverlayThenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح للتطبيق بالظهور فوق التطبيقات لإظهار مؤشر المراقبة", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY -> if (Settings.canDrawOverlays(this)) requestScreenCapture()
            REQUEST_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                startForegroundService(service)
                status.text = "المراقبة تعمل — المؤشر العائم يظهر فوق اللعبة"
            }
            REQUEST_EXPORT -> if (resultCode == RESULT_OK && data?.data != null) exportCsv(data.data!!)
        }
    }

    private fun createCsvDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "football-studio-results.csv")
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    private fun exportCsv(uri: Uri) {
        val values = getSharedPreferences("tracker", Context.MODE_PRIVATE).getString("results", "") ?: ""
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                OutputStreamWriter(stream, Charsets.UTF_8).use { writer ->
                    writer.write("number,result,color\n")
                    values.forEachIndexed { index, value ->
                        val color = when (value) { 'A' -> "red"; 'B' -> "blue"; else -> "yellow_draw" }
                        writer.write("${index + 1},$value,$color\n")
                    }
                }
            } ?: throw IllegalStateException("تعذر فتح الملف")
            Toast.makeText(this, "تم حفظ السجل", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ السجل: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderSavedResults() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val values = prefs.getString("results", "") ?: ""
        strip.removeAllViews()
        val chars = values.takeLast(14).reversed().toList()
        if (chars.isEmpty()) {
            strip.addView(TextView(this).apply {
                text = "ستظهر النتائج هنا بعد اكتشافها"
                setTextColor(Color.LTGRAY)
            })
        } else {
            chars.forEach { ch ->
                val tile = TextView(this).apply {
                    text = ch.toString()
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    setPadding(12, 12, 12, 12)
                    setBackgroundColor(when (ch) {
                        'A' -> Color.rgb(205, 25, 38)
                        'B' -> Color.rgb(25, 77, 153)
                        else -> Color.rgb(230, 190, 25)
                    })
                }
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(3, 0, 3, 0)
                strip.addView(tile, lp)
            }
        }
        history.text = "النتائج المسجلة: ${values.length}\nالأحدث ← الأقدم (من اليسار إلى اليمين):\n${values.reversed().chunked(7).joinToString("  ")}"
        status.text = if (prefs.getBoolean("monitoring", false)) "المراقبة تعمل" else "متوقف — اضغط بدء المراقبة"
    }
}
