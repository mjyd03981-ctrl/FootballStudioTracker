# Football Studio Tracker v1.3

Android screen-capture tracker for the seven-cell Football Studio history strip.

## Sensor frame
- A transparent rounded rectangle is drawn above the live screen.
- Drag inside the frame to move it; drag its edges/corners to resize it in every direction.
- The frame geometry is saved as normalized screen percentages.
- The frame has no filled background; only its border and handles are visible. The reader samples the inner center of each cell to reduce overlay interference.

## Reading and ordering
- The sensor reads seven slots from left to right inside the selected rectangle only.
- A = red, B = blue, X = yellow/gold draw.
- A result is accepted only after a stable sequence is observed and the next snapshot matches a one-slot rightward shift. This prevents repeated recording of a static color.
- The newly detected result is appended to the stored history; the app displays newest first at the far left, with older results moving right.
- The first stable scan is used as a baseline and is not imported as seven new results.

## Important limitations
The reader uses visible screen pixels, not the game's internal data. It is tuned for the seven colored history chevrons shown in the supplied screenshot. If the game layout, zoom, orientation, or number of visible slots changes, move/resize the frame to enclose the row. Consecutive visually identical rows cannot always be distinguished from a static row using color alone; verify the history manually. The app does not predict outcomes.

## Build
Open the repository root in GitHub and run the `Build Football Studio Tracker APK` workflow. The generated debug APK is uploaded as an Actions artifact.


## Broadcast-style seven-cell result strip (v1.3)
- Restores a prominent horizontal strip of seven result tiles in the app UI.
- A is red, B is blue, X is yellow/gold; empty positions remain dark.
- The newest saved result is always shown in the far-left tile. Older results shift one position right.
- The 500-result history remains below the seven-cell strip.
