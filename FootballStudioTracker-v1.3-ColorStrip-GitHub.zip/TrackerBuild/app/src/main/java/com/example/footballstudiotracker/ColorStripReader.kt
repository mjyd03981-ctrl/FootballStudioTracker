package com.example.footballstudiotracker

import android.content.SharedPreferences
import android.media.Image
import kotlin.math.max

/** Reads the seven colored history cells inside the adjustable sensor frame. */
object ColorStripReader {
    const val SLOT_COUNT = 7

    /** Returns left-to-right slots; '-' means no confident colored marker. */
    fun readSequence(image: Image, prefs: SharedPreferences): String {
        val plane = image.planes.firstOrNull() ?: return "-------"
        val buffer = plane.buffer.duplicate()
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (width < 100 || height < 100 || pixelStride < 3) return "-------"

        val xPct = prefs.getInt("sensor_x", 10).coerceIn(0, 950) / 1000f
        val yPct = prefs.getInt("sensor_y", 428).coerceIn(0, 950) / 1000f
        val wPct = prefs.getInt("sensor_w", 980).coerceIn(50, 1000) / 1000f
        val hPct = prefs.getInt("sensor_h", 65).coerceIn(25, 500) / 1000f
        val left = (width * xPct).toInt().coerceIn(0, width - 2)
        val top = (height * yPct).toInt().coerceIn(0, height - 2)
        val right = (left + width * wPct).toInt().coerceIn(left + 1, width - 1)
        val bottom = (top + height * hPct).toInt().coerceIn(top + 1, height - 1)
        val regionWidth = right - left
        val regionHeight = bottom - top
        val slotWidth = regionWidth.toFloat() / SLOT_COUNT
        val output = StringBuilder(SLOT_COUNT)

        for (slot in 0 until SLOT_COUNT) {
            // Ignore the frame edge and sample the central body of each chevron.
            val sx = left + (slot * slotWidth + slotWidth * 0.28f).toInt()
            val ex = left + (slot * slotWidth + slotWidth * 0.72f).toInt()
            val sy = top + (regionHeight * 0.22f).toInt()
            val ey = top + (regionHeight * 0.78f).toInt()
            val stepX = max(1, (ex - sx) / 12)
            val stepY = max(1, (ey - sy) / 6)
            var red = 0; var blue = 0; var yellow = 0; var samples = 0
            var y = sy
            while (y < ey) {
                var x = sx
                while (x < ex) {
                    val index = y * rowStride + x * pixelStride
                    if (index >= 0 && index + 2 < buffer.limit()) {
                        val r = buffer.get(index).toInt() and 0xff
                        val g = buffer.get(index + 1).toInt() and 0xff
                        val b = buffer.get(index + 2).toInt() and 0xff
                        samples++
                        when {
                            r > 95 && r - g > 35 && r - b > 25 && g < 175 -> red++
                            b > 75 && b - r > 22 && b - g > 8 -> blue++
                            r > 130 && g > 95 && r - b > 28 && g - b > 18 -> yellow++
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            if (samples == 0) { output.append('-'); continue }
            val scores = listOf('A' to red, 'B' to blue, 'X' to yellow).sortedByDescending { it.second }
            val best = scores[0]
            val second = scores[1].second
            val required = max(5, (samples * 0.20f).toInt())
            if (best.second < required || best.second < second * 1.30f) output.append('-')
            else output.append(best.first)
        }
        return output.toString()
    }
}
