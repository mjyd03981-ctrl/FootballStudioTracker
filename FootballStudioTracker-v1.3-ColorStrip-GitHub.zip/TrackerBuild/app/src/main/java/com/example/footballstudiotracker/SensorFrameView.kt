package com.example.footballstudiotracker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/** Transparent, draggable and resizable ROI frame. Only its border/handles are painted. */
class SensorFrameView(
    context: Context,
    private val windowManager: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val onFrameChanged: (Int, Int, Int, Int) -> Unit
) : View(context) {
    private val density = resources.displayMetrics.density
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(60, 210, 235); style = Paint.Style.STROKE; strokeWidth = 3.5f * density
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(55, 45, 130, 255); style = Paint.Style.STROKE; strokeWidth = 10f * density
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 115, 255); style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var startW = 0
    private var startH = 0
    private var mode = Mode.MOVE
    private val hit = 34f * density
    private val minW = 150f * density
    private val minH = 36f * density
    private enum class Mode { MOVE, LEFT, RIGHT, TOP, BOTTOM, TL, TR, BL, BR }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val inset = 8f * density
        val rect = RectF(inset, inset, width - inset, height - inset)
        canvas.drawRoundRect(rect, 28f * density, 28f * density, glow)
        canvas.drawRoundRect(rect, 28f * density, 28f * density, border)
        val radius = 9f * density
        val pts = arrayOf(
            inset to inset, (width - inset) to inset,
            inset to (height - inset), (width - inset) to (height - inset),
            width / 2f to inset, width / 2f to (height - inset),
            inset to (height / 2f), (width - inset) to (height / 2f)
        )
        pts.forEach { (x, y) ->
            canvas.drawCircle(x, y, radius + 2f * density, handle)
            canvas.drawCircle(x, y, radius + 2f * density, handleStroke)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX; downRawY = event.rawY
                startX = params.x; startY = params.y; startW = params.width; startH = params.height
                mode = chooseMode(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - downRawX).toInt()
                val dy = (event.rawY - downRawY).toInt()
                when (mode) {
                    Mode.MOVE -> { params.x = (startX + dx).coerceIn(0, screenWidth - params.width); params.y = (startY + dy).coerceIn(0, screenHeight - params.height) }
                    Mode.LEFT, Mode.TL, Mode.BL -> {
                        val newX = (startX + dx).coerceIn(0, startX + startW - minW.toInt())
                        params.width = (startW + startX - newX).coerceAtMost(screenWidth - newX); params.x = newX
                    }
                    Mode.RIGHT, Mode.TR, Mode.BR -> params.width = (startW + dx).coerceIn(minW.toInt(), screenWidth - startX)
                    else -> Unit
                }
                when (mode) {
                    Mode.TOP, Mode.TL, Mode.TR -> {
                        val newY = (startY + dy).coerceIn(0, startY + startH - minH.toInt())
                        params.height = (startH + startY - newY).coerceAtMost(screenHeight - newY); params.y = newY
                    }
                    Mode.BOTTOM, Mode.BL, Mode.BR -> params.height = (startH + dy).coerceIn(minH.toInt(), screenHeight - startY)
                    else -> Unit
                }
                try { windowManager.updateViewLayout(this, params) } catch (_: Exception) { }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                onFrameChanged(params.x, params.y, params.width, params.height)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun chooseMode(x: Float, y: Float): Mode {
        val l = x < hit; val r = x > width - hit; val t = y < hit; val b = y > height - hit
        return when {
            l && t -> Mode.TL; r && t -> Mode.TR; l && b -> Mode.BL; r && b -> Mode.BR
            l -> Mode.LEFT; r -> Mode.RIGHT; t -> Mode.TOP; b -> Mode.BOTTOM
            else -> Mode.MOVE
        }
    }
}
