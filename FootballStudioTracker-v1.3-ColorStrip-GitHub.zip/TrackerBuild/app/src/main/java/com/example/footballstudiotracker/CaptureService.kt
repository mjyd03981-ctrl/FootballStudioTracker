package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var candidateSequence: String? = null
    private var candidateFrames = 0
    private var previousStableSequence: String? = null
    private var sensorFrameView: SensorFrameView? = null
    private var sensorFrameParams: WindowManager.LayoutParams? = null
    private var windowManager: WindowManager? = null
    private var floatingView: LinearLayout? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    val sequence = ColorStripReader.readSequence(image, prefs)
                    processSensorSequence(sequence)
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        showSensorFrame(width, height)
    }

    /**
     * The sensor reads seven cells from left to right. A new card is accepted
     * only after a stable frame shows the old sequence shifted one slot right.
     */
    private fun processSensorSequence(sequence: String) {
        if (sequence.length != ColorStripReader.SLOT_COUNT) return
        if (candidateSequence == sequence) candidateFrames++ else {
            candidateSequence = sequence
            candidateFrames = 1
        }
        if (candidateFrames < 3) return

        val previous = previousStableSequence
        if (previous == null) {
            // First stable scan is a baseline, never imported as seven new results.
            previousStableSequence = sequence
            return
        }
        if (sequence == previous) return

        var aligned = 0
        for (index in 1 until ColorStripReader.SLOT_COUNT) {
            val now = sequence[index]
            val before = previous[index - 1]
            if (now != '-' && before != '-' && now == before) aligned++
        }

        val newResult = sequence.firstOrNull() ?: '-'
        if (newResult in "ABX" && aligned >= 3) {
            val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            val existing = prefs.getString("results", "") ?: ""
            // Stored oldest -> newest; UI reverses it so newest is at far left.
            val updated = (existing + newResult).takeLast(1000)
            prefs.edit().putString("results", updated).apply()
            updateFloatingIndicator(updated)
        }
        // Consume this stable snapshot whether accepted or not, preventing repeats.
        previousStableSequence = sequence
    }

    private fun showSensorFrame(screenWidth: Int, screenHeight: Int) {
        if (!Settings.canDrawOverlays(this) || sensorFrameView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val x = (screenWidth * prefs.getInt("sensor_x", 10) / 1000f).toInt().coerceIn(0, screenWidth - 150)
        val y = (screenHeight * prefs.getInt("sensor_y", 428) / 1000f).toInt().coerceIn(0, screenHeight - 60)
        val w = (screenWidth * prefs.getInt("sensor_w", 980) / 1000f).toInt().coerceIn(150, screenWidth - x)
        val h = (screenHeight * prefs.getInt("sensor_h", 65) / 1000f).toInt().coerceIn(60, screenHeight - y)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }
        val frame = SensorFrameView(this, windowManager!!, params, screenWidth, screenHeight) { fx, fy, fw, fh ->
            prefs.edit()
                .putInt("sensor_x", (fx * 1000f / screenWidth).toInt())
                .putInt("sensor_y", (fy * 1000f / screenHeight).toInt())
                .putInt("sensor_w", (fw * 1000f / screenWidth).toInt())
                .putInt("sensor_h", (fh * 1000f / screenHeight).toInt())
                .apply()
        }
        sensorFrameView = frame
        sensorFrameParams = params
        try { windowManager?.addView(frame, params) } catch (_: Exception) { sensorFrameView = null }
    }

    private fun updateFloatingIndicator(values: String) {
        // The live screen is kept unobstructed; results are shown in the app history.
    }

    private fun removeFloatingIndicator() {
        try { sensorFrameView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        sensorFrameView = null
        sensorFrameParams = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("قراءة خانات شريط النتائج داخل إطار الحساس")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        removeFloatingIndicator()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
