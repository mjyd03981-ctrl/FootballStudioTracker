# Football Studio Tracker v2.8.10 — Paper Bot Decision CSV Log

- Preserves the embedded Data 1 history of 12,874 rounds.
- Adds a separate export option: “حفظ سجل قرارات البوت CSV”.
- The decision log records each newly processed live round, its actual result/color, the prior signal and its settlement, the next decision, the predicted next round number, and the rolling-window support reason.
- The log is separate from the ordinary results CSV and is retained across app restarts. It is cleared only when the user explicitly resets the paper-bot experiment.
- Existing counters and the current strategy thresholds are preserved; no retrospective decision rows are fabricated for rounds processed before this update.
- Detector, sensor, capture, and region-selection source files are unchanged.
- Paper-only simulation; no real betting actions.

Build the APK with GitHub Actions. A local Gradle build was not available in this environment, so APK compilation still needs confirmation by GitHub Actions.
