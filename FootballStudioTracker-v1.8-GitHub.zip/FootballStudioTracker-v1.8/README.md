# Football Studio Tracker v1.5

تحديث لمعالجة اختلاف الألوان وترتيب شريط النتائج حسب الشريط الظاهر في بث Evolution.

## التغييرات في v1.5
- تحليل اللون باستخدام HSV بدلاً من فروق RGB البسيطة؛ وهذا أفضل مع اختلاف الإضاءة وضغط الفيديو.
- دعم علامات النتائج الملونة الرفيعة داخل الخانات الداكنة، إضافة إلى الخانات المملوءة بالألوان.
- تجاهل الخانات غير الواضحة بدلاً من تخمين نتيجة.
- اعتماد اتجاه الشريط الحي: **النتيجة الجديدة تظهر أقصى اليسار، والنتائج القديمة تتحرك إلى اليمين**.
- اكتشاف الإزاحة باتجاه واحد فقط (الجديد يساراً) لمنع تسجيل تغيّر الاتجاه المعاكس.
- انتظار قراءتين متطابقتين متتاليتين قبل اعتماد الشريط لتقليل أخطاء الإطار الواحد.
- ترحيل السجل القديم مرة واحدة من ترتيب القديم-إلى-الجديد إلى ترتيب الجديد-أولاً.
- وضع مؤشر REC إلى يمين مربعات النتائج حتى لا يزاحم أحدث نتيجة.
- ضبط عدد الخانات الافتراضي إلى 7، ويمكن تغييره من المعايرة اليدوية إذا كان الشريط يعرض عدداً مختلفاً.

## مهم قبل الاختبار
1. حدّث ملفات المستودع كاملة بمحتويات هذا المشروع.
2. ابنِ APK من GitHub Actions وثبّته.
3. ابدأ مراقبة الشاشة ثم اختر **تحديد منطقة الالتقاط بالسحب**.
4. ضع الإطار على شريط النتائج نفسه فقط، من أول خانة ظاهرة إلى آخر خانة ظاهرة. لا تضمّن لوحة A/B الكبيرة أو الفيديو أو شريط REC.
5. من «معايرة يدوية متقدمة» اضبط عدد الخانات الظاهرة (غالباً 7 في لقطاتك الحالية).
6. راقب أول نتيجة جديدة وقارنها بالبث. صحّحها يدوياً إذا كانت القراءة غير واضحة.

## حدود القراءة
- القراءة تجريبية وتعتمد على وضوح الشريط ومكان تحديده. إذا كانت كل الخانات متطابقة اللون، فلا يمكن استنتاج حدوث إزاحة من اللون وحده؛ لذلك قد لا يضيف البرنامج نتيجة في هذه الحالة بدلاً من تخمينها.
- إذا تغيّر تكبير صفحة الموقع أو موضع شريط النتائج، أعد تحديد منطقة الالتقاط.
- التطبيق يسجل النتائج المعروضة فقط، ولا يتنبأ بنتائج المباريات ولا ينفذ رهانات.

## البناء
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Kotlin 2.0.21
- JDK 17
- compileSdk 35 / minSdk 26

ارفع **محتويات المجلد** إلى جذر مستودع GitHub، ثم افتح Actions ونزّل `FootballStudioTracker-debug` بعد نجاح البناء.


## v1.7 — Floating controls redesign
- Floating control is now a compact blue ring button that shows/hides the toolbar.
- New vertical black toolbar inspired by the supplied reference: Play/status, Settings/region selection, and four-way Move.
- Drag the four-way move icon to reposition the toolbar anywhere on screen.
- Drag the blue ring button itself to reposition that control.


## الإصدار 1.7
- استعادة زر عائم صغير شبه شفاف؛ الضغط عليه يفتح قائمة التفاصيل والإعدادات.
- إزالة شريط الأدوات الأسود الدائم.
- تحسين قراءة علامات الألوان الرفيعة في وسط خانات Evolution عبر فحص بكسلات أكثر داخل كل خانة.
- تصنيف الأحمر A والأزرق B والذهبي X مع رفض الخانات غير الواضحة بدلاً من التخمين.
- يجب أن تغطي منطقة الالتقاط شريط النتائج فقط، من أول خانة ظاهرة إلى آخر خانة ظاهرة.

ملاحظة: القراءة تعتمد على جودة البث ومكان إطار الالتقاط، ويجب التحقق منها بمقارنة عدة نتائج حقيقية قبل الاعتماد عليها.


## Version 1.8 — detection reliability update

- Each history tile is classified independently as A (red), B (blue), X (gold/yellow), or unknown. An uncertain tile no longer cancels the entire strip read.
- Color classification uses HSV hue/chroma bands and the strongest vertical marker column, targeting Evolution's thin colored strokes.
- A candidate strip must be stable for three consecutive capture frames.
- New outcomes are accepted only when the overlapping cells support a one-position shift to the right, consistent with a new result entering at the left. At least four overlaps are required for a seven-tile strip, with at most one conflicting overlap.
- A short 1.8-second acceptance guard prevents duplicate frame events. It does not replace correct region selection.

### Calibration note
Select only the row of small history chevrons, from the first visible tile through the last. Do not include the large red/blue betting panels, presenter, or match text. Set the tile count to the number of complete visible chevrons in the selected region. If the strip is clipped or includes empty gaps, detection confidence will fall.

### Known limitation
If every visible tile has the same color and the game does not visibly animate or expose a round counter, a screenshot-only color reader cannot prove that the strip shifted. In that case it intentionally cannot guarantee a new result from color pixels alone. This build is a reliability improvement, not a claim of perfect or independently verified recognition.
