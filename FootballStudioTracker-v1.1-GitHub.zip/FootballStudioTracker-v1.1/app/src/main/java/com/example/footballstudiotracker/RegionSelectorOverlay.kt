package com.example.footballstudiotracker

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** A transparent, draggable and resizable screen overlay used to choose the scan rectangle. */
class RegionSelectorOverlay(
    private val context: Context,
    private val windowManager: WindowManager,
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val onSave: (Int, Int, Int, Int) -> Unit,
    private val onCancel: () -> Unit
) {
    private val root = FrameLayout(context)
    private val frame = FrameLayout(context)
    private val border = View(context)
    private val handle = TextView(context)
    private var rootParams: WindowManager.LayoutParams? = null
    private var frameLeft = (screenWidth * 0.025f).toInt()
    private var frameTop = (screenHeight * 0.435f).toInt()
    private var frameWidth = (screenWidth * 0.95f).toInt()
    private var frameHeight = max((screenHeight * 0.055f).toInt(), dp(42))
    private var startX = 0f
    private var startY = 0f
    private var startLeft = 0
    private var startTop = 0
    private var startWidth = 0
    private var startHeight = 0
    private var attached = false

    fun show() {
        root.setBackgroundColor(Color.TRANSPARENT)
        root.isClickable = false
        frame.background = GradientDrawable().apply {
            setColor(Color.argb(28, 40, 180, 255))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(3), Color.rgb(60, 220, 255))
        }
        frame.isClickable = true
        frame.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    startLeft = frameLeft; startTop = frameTop
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    frameLeft = (startLeft + event.rawX - startX).toInt()
                    frameTop = (startTop + event.rawY - startY).toInt()
                    clampFrame(); updateFrameLayout(); true
                }
                else -> true
            }
        }
        root.addView(frame)
        border.background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), Color.WHITE)
            cornerRadius = dp(6).toFloat()
        }
        frame.addView(border, FrameLayout.LayoutParams(-1, -1))
        handle.text = "↘"
        handle.textSize = 20f
        handle.gravity = Gravity.CENTER
        handle.setTextColor(Color.WHITE)
        handle.setBackgroundColor(Color.rgb(0, 105, 160))
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    startWidth = frameWidth; startHeight = frameHeight; true
                }
                MotionEvent.ACTION_MOVE -> {
                    frameWidth = (startWidth + event.rawX - startX).toInt()
                    frameHeight = (startHeight + event.rawY - startY).toInt()
                    clampFrame(); updateFrameLayout(); true
                }
                else -> true
            }
        }
        val handleSize = dp(42)
        frame.addView(handle, FrameLayout.LayoutParams(handleSize, handleSize, Gravity.RIGHT or Gravity.BOTTOM))
        val toolbar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 15, 25, 42)); cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        toolbar.addView(TextView(context).apply {
            text = "حرّك الإطار إلى شريط النتائج، واسحب الزاوية لتغيير حجمه"
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(Button(context).apply {
            text = "حفظ المنطقة"
            setOnClickListener {
                val l = (frameLeft * 1000f / screenWidth).toInt().coerceIn(0, 999)
                val t = (frameTop * 1000f / screenHeight).toInt().coerceIn(0, 999)
                val r = ((frameLeft + frameWidth) * 1000f / screenWidth).toInt().coerceIn(l + 1, 1000)
                val b = ((frameTop + frameHeight) * 1000f / screenHeight).toInt().coerceIn(t + 1, 1000)
                onSave(l, t, r, b)
                dismiss()
            }
        })
        actions.addView(Button(context).apply { text = "إلغاء"; setOnClickListener { dismiss(); onCancel() } })
        toolbar.addView(actions)
        root.addView(toolbar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(48) })
        updateFrameLayout()
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        rootParams = params
        try { windowManager.addView(root, params); attached = true } catch (_: Exception) { attached = false }
    }

    private fun updateFrameLayout() {
        val lp = frame.layoutParams as? FrameLayout.LayoutParams
            ?: FrameLayout.LayoutParams(frameWidth, frameHeight)
        lp.width = frameWidth; lp.height = frameHeight
        lp.leftMargin = frameLeft; lp.topMargin = frameTop
        frame.layoutParams = lp
    }

    private fun clampFrame() {
        frameWidth = frameWidth.coerceIn(dp(90), screenWidth)
        frameHeight = frameHeight.coerceIn(dp(28), (screenHeight * 0.35f).toInt())
        frameLeft = frameLeft.coerceIn(0, max(0, screenWidth - frameWidth))
        frameTop = frameTop.coerceIn(0, max(0, screenHeight - frameHeight))
    }

    fun dismiss() {
        if (attached) try { windowManager.removeView(root) } catch (_: Exception) { }
        attached = false
    }

    private fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
}
