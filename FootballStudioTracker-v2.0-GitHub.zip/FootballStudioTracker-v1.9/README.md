# Football Studio Tracker v1.9

## New result detection method
This version reads the Evolution result announcement banner near the upper center of the screen instead of sampling the tiny history arrows.

- Red banner “الفريق المضيف” => A
- Blue banner “الفريق الضيف” => B
- Gold/yellow banner “اسحب” => X (draw)

## Setup
1. Install the APK built by GitHub Actions.
2. Start screen monitoring and grant Android screen-capture and overlay permissions.
3. From the floating control choose **تحديد منطقة إعلان النتيجة**.
4. Place the rectangle tightly around the colored announcement banner at the top-center of the game. Avoid including the video/table area below it. Save.
5. Keep the game visible. The app requires a stable banner for several frames and records it once. It waits for the banner to disappear for about one second before it can record another announcement.

The newest result is prepended and displayed at the left of the floating history strip. The old history-arrow reader is no longer used for automatic result recording.

## Important limitations
Detection is based on the dominant banner color, not Arabic OCR. It depends on selecting a tight region and on the announcement banner being visible in the captured screen. It has not been validated against a live Evolution session in this build environment. Please compare the first few detected results with the game and correct/delete any mistakes. This app only records visible outcomes; it does not predict results or guarantee betting outcomes.


## v2.0 — ترتيب النتائج
- تخزين النتائج داخلياً بترتيب زمني واضح: الأقدم أولاً.
- عرض النتائج في التطبيق والمؤشر العائم بأحدث نتيجة في أقصى اليسار.
- كل نتيجة جديدة تُضاف إلى نهاية السجل الداخلي، ثم تُعرض بعد عكس العرض فقط.
- تصحيح المربعات وتصدير CSV يتبعان ترتيب العرض الأحدث أولاً.
- ترحيل سجل v1.9 مرة واحدة إلى صيغة التخزين الجديدة.
