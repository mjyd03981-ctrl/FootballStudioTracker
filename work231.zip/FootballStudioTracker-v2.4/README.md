# Football Studio Tracker v2.4

Android Kotlin app that monitors the Evolution Football Studio announcement banner using Android MediaProjection.

## v2.4 updates
- Reads the upper-center result announcement banner selected by the user: red = A, blue = B, gold/yellow = X (draw).
- The visible sensor frame is transparent with a thin blue outline so it does not cover the banner color. The reader ignores the frame border while sampling.
- Region selector opens over the full screen; the frame starts near the upper-center banner and can be moved/resized from all corners and edges.
- Requires a neutral interval before accepting another banner result to reduce duplicate registrations while the same announcement remains visible.
- Results are shown in a horizontal color ribbon; newest is at the far left and older results move right. Tap a tile to correct it.
- Sensor shortcut is placed at the left side of the results header.
- CSV export and persistent local result history remain available.

## Build with GitHub Actions
Upload the contents of this folder to the repository root (do not upload the ZIP as a nested file). The workflow builds `app-debug.apk` using Gradle 8.9 and Java 17. Download it from the successful Actions run under Artifacts.

## First use
1. Open the app and grant permission to display over other apps.
2. Tap **تحديد مربع حساس اللون** and grant screen-capture permission.
3. Place the blue frame around the upper-center Evolution result announcement banner (red team / blue team / yellow draw), then save.
4. Start monitoring and keep the game visible.

## Important limitation
This version reads the banner's dominant color, not the physical playing cards or betting panels. It requires the announcement banner to be visible and unobstructed in the selected frame. Video compression, overlays, theme changes, or a different banner layout may require moving/resizing the frame. It is a visual color detector, not a predictor of future outcomes.
