package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.AudioManager
import android.media.ToneGenerator
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_SELECT_REGION = "select_region"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var lastAcceptedAt = 0L
    private var sensorArmed = false
    private var sensorNeutralFrames = 0
    private var sensorCandidate: Char? = null
    private var sensorCandidateFrames = 0
    private var sensorFrameView: View? = null
    private var historyRibbonView: View? = null
    private var windowManager: WindowManager? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    private var regionSelector: RegionSelectorOverlay? = null
    private var selectingRegion = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data, intent?.getBooleanExtra(EXTRA_SELECT_REGION, false) == true)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent, selectRegion: Boolean) {
        migrateResultOrderIfNeeded()
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        captureWidth = width
        captureHeight = height
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    if (!selectingRegion) {
                        val detected = BannerAnnouncementReader.detect(image, prefs)
                        processSensorDetection(detected)
                    }
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        if (selectRegion) showRegionSelector(width, height) else {
            showSensorFrameIfConfigured()
            showHistoryRibbon()
        }
    }

    private fun showRegionSelector(width: Int, height: Int) {
        removeSensorFrame()
        selectingRegion = true
        regionSelector?.dismiss()
        regionSelector = RegionSelectorOverlay(
            this, getSystemService(WINDOW_SERVICE) as WindowManager, width, height,
            onSave = { left, top, right, bottom ->
                getSharedPreferences("tracker", Context.MODE_PRIVATE).edit()
                    .putInt("region_left", left).putInt("region_top", top)
                    .putInt("region_right", right).putInt("region_bottom", bottom)
                    .putBoolean("region_custom", true).apply()
                selectingRegion = false
                sensorArmed = false
                sensorNeutralFrames = 0
                sensorCandidate = null
                sensorCandidateFrames = 0
                lastAcceptedAt = 0L
                mainHandler.post { showSensorFrameIfConfigured(); showHistoryRibbon() }
                updateFloatingStatus("تم حفظ منطقة حساس اللون")
            },
            onCancel = {
                selectingRegion = false
                updateFloatingStatus("اختيار المنطقة ألغي")
            }
        ).also { it.show() }
    }


    private fun migrateResultOrderIfNeeded() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("banner_reader_v19", false)) {
            // v1.8 stored a rectangle for the history-arrow strip; v1.9 uses the
            // announcement banner, so discard the incompatible old rectangle.
            prefs.edit().remove("region_left").remove("region_top")
                .remove("region_right").remove("region_bottom")
                .putBoolean("banner_reader_v19", true).apply()
        }
        // Keep storage chronological; UI components reverse it for newest-left display.
        if (!prefs.getBoolean("storage_oldest_first_v20", false)) {
            val old = prefs.getString("results", "") ?: ""
            prefs.edit()
                .putString("results", old.reversed())
                .putBoolean("storage_oldest_first_v20", true)
                .apply()
        }
        if (!prefs.getBoolean("scan_count_custom", false)) {
            prefs.edit().putInt("scan_count", 7).apply()
        }
    }

    private fun updateFloatingStatus(message: String) {
        mainHandler.post {
            // Keep the result strip intact; show status separately as a short toast.
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * A color is recorded once after the watched tile has been neutral for several frames.
     * Requiring a neutral interval prevents the same persistent color from being logged again.
     */
    private fun processSensorDetection(detection: BannerAnnouncementReader.Detection?) {
        if (detection == null) {
            sensorNeutralFrames = (sensorNeutralFrames + 1).coerceAtMost(30)
            sensorCandidate = null
            sensorCandidateFrames = 0
            if (sensorNeutralFrames >= 10) sensorArmed = true
            return
        }
        sensorNeutralFrames = 0
        if (!sensorArmed) return

        if (sensorCandidate == detection.result) {
            sensorCandidateFrames++
        } else {
            sensorCandidate = detection.result
            sensorCandidateFrames = 1
        }
        if (sensorCandidateFrames < 6) return

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastAcceptedAt < 1200L) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val chronological = prefs.getString("results", "") ?: ""
        // Alert only when an A or B streak reaches exactly three consecutive wins.
        // This prevents repeated alarms on the 4th, 5th, etc. result in the same streak.
        val previousStreak = trailingStreakLength(chronological, detection.result)
        val shouldAlert = detection.result in listOf('A', 'B') && previousStreak == 2
        prefs.edit()
            .putString("results", (chronological + detection.result).takeLast(1000))
            .putString("last_detected_result", detection.result.toString())
            .putLong("last_detected_at", now)
            .apply()
        mainHandler.post {
            updateHistoryRibbon()
            if (shouldAlert) playThreeInARowAlert(detection.result)
        }

        sensorArmed = false
        sensorCandidate = null
        sensorCandidateFrames = 0
        lastAcceptedAt = now
        updateFloatingStatus(when (detection.result) {
            'A' -> "الحساس رصد شريط الفوز: الأحمر — A"
            'B' -> "الحساس رصد شريط الفوز: الأزرق — B"
            else -> "الحساس رصد شريط الفوز: الأصفر — X"
        })
    }


    /**
     * Counts consecutive A or B wins while ignoring yellow draws (X).
     * Example: A,A,X,A is a three-A streak. The opposite team result breaks it.
     */
    private fun trailingStreakLength(history: String, result: Char): Int {
        if (history.isEmpty() || result !in listOf('A', 'B')) return 0
        var count = 0
        for (index in history.length - 1 downTo 0) {
            when (history[index]) {
                'X' -> continue // Draws do not count and do not break a color streak.
                result -> count++
                else -> break // An opposite A/B win breaks the streak.
            }
        }
        return count
    }

    /** A short notification-style bell when the 3rd consecutive red or blue result arrives. */
    private fun playThreeInARowAlert(result: Char) {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 420)
            mainHandler.postDelayed({
                try { tone.release() } catch (_: Exception) { }
            }, 600L)
            val label = if (result == 'A') "ثلاث نتائج حمراء متتالية" else "ثلاث نتائج زرقاء متتالية"
            android.widget.Toast.makeText(this, label, android.widget.Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            // Audio may be muted or unavailable; result recording must continue normally.
        }
    }

    @Suppress("DEPRECATION")
    private fun showSensorFrameIfConfigured() {
        if (sensorFrameView != null || !Settings.canDrawOverlays(this)) return
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("region_custom", false)) return
        val left = (captureWidth * prefs.getInt("region_left", 90) / 1000f).toInt()
        val top = (captureHeight * prefs.getInt("region_top", 132) / 1000f).toInt()
        val right = (captureWidth * prefs.getInt("region_right", 910) / 1000f).toInt()
        val bottom = (captureHeight * prefs.getInt("region_bottom", 178) / 1000f).toInt()
        val sensor = android.widget.FrameLayout(this).apply {
            background = GradientDrawable().apply {
                // Almost fully transparent: the banner remains visible and its colors stay readable.
                setColor(Color.argb(2, 30, 130, 255))
                cornerRadius = dp(5).toFloat()
                setStroke(dp(2), Color.argb(225, 35, 135, 255))
            }
            contentDescription = "إطار حساس اللون — المراقبة مباشرة"
            addView(android.widget.TextView(this@CaptureService).apply {
                text = "● LIVE SENSOR"
                textSize = 9f
                setTextColor(Color.WHITE)
                setPadding(dp(5), dp(2), dp(5), dp(2))
                background = GradientDrawable().apply {
                    setColor(Color.argb(145, 5, 15, 30))
                    cornerRadius = dp(5).toFloat()
                }
            }, android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (right - left).coerceAtLeast(dp(24)), (bottom - top).coerceAtLeast(dp(24)), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = left; y = top }
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager?.addView(sensor, params)
            sensorFrameView = sensor
        } catch (_: Exception) { sensorFrameView = null }
    }

    /** Displays the recent A/B/X history over the live broadcast. Newest tile is always at far left. */
    @Suppress("DEPRECATION")
    private fun showHistoryRibbon() {
        if (historyRibbonView != null || !Settings.canDrawOverlays(this)) return
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val ribbon = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
            background = GradientDrawable().apply {
                setColor(Color.argb(178, 18, 22, 34))
                cornerRadius = dp(9).toFloat()
                setStroke(dp(1), Color.argb(100, 255, 255, 255))
            }
            isClickable = false
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (metrics.widthPixels - dp(24)).coerceAtLeast(dp(180)), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = (metrics.heightPixels * 0.265f).toInt()
        }
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager?.addView(ribbon, params)
            historyRibbonView = ribbon
            updateHistoryRibbon()
        } catch (_: Exception) { historyRibbonView = null }
    }

    private fun updateHistoryRibbon() {
        val ribbon = historyRibbonView as? android.widget.LinearLayout ?: return
        ribbon.removeAllViews()
        val values = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            .getString("results", "") ?: ""
        val newestFirst = values.takeLast(8).reversed()
        if (newestFirst.isEmpty()) {
            ribbon.addView(android.widget.TextView(this).apply {
                text = "A     B     X"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.LTGRAY)
            }, android.widget.LinearLayout.LayoutParams(-1, -1))
            return
        }
        newestFirst.forEach { result ->
            val tile = android.widget.TextView(this).apply {
                text = result.toString()
                textSize = 17f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(when (result) {
                        'A' -> Color.rgb(205, 48, 55)
                        'B' -> Color.rgb(35, 95, 220)
                        else -> Color.rgb(222, 177, 28)
                    })
                    cornerRadius = dp(5).toFloat()
                    setStroke(dp(1), Color.argb(110, 255, 255, 255))
                }
            }
            val lp = android.widget.LinearLayout.LayoutParams(0, dp(44), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            ribbon.addView(tile, lp)
        }
    }

    private fun removeHistoryRibbon() {
        try { historyRibbonView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        historyRibbonView = null
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun removeSensorFrame() {
        try { sensorFrameView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        sensorFrameView = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("قراءة لون إعلان الفوز داخل إطار الحساس")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        regionSelector?.dismiss()
        regionSelector = null
        removeSensorFrame()
        removeHistoryRibbon()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
