# Football Studio Tracker v2.5

Android Kotlin app for reading the **winner announcement banner** near the upper center of the Football Studio live broadcast.

## Result mapping
- Red banner: `A` (Home / red)
- Blue banner: `B` (Away / blue)
- Yellow/gold banner: `X` (draw)

## How it works
1. Start screen monitoring and grant Android screen-capture permission.
2. Choose **تحديد مربع حساس اللون**.
3. Move/resize the transparent frame so it surrounds only the colored winner announcement bar at the upper center of the broadcast.
4. Press **حفظ المنطقة**.
5. The reader samples only the selected rectangle, ignores low-saturation white text and dark pixels, and accepts a result only when one banner color dominates clearly for several consecutive frames.
6. After one result is accepted, the sensor waits for the banner to disappear (neutral frames) before it can accept the next result. This prevents repeatedly logging one persistent announcement.
7. New results appear at the far left of the horizontal ribbon; older results move right. The same recent-results ribbon is also shown transparently over the live broadcast while monitoring. Tap a result in the app history to correct it. Export history as the original CSV file or as a PNG image containing only colored tiles (no letters or numbers). The PNG grid uses 12 columns and places the newest result at the top-left; red=A, blue=B, yellow=X. The CSV export remains available unchanged.

## Important calibration note
The sensor does not analyze the full screen semantically or read the playing cards. It classifies the dominant red/blue/yellow color in the user-selected announcement rectangle. Keep the frame tightly around the banner and avoid including the red/blue score panels, cards, or colorful studio background.

A repeated same-color win is accepted as a new round only after the announcement disappears and the selected area becomes neutral long enough to re-arm the sensor. If the broadcast keeps the colored banner continuously visible between rounds, the app will intentionally wait rather than guess and create duplicates.

## Build APK with GitHub Actions
Push the extracted project contents to the repository's `main` branch, or run the workflow manually from Actions. Download the `FootballStudioTracker-debug` artifact after a successful run.

Version: 2.5.3 (versionCode 29)

This update only restores the live transparent A/B/X history ribbon. It shows up to the latest 8 results, newest at the far left and older results shifting right. Existing sensor and recognition behavior is unchanged.


## v2.5.3 export addition

The existing CSV export is retained. The save button now offers CSV or a PNG color-grid image. PNG tiles contain no text or numbers, use red for A, blue for B, and yellow for X, and are arranged newest-first from the top-left across 12 columns. Sensor, recognition, live ribbon, and stored results behavior are otherwise unchanged.


## v2.5.4 consecutive-color sound alert

When a newly accepted result completes a streak of exactly three consecutive `A` (red) or `B` (blue) results, the app plays one short notification beep and shows a brief matching message. It does not alert for yellow `X`, and it does not repeat the alert for the 4th or later result in the same uninterrupted streak. A different result breaks the streak. The sensor, region selection, result ordering, live ribbon, CSV export, and PNG export are unchanged.


## v2.5.5 alert streak clarification

Yellow draw results (`X`) are ignored when counting consecutive red (`A`) or blue (`B`) wins. For example, `A, A, X, A` completes a three-red streak and triggers one alert when the final `A` is accepted. An opposite team result (`A` versus `B`) breaks the streak. Further same-color results do not repeat the alert until a new streak of three is formed. All other app behavior is unchanged.
