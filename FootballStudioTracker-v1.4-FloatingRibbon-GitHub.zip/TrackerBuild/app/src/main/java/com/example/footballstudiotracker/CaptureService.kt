package com.example.footballstudiotracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var candidateSequence: String? = null
    private var candidateFrames = 0
    private var previousStableSequence: String? = null
    private var sensorFrameView: SensorFrameView? = null
    private var sensorFrameParams: WindowManager.LayoutParams? = null
    private var windowManager: WindowManager? = null
    private var floatingView: LinearLayout? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private var resultStripView: LinearLayout? = null
    private var resultStripParams: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        thread = HandlerThread("screen-reader").also { it.start() }
        worker = Handler(thread!!.looper)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, worker)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "FootballStudioTracker", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) {
                    val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                    val sequence = ColorStripReader.readSequence(image, prefs)
                    processSensorSequence(sequence)
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, worker)
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", true).apply()
        showSensorFrame(width, height)
        showResultStrip(width, height)
        updateResultStrip(getSharedPreferences("tracker", Context.MODE_PRIVATE)
            .getString("results", "") ?: "")
    }

    /**
     * The sensor reads seven cells from left to right. A new card is accepted
     * only after a stable frame shows the old sequence shifted one slot right.
     */
    private fun processSensorSequence(sequence: String) {
        if (sequence.length != ColorStripReader.SLOT_COUNT) return
        if (candidateSequence == sequence) candidateFrames++ else {
            candidateSequence = sequence
            candidateFrames = 1
        }
        if (candidateFrames < 3) return

        val previous = previousStableSequence
        if (previous == null) {
            // First stable scan is a baseline, never imported as seven new results.
            previousStableSequence = sequence
            return
        }
        if (sequence == previous) return

        var aligned = 0
        for (index in 1 until ColorStripReader.SLOT_COUNT) {
            val now = sequence[index]
            val before = previous[index - 1]
            if (now != '-' && before != '-' && now == before) aligned++
        }

        val newResult = sequence.firstOrNull() ?: '-'
        if (newResult in "ABX" && aligned >= 3) {
            val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
            val existing = prefs.getString("results", "") ?: ""
            // Stored oldest -> newest; UI reverses it so newest is at far left.
            val updated = (existing + newResult).takeLast(1000)
            prefs.edit().putString("results", updated).apply()
            updateFloatingIndicator(updated)
            mainHandler.post { updateResultStrip(updated) }
        }
        // Consume this stable snapshot whether accepted or not, preventing repeats.
        previousStableSequence = sequence
    }

    private fun showSensorFrame(screenWidth: Int, screenHeight: Int) {
        if (!Settings.canDrawOverlays(this) || sensorFrameView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val x = (screenWidth * prefs.getInt("sensor_x", 10) / 1000f).toInt().coerceIn(0, screenWidth - 150)
        val y = (screenHeight * prefs.getInt("sensor_y", 428) / 1000f).toInt().coerceIn(0, screenHeight - 60)
        val w = (screenWidth * prefs.getInt("sensor_w", 980) / 1000f).toInt().coerceIn(150, screenWidth - x)
        val h = (screenHeight * prefs.getInt("sensor_h", 65) / 1000f).toInt().coerceIn(60, screenHeight - y)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }
        val frame = SensorFrameView(this, windowManager!!, params, screenWidth, screenHeight) { fx, fy, fw, fh ->
            prefs.edit()
                .putInt("sensor_x", (fx * 1000f / screenWidth).toInt())
                .putInt("sensor_y", (fy * 1000f / screenHeight).toInt())
                .putInt("sensor_w", (fw * 1000f / screenWidth).toInt())
                .putInt("sensor_h", (fh * 1000f / screenHeight).toInt())
                .apply()
        }
        sensorFrameView = frame
        sensorFrameParams = params
        try { windowManager?.addView(frame, params) } catch (_: Exception) { sensorFrameView = null }
    }


    /**
     * Broadcast-style translucent result ribbon drawn above the live game.
     * Newest result is placed in the left-most cell; older cells shift right.
     */
    private fun showResultStrip(screenWidth: Int, screenHeight: Int) {
        if (!Settings.canDrawOverlays(this) || resultStripView != null) return
        val wm = windowManager ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { windowManager = it }
        val density = resources.displayMetrics.density
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (screenWidth - 24 * density).toInt(),
            (76 * density).toInt(),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * density).toInt()
            y = (screenHeight * 0.245f).toInt()
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding((7 * density).toInt(), (6 * density).toInt(),
                (7 * density).toInt(), (6 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.argb(155, 18, 22, 36))
                cornerRadius = 12 * density
                setStroke((1 * density).toInt(), Color.argb(130, 205, 220, 255))
            }
        }
        val cells = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        repeat(7) {
            val tile = TextView(this).apply {
                text = " "
                tag = "result_cell_$it"
                textSize = 21f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(Color.argb(100, 75, 82, 100))
                    cornerRadius = 5 * density
                    setStroke((1 * density).toInt(), Color.argb(100, 230, 235, 255))
                }
            }
            val lp = LinearLayout.LayoutParams(0, (56 * density).toInt(), 1f)
            lp.setMargins((2 * density).toInt(), 0, (2 * density).toInt(), 0)
            cells.addView(tile, lp)
        }
        bar.addView(cells, LinearLayout.LayoutParams(0, -1, 1f))

        val rec = TextView(this).apply {
            text = "●\nR\nE\nC"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding((5 * density).toInt(), 0, (3 * density).toInt(), 0)
            contentDescription = "مؤشر التسجيل"
        }
        bar.addView(rec, LinearLayout.LayoutParams((32 * density).toInt(), -1))

        // Drag the whole ribbon to any screen position without blocking the game.
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + event.rawX - downX).toInt()
                        .coerceIn(0, screenWidth - params.width)
                    params.y = (startY + event.rawY - downY).toInt()
                        .coerceIn(0, screenHeight - params.height)
                    try { wm.updateViewLayout(bar, params) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }
        resultStripView = bar
        resultStripParams = params
        try {
            wm.addView(bar, params)
        } catch (_: Exception) {
            resultStripView = null
            resultStripParams = null
        }
    }

    private fun updateResultStrip(values: String) {
        val bar = resultStripView ?: return
        val cells = bar.getChildAt(0) as? LinearLayout ?: return
        val newestFirst = values.takeLast(7).reversed()
        for (i in 0 until cells.childCount) {
            val tile = cells.getChildAt(i) as? TextView ?: continue
            val result = newestFirst.getOrNull(i)
            tile.text = when (result) { 'A' -> "A"; 'B' -> "B"; 'X' -> "X"; else -> "" }
            val color = when (result) {
                'A' -> Color.argb(220, 205, 48, 55)
                'B' -> Color.argb(220, 30, 90, 220)
                'X' -> Color.argb(230, 220, 178, 35)
                else -> Color.argb(75, 70, 78, 96)
            }
            tile.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 5 * resources.displayMetrics.density
                setStroke(1, Color.argb(115, 235, 240, 255))
            }
        }
    }

    private fun removeResultStrip() {
        try { resultStripView?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        resultStripView = null
        resultStripParams = null
    }

    private fun updateFloatingIndicator(values: String) {
        // The live screen is kept unobstructed; results are shown in the app history.
    }

    private fun removeFloatingIndicator() {
        try { sensorFrameView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        sensorFrameView = null
        sensorFrameParams = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Football Studio Tracker")
            .setContentText("قراءة خانات شريط النتائج داخل إطار الحساس")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        getSharedPreferences("tracker", Context.MODE_PRIVATE).edit().putBoolean("monitoring", false).apply()
        removeFloatingIndicator()
        removeResultStrip()
        display?.release()
        reader?.close()
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) { } }
        projection?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }
}
