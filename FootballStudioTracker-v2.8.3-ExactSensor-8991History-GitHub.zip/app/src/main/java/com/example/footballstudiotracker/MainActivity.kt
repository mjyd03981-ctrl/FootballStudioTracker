package com.example.footballstudiotracker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStreamWriter

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_CAPTURE = 4102
        private const val REQUEST_OVERLAY = 4103
        private const val REQUEST_EXPORT = 4104
        private const val REQUEST_EXPORT_PNG = 4105
        const val EXTRA_CONTROL_ACTION = "floating_control_action"
        const val ACTION_REQUEST_CAPTURE = "request_capture"
        const val ACTION_REQUEST_REGION = "request_region"
        const val ACTION_CALIBRATE = "calibrate"
        const val ACTION_EXPORT = "export"
    }

    private lateinit var status: TextView
    private lateinit var strip: LinearLayout
    private lateinit var history: TextView
    private var pendingRegionSelection = false
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            renderSavedResults()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        migrateResultOrderIfNeeded()
        migrateUndoStackToUnified()
        val botPrefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        PaperBot.loadHistoricalData(this, botPrefs)
        val botCount = botPrefs.getLong("result_count", (botPrefs.getString("results", "") ?: "").length.toLong())
        PaperBot.migrateToSelectiveStrategy(botPrefs, botCount)
        buildUi()
        renderSavedResults()
        handleControlAction(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleControlAction(intent)
    }

    private fun handleControlAction(intent: Intent?) {
        when (intent?.getStringExtra(EXTRA_CONTROL_ACTION)) {
            ACTION_REQUEST_CAPTURE -> {
                intent.removeExtra(EXTRA_CONTROL_ACTION)
                checkOverlayThenCapture()
            }
            ACTION_REQUEST_REGION -> {
                intent.removeExtra(EXTRA_CONTROL_ACTION)
                checkOverlayThenCapture(selectRegion = true)
            }
            ACTION_CALIBRATE -> {
                intent.removeExtra(EXTRA_CONTROL_ACTION)
                showCalibrationDialog()
            }
            ACTION_EXPORT -> {
                intent.removeExtra(EXTRA_CONTROL_ACTION)
                showExportOptions()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun migrateResultOrderIfNeeded() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("banner_reader_v19", false)) {
            prefs.edit().remove("region_left").remove("region_top")
                .remove("region_right").remove("region_bottom")
                .putBoolean("banner_reader_v19", true).apply()
        }
        // v2.0 uses one unambiguous storage convention: oldest-first in storage.
        // v1.9 prepended new outcomes, so migrate that history exactly once.
        if (!prefs.getBoolean("storage_oldest_first_v20", false)) {
            val old = prefs.getString("results", "") ?: ""
            prefs.edit().putString("results", old.reversed())
                .putBoolean("storage_oldest_first_v20", true).apply()
        }
        if (!prefs.getBoolean("scan_count_custom", false)) {
            prefs.edit().putInt("scan_count", 7).apply()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(Color.rgb(14, 22, 38))
        }
        val title = TextView(this).apply {
            text = "FOOTBALL STUDIO TRACKER"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        status = TextView(this).apply {
            text = "متوقف — اضغط بدء المراقبة"
            textSize = 14f
            setTextColor(Color.rgb(180, 195, 215))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "بدء مراقبة الشاشة"
            setOnClickListener { checkOverlayThenCapture() }
        }
        val stop = Button(this).apply {
            text = "إيقاف المراقبة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "المراقبة متوقفة"
                renderSavedResults()
            }
        }
        val selectRegion = Button(this).apply {
            text = "تحديد مربع حساس اللون"
            setOnClickListener { checkOverlayThenCapture(selectRegion = true) }
        }
        val calibrate = Button(this).apply {
            text = "معايرة يدوية متقدمة"
            setOnClickListener { showCalibrationDialog() }
        }
        val export = Button(this).apply {
            text = "حفظ السجل CSV / صورة ملونة"
            setOnClickListener { showExportOptions() }
        }
        val reset = Button(this).apply {
            text = "مسح السجل"
            setOnClickListener { clearManualResults() }
        }
        val manualControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
        }
        listOf(
            Triple("+ A أحمر", 'A', Color.rgb(205, 48, 55)),
            Triple("+ X أصفر", 'X', Color.rgb(222, 177, 28)),
            Triple("+ B أزرق", 'B', Color.rgb(30, 90, 220))
        ).forEach { (label, value, color) ->
            val addButton = Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(color)
                setOnClickListener { addManualResult(value) }
            }
            manualControls.addView(addButton, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val undoButton = Button(this).apply {
            text = "تراجع"
            textSize = 11f
            setOnClickListener { undoManualChange() }
        }
        manualControls.addView(undoButton, LinearLayout.LayoutParams(0, -2, 0.8f))
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 14, 0, 14)
        }
        val resultsHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 12, 0, 4)
        }
        val sensorShortcut = Button(this).apply {
            text = "◉ تحديد الحساس"
            textSize = 12f
            setOnClickListener { checkOverlayThenCapture(selectRegion = true) }
        }
        val gridTitle = TextView(this).apply {
            text = "شريط النتائج — الأحدث يساراً"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 4)
        }
        resultsHeader.addView(sensorShortcut, LinearLayout.LayoutParams(0, -2, 1f))
        resultsHeader.addView(gridTitle, LinearLayout.LayoutParams(0, -2, 2f))
        history = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        }
        val note = TextView(this).apply {
            text = "حساس إعلان الفوز: ضع الإطار الشفاف حول الشريط الملون أعلى منتصف البث فقط. الأحمر يسجل A، الأزرق B، والأصفر X. يتطلب الحساس لوناً واضحاً وثابتاً لعدة إطارات، ثم ينتظر اختفاء الإعلان قبل قبول نتيجة جديدة؛ لذلك لا يكرر الإعلان نفسه. النتائج الجديدة تظهر أقصى اليسار. اضبط الإطار بدقة حول شريط الإعلان لتقليل قراءة ألوان الخلفية."
            textSize = 13f
            setTextColor(Color.rgb(180, 195, 215))
            setPadding(0, 18, 0, 0)
        }
        val alertSettings = Button(this).apply {
            text = "إعدادات الإنذارات"
            setOnClickListener { showAlertSettings() }
        }
        val paperBot = Button(this).apply {
            text = "البوت التجريبي — بدون رهان حقيقي"
            setOnClickListener { showPaperBotDialog() }
        }
        listOf(title, status, start, stop, selectRegion, calibrate, export, reset, alertSettings, paperBot, resultsHeader, manualControls).forEach { root.addView(it) }
        val resultsScroll = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            addView(strip, android.view.ViewGroup.LayoutParams(-2, -2))
        }
        root.addView(resultsScroll)
        listOf(history, note).forEach { root.addView(it) }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }


    private fun showPaperBotDialog() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val snapshot = PaperBot.snapshot(prefs)
        val state = if (snapshot.enabled) "يعمل — يسجل توقعات افتراضية فقط" else "متوقف"
        val pending = snapshot.pending?.let { if (it == 'A') "Home / المضيف" else "Away / الضيف" } ?: "انتظار — لا توجد إشارة"
        val last = snapshot.lastSignal?.let { if (it == 'A') "Home / المضيف" else "Away / الضيف" } ?: "لا توجد إشارة بعد"
        val message = "الحالة: $state\n\nالإشارات الصادرة: ${snapshot.signals}\nالجولات التي اختار فيها البوت الانتظار: ${snapshot.waits}\nالصحيحة: ${snapshot.wins}\nالخاطئة: ${snapshot.losses}\nنسبة النجاح بعد التسوية: ${snapshot.accuracy}%\nقرار الجولة القادمة: $pending\nآخر إشارة صادرة: $last\nالجولات التي تم تجاوزها بسبب فجوة تسلسل: ${snapshot.skipped}\n\nقاعدة البيانات التاريخية المحمّلة: ${PaperBot.historicalRounds(prefs)} جولة. الاستراتيجية الانتقائية: لا يصدر إشارة إلا إذا اتفقت أغلبية آخر 10 و20 و50 نتيجة غير تعادل على نفس الطرف، مع دعم لا يقل عن 60% في كل نافذة. وإلا ينتظر. التعادل X يُحسب خسارة للإشارة المعلقة. هذه تجربة ورقية، ولم تثبت أفضلية تنبؤية."
        val builder = AlertDialog.Builder(this).setTitle("بوت Football Studio التجريبي")
            .setMessage(message)
            .setNegativeButton("إغلاق", null)
        if (snapshot.enabled) {
            builder.setPositiveButton("إيقاف البوت") { _, _ ->
                PaperBot.stop(prefs)
                Toast.makeText(this, "تم إيقاف البوت التجريبي", Toast.LENGTH_SHORT).show()
            }
        } else {
            builder.setPositiveButton("بدء التجربة") { _, _ ->
                val count = prefs.getLong("result_count", (prefs.getString("results", "") ?: "").length.toLong())
                PaperBot.start(prefs, count)
                Toast.makeText(this, "بدأ البوت التجريبي — لا توجد رهانات حقيقية", Toast.LENGTH_LONG).show()
            }
        }
        builder.setNeutralButton("تصفير إحصائيات التجربة") { _, _ ->
            val count = prefs.getLong("result_count", (prefs.getString("results", "") ?: "").length.toLong())
            PaperBot.reset(prefs, count)
            Toast.makeText(this, "تم تصفير إحصائيات التجربة", Toast.LENGTH_SHORT).show()
        }
        builder.show()
    }

    private fun showAlertSettings() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val options = arrayOf("إعداد إنذار النتائج المتتالية", "إعداد إنذار توقف اللعب")
        AlertDialog.Builder(this).setTitle("إعدادات الإنذارات").setItems(options) { _, which ->
            if (which == 0) showStreakSettings() else showStopSettings()
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun showStreakSettings() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("streak_alert_enabled", true)
        val threshold = prefs.getInt("streak_threshold", 9).coerceIn(1, 15)
        val sounds = arrayOf("ثلاث نبضات قوية (الحالي)")
        AlertDialog.Builder(this).setTitle("إنذار النتائج المتتالية")
            .setSingleChoiceItems((1..15).map { "$it نتيجة" }.toTypedArray(), threshold - 1) { dialog, which ->
                prefs.edit().putInt("streak_threshold", which + 1).apply()
            }
            .setNeutralButton(if (enabled) "إيقاف الإنذار" else "تشغيل الإنذار") { _, _ -> prefs.edit().putBoolean("streak_alert_enabled", !enabled).apply(); Toast.makeText(this, if (enabled) "تم إيقاف إنذار النتائج" else "تم تشغيل إنذار النتائج", Toast.LENGTH_SHORT).show() }
            .setPositiveButton("حفظ", null).show()
    }

    private fun showStopSettings() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("stop_alert_enabled", true)
        val current = prefs.getInt("stop_alert_seconds", 15).coerceIn(10, 60)
        val sounds = arrayOf("طوط قصير", "صفارة إلكترونية", "تنبيه متقطع")
        AlertDialog.Builder(this).setTitle("إنذار توقف اللعب")
            .setSingleChoiceItems((10..60).map { "$it ثانية" }.toTypedArray(), current - 10) { _, which -> prefs.edit().putInt("stop_alert_seconds", which + 10).apply() }
            .setNeutralButton(if (enabled) "إيقاف الإنذار" else "تشغيل الإنذار") { _, _ -> prefs.edit().putBoolean("stop_alert_enabled", !enabled).apply(); Toast.makeText(this, if (enabled) "تم إيقاف إنذار توقف اللعب" else "تم تشغيل إنذار توقف اللعب", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("الصوت: ${sounds[prefs.getInt("stop_alert_sound", 0).coerceIn(0,2)]}") { _, _ ->
                AlertDialog.Builder(this).setTitle("اختيار صوت إنذار التوقف").setItems(sounds) { _, which -> prefs.edit().putInt("stop_alert_sound", which).apply() }.show()
            }.setPositiveButton("حفظ", null).show()
    }

    private fun showCalibrationDialog() {
        AlertDialog.Builder(this)
            .setTitle("معايرة حساس اللون")
            .setMessage("ضع الإطار حول شريط إعلان الفوز أعلى منتصف البث، وليس فوق أوراق اللعب أو شريط التاريخ. الأحمر = A، الأزرق = B، الأصفر = X. احفظ المنطقة بعد أن يحيط الإطار بالشريط الملون فقط.")
            .setNegativeButton("إغلاق", null)
            .setPositiveButton("تحديد المنطقة") { _, _ -> checkOverlayThenCapture(selectRegion = true) }
            .show()
    }

    private fun checkOverlayThenCapture(selectRegion: Boolean = false) {
        pendingRegionSelection = selectRegion
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح للتطبيق بالظهور فوق التطبيقات لإظهار إطار حساس اللون", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY -> if (Settings.canDrawOverlays(this)) requestScreenCapture()
            REQUEST_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                    putExtra(CaptureService.EXTRA_SELECT_REGION, pendingRegionSelection)
                }
                startForegroundService(service)
                status.text = if (pendingRegionSelection) "حدد شريط إعلان الفوز أعلى منتصف البث ثم اضغط حفظ المنطقة" else "المراقبة تعمل — حساس اللون يراقب الإطار المحدد"
                pendingRegionSelection = false
            }
            REQUEST_EXPORT -> if (resultCode == RESULT_OK && data?.data != null) exportCsv(data.data!!)
            REQUEST_EXPORT_PNG -> if (resultCode == RESULT_OK && data?.data != null) exportColorGridPng(data.data!!)
        }
    }

    private fun showExportOptions() {
        AlertDialog.Builder(this)
            .setTitle("حفظ سجل النتائج")
            .setItems(arrayOf("حفظ CSV النصي (كما هو)", "حفظ صورة مربعات ملونة PNG")) { _, which ->
                if (which == 0) createCsvDocument() else createPngDocument()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun createPngDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/png"
            putExtra(Intent.EXTRA_TITLE, "football-studio-results.png")
        }
        startActivityForResult(intent, REQUEST_EXPORT_PNG)
    }

    private fun exportColorGridPng(uri: Uri) {
        val exportPrefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val values = exportPrefs.getString("results", "") ?: ""
        val totalCount = exportPrefs.getLong("result_count", values.length.toLong())
        if (values.isEmpty()) {
            Toast.makeText(this, "لا توجد نتائج لحفظها", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            // Match the app's display convention: newest result at the top-left.
            val newestFirst = values.takeLast(500).reversed()
            val columns = 12
            val cellWidth = 112
            val cellHeight = 92
            val gap = 16
            val padding = 20
            val rows = (newestFirst.length + columns - 1) / columns
            val width = padding * 2 + columns * cellWidth + (columns - 1) * gap
            val height = padding * 2 + rows * cellHeight + (rows - 1) * gap
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.rgb(12, 15, 25))
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            newestFirst.forEachIndexed { index, result ->
                val tileNumber = totalCount - index
                val row = index / columns
                val col = index % columns
                val left = (padding + col * (cellWidth + gap)).toFloat()
                val top = (padding + row * (cellHeight + gap)).toFloat()
                val rect = RectF(left, top, left + cellWidth, top + cellHeight)
                paint.color = when (result) {
                    'A' -> Color.rgb(220, 25, 35)
                    'B' -> Color.rgb(16, 43, 165)
                    else -> Color.rgb(245, 190, 35)
                }
                paint.style = Paint.Style.FILL
                canvas.drawRoundRect(rect, 12f, 12f, paint)
                paint.color = Color.rgb(190, 205, 230)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.5f
                canvas.drawRoundRect(rect, 12f, 12f, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = when { tileNumber >= 10000L -> 24f; tileNumber >= 1000L -> 28f; tileNumber >= 100L -> 34f; else -> 42f }
                paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                val textY = rect.centerY() - (paint.ascent() + paint.descent()) / 2f
                canvas.drawText(tileNumber.toString(), rect.centerX(), textY, paint)
            }
            contentResolver.openOutputStream(uri)?.use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                    throw IllegalStateException("تعذر إنشاء صورة PNG")
                }
            } ?: throw IllegalStateException("تعذر فتح ملف الصورة")
            bitmap.recycle()
            Toast.makeText(this, "تم حفظ صورة النتائج الملونة", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ الصورة: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun createCsvDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "football-studio-results.csv")
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    private fun exportCsv(uri: Uri) {
        val values = getSharedPreferences("tracker", Context.MODE_PRIVATE).getString("results", "") ?: ""
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                OutputStreamWriter(stream, Charsets.UTF_8).use { writer ->
                    writer.write("number,result,color\n")
                    values.reversed().forEachIndexed { index, value ->
                        val color = when (value) { 'A' -> "red"; 'B' -> "blue"; else -> "yellow_draw" }
                        writer.write("${index + 1},$value,$color\n")
                    }
                }
            } ?: throw IllegalStateException("تعذر فتح الملف")
            Toast.makeText(this, "تم حفظ السجل", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ السجل: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderSavedResults() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val values = prefs.getString("results", "") ?: ""
        val totalCount = prefs.getLong("result_count", values.length.toLong())
        PaperBot.observe(prefs, totalCount, values)
        strip.removeAllViews()

        // One horizontal ribbon: newest result is always the leftmost tile.
        val newestFirst = values.takeLast(500).reversed()
        if (newestFirst.isEmpty()) {
            strip.addView(TextView(this).apply {
                text = "ستظهر النتائج هنا بعد اكتشافها"
                setTextColor(Color.LTGRAY)
                setPadding(8, 18, 8, 18)
            })
        } else {
            newestFirst.forEachIndexed { newestFirstIndex, ch ->
                val tileNumber = totalCount - newestFirstIndex
                val tile = TextView(this).apply {
                    text = tileNumber.toString()
                    textSize = when { tileNumber >= 10000L -> 7f; tileNumber >= 1000L -> 8f; tileNumber >= 100L -> 10f; tileNumber >= 10L -> 12f; else -> 15f }
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(when (ch) {
                            'A' -> Color.rgb(205, 48, 55)
                            'B' -> Color.rgb(30, 90, 220)
                            else -> Color.rgb(222, 177, 28)
                        })
                        cornerRadius = 7f
                        setStroke(1, Color.argb(90, 255, 255, 255))
                    }
                    contentDescription = when (ch) {
                        'A' -> "أحمر A"
                        'B' -> "أزرق B"
                        else -> "تعادل X أصفر"
                    }
                    setOnClickListener { showCorrectionDialog(newestFirstIndex, ch) }
                    setOnLongClickListener {
                        confirmDeleteResult(newestFirstIndex)
                        true
                    }
                }
                val size = (resources.displayMetrics.widthPixels / resources.displayMetrics.density / 11f)
                    .toInt().coerceIn(28, 42)
                val lp = LinearLayout.LayoutParams(size, size)
                lp.setMargins(2, 3, 2, 3)
                strip.addView(tile, lp)
            }
        }

        val counts = values.take(500).groupingBy { it }.eachCount()
        val savedCount = values.count()
        val shownCount = newestFirst.count()
        history.text = "المجموع المحفوظ: ${savedCount}  |  المعروض: ${shownCount}\nA أحمر: ${counts['A'] ?: 0}   B أزرق: ${counts['B'] ?: 0}   X أصفر: ${counts['X'] ?: 0}\nإضافة: أزرار A / X / B — اضغط مربعاً لتصحيحه، واضغط مطولاً لحذفه. التراجع يشمل النتائج اليدوية والتلقائية."
        status.text = if (prefs.getBoolean("monitoring", false)) "المراقبة تعمل" else "متوقف — اضغط بدء المراقبة"
    }

    private fun migrateUndoStackToUnified() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        if (!prefs.contains("result_undo_stack_v278")) {
            val legacy = prefs.getString("manual_undo_stack_v274", "") ?: ""
            prefs.edit().putString("result_undo_stack_v278", legacy.takeIf { it.isNotEmpty() } ?: "")
                .remove("manual_undo_stack_v274").apply()
        }
    }

    private fun saveUndoSnapshot() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val stack = prefs.getString("result_undo_stack_v278", "") ?: ""
        val results = prefs.getString("results", "") ?: ""
        val count = prefs.getLong("result_count", results.length.toLong())
        val entry = "$count:$results"
        val updated = (if (stack.isEmpty()) listOf(entry) else stack.split("\n") + entry).takeLast(100)
        prefs.edit().putString("result_undo_stack_v278", updated.joinToString("\n")).apply()
    }

    private fun addManualResult(value: Char) {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val old = prefs.getString("results", "") ?: ""
        saveUndoSnapshot()
        val updated = (old + value).takeLast(1000)
        val nextNumber = prefs.getLong("result_count", old.length.toLong()) + 1L
        prefs.edit().putString("results", updated)
            .putLong("result_count", nextNumber)
            .putString("last_detected_result", value.toString())
            .apply()
        renderSavedResults()
        Toast.makeText(this, "تمت إضافة النتيجة $value يدوياً", Toast.LENGTH_SHORT).show()
    }

    private fun confirmDeleteResult(latestIndex: Int) {
        AlertDialog.Builder(this)
            .setTitle("حذف نتيجة")
            .setMessage("هل تريد حذف هذا المربع من السجل؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف") { _, _ ->
                val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                val old = prefs.getString("results", "") ?: ""
                val index = old.length - 1 - latestIndex
                if (index in old.indices) {
                    saveUndoSnapshot()
                    val updated = old.removeRange(index, index + 1)
                    val previousCount = prefs.getLong("result_count", old.length.toLong())
                    prefs.edit().putString("results", updated)
                        .putLong("result_count", (previousCount - 1L).coerceAtLeast(updated.length.toLong())).apply()
                    renderSavedResults()
                    Toast.makeText(this, "تم حذف النتيجة وإعادة الترقيم", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun clearManualResults() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val old = prefs.getString("results", "") ?: ""
        if (old.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("مسح جميع النتائج؟")
            .setMessage("سيتم تفريغ السجل وإعادة الترقيم من 1.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("مسح") { _, _ ->
                saveUndoSnapshot()
                prefs.edit().remove("results").remove("baseline")
                    .putLong("result_count", 0L).apply()
                renderSavedResults()
            }.show()
    }

    private fun undoManualChange() {
        val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
        val stack = (prefs.getString("result_undo_stack_v278", "") ?: "").split("\n").filter { it.isNotEmpty() }
        if (stack.isEmpty()) {
            Toast.makeText(this, "لا توجد خطوات إضافية للتراجع", Toast.LENGTH_SHORT).show()
            return
        }
        val entry = stack.last()
        val separator = entry.indexOf(':')
        if (separator < 1) return
        val count = entry.substring(0, separator).toLongOrNull() ?: 0L
        val results = entry.substring(separator + 1)
        prefs.edit().putString("results", results).putLong("result_count", count)
            .putString("result_undo_stack_v278", stack.dropLast(1).joinToString("\n"))
            .apply()
        renderSavedResults()
        Toast.makeText(this, "تم التراجع — متبقي ${stack.size - 1} خطوة", Toast.LENGTH_SHORT).show()
    }

    private fun showCorrectionDialog(latestIndex: Int, current: Char) {
        val choices = arrayOf("A — أحمر", "B — أزرق", "X — أصفر / تعادل")
        val selected = when (current) { 'A' -> 0; 'B' -> 1; else -> 2 }
        AlertDialog.Builder(this)
            .setTitle("تصحيح النتيجة")
            .setSingleChoiceItems(choices, selected) { dialog, which ->
                val replacement = when (which) { 0 -> 'A'; 1 -> 'B'; else -> 'X' }
                val prefs = getSharedPreferences("tracker", Context.MODE_PRIVATE)
                val old = prefs.getString("results", "") ?: ""
                // The visible list is newest-first while storage is oldest-first.
                val index = old.length - 1 - latestIndex
                if (index in old.indices) {
                    saveUndoSnapshot()
                    val updated = old.toCharArray()
                    updated[index] = replacement
                    prefs.edit().putString("results", String(updated)).apply()
                    Toast.makeText(this, "تم تصحيح النتيجة إلى $replacement", Toast.LENGTH_SHORT).show()
                    renderSavedResults()
                }
                dialog.dismiss()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
